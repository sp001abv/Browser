package com.sp.browser;

import android.graphics.Canvas;
import java.util.ArrayList;

class WebDiv extends WebItem {
    ArrayList<WebItem> items = new ArrayList<WebItem>();

    @Override
    boolean remove(WebItem item)
    {
        if (items.contains(item)){
            items.remove(item);
            return true;
        }
        for(int i=0;i<items.size();i++) {
            if (items.get(i).remove(item))
                return true;
        }
        return false;
    }

    @Override
    WebItem get(float x, float y) {
        for(int i=0;i<items.size();i++) {
            WebItem item = items.get(i).get(x, y);
            if (item != null)
                return item;
        }
        return super.get(x, y);
    }

    @Override
    void move(float left, float top, float right, float bottom)
    {
        float l = left;
        float t = top;
        float h = 0;
        for(WebItem item : items){
            if (item.newrow || (l+item.width>right)) {
                t += h;
                h = 0;
                l = left;
            }
            if (h<item.height) h=item.height;
            item.move(l,t,l+item.width,t+item.height);
            l+=item.width;
        }
        super.move(left, top, right, bottom);
    }

    @Override
    boolean wrap(float w, float h)
    {
        for(WebItem item : items)
            item.wrap(w, h);
        size(w);
        return true;
    }

    void size(float w)
    {
        float l= 0;
        float h = 0;
        height = 0;
        width = 0;
        for(WebItem item : items){
            if (item.newrow || l+item.width>w){
                if (width<l) width=l;
                height+=h;
                h = l = 0;
            }
            if (h<item.height) h=item.height;
            l+=item.width;
        }
        if (width<l) width=l;
        if (width>0) width+=2f;
        height+=h;
    }

    @Override
    void onDestroy() {
        for(WebItem item : items)
            item.onDestroy();
        items.clear();
        items = null;
    }

    @Override
    void onDraw(Canvas canvas) {
        float h = canvas.getHeight();
        for(int i=0;i<items.size();i++) {
            WebItem item = items.get(i);
            if (item.intersects(h))
                item.onDraw(canvas);
        }
    }

    @Override
    void select(float x1, float y1, float x2, float y2) {
        for(int i=0;i<items.size();i++)
            items.get(i).select(x1, y1, x2, y2);
    }

    @Override
    void copy(CopyBuilder builder) {
        for(int i=0;i<items.size();i++) {
            items.get(i).copy(builder);
        }
    }

    @Override
    void find(String text, ArrayList<Finding> findings) {
        for(int i=0;i<items.size();i++)
            items.get(i).find(text, findings);
    }

    @Override
    void select(int index, int length) {
        for(int i=0;i<items.size();i++)
            items.get(i).select(index, length);
    }

    @Override
    boolean offset(float x, float y, float dx, float dy) {
        for(int i=0;i<items.size();i++)
            items.get(i).offset(x, y, dx, dy);
        return super.offset(x, y, dx, dy);
    }

    @Override
    void addMediaHref(ArrayList<String> hrefs) {
        for(int i=0;i<items.size();i++)
            items.get(i).addMediaHref(hrefs);
    }
}



package com.sp.browser;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;

import android.content.Intent;
import android.view.Window;
import android.view.WindowManager;

import java.lang.Thread.UncaughtExceptionHandler;

public class MainActivity extends Activity implements UncaughtExceptionHandler
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		String url = null;
		String type = null;
        if (Pages.activity == null) {
			Pages.activity = this;
			Cookies.load();
			S.bookmarks.load();
			S.blockedImages.load();
			Downloader.start();
			Thread.setDefaultUncaughtExceptionHandler(this);
		}
		Intent intent = getIntent();
		if (intent != null) {
			type = intent.getType();
			String action = intent.getAction();
			if (action.equals(Intent.ACTION_MAIN))
				url = S.home_folder + C.home_page_file;
			else if (action.equals(Intent.ACTION_SEND))
				url = intent.getStringExtra(Intent.EXTRA_TEXT);
			else if (action.equals(Intent.ACTION_VIEW))
				url = intent.getDataString();
		}
		if (url != null && url.length() > 0 ) {
			if (url.charAt(0) == C.slash)
				url = C.file + url;
			Pages.add(url, type);
			if (Pages.activity != this)
				finish();
		} else
			finish();
    }

	@Override
	protected void onDestroy(){
    	if (Pages.activity == this) {
			Downloader.stop();
			Pages.clear();
			Pages.activity = null;
		}
		super.onDestroy();
	}

	void toggleFullScreen(){
		Window window = getWindow();
		if (window != null){
			try{
				if (S.full_screen)
					window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
				else
					window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
			}catch(Exception e){
                S.full_screen = !S.full_screen;
			    Toaster.postLongToast(e.getMessage());
			}
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		Pages.active().invalidateLayout();
	}

	public void uncaughtException(Thread thread, final Throwable e) {
		StringBuilder sb = new StringBuilder();
		sb.append(e.getMessage());
		Logger.log(e.getMessage());
		StackTraceElement[] stack = e.getStackTrace();
		for(int i = 0; i < 5 && i < stack.length; i++) {
			sb.append(C.newline);
			sb.append(stack[i].toString());
			Logger.log(stack[i].toString());
		}
		Toaster.postLongToast(sb.toString());
    }

	boolean onBack() {
		Actions aa = Actions.active;
		if (aa != null) {
		    if (aa.closeOnBack()) {
                if (aa.onBack()) {
                    Pages.active().postInvalidate();
                    return false;
                }
            } else {
		        return false;
            }
		}
		else {
			if (Pages.active().onBack())
				return false;
		}
		WebPage page = Pages.cut();
		if (page != null) {
			Downloader.clear();
			page.onDestroy();
			page = Pages.active();
			if (page != null){
				setContentView(page);
				return false;
			}
		}
		return true;
	}

	@Override
	public void onBackPressed() {
		if (onBack())
			super.onBackPressed();
	}
}


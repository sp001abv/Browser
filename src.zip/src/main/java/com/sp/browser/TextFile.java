package com.sp.browser;

import java.io.FileOutputStream;

class TextFile extends WebText {
    boolean edited;
    String url;
    String encoding;

    TextFile(String text, String url, String encoding) {
        this.text = text;
        this.url = url;
        this.encoding = encoding;
    }

    @Override
    public void del() {
        edited = true;
        super.del();
    }

    @Override
    public boolean onEnter() {
        return false;
    }

    @Override
    public void paste(String chars) {
        edited = true;
        if (text.length() == 0)
            width = 0;
        super.paste(chars);
    }

    @Override
    boolean wrap(float w, float h) {
        if (text.length() == 0) {
            width = w;
            height = h;
            return  true;
        }
        return super.wrap(w, h);
    }

    @Override
    void onDestroy() {
        if (edited) {
            try {
                FileOutputStream output = new FileOutputStream(S.getLocalPath(url));
                output.write(text.getBytes(encoding));
                output.close();
            }
            catch (Exception e) {

            }
        }
        super.onDestroy();
    }

    @Override
    void onClick(float x, float y) {
        if (!editing) {
            startEditing();
        }
        super.onClick(x, y);
    }
}

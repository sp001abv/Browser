package com.sp.browser;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

class TextFile extends WebTextEdit {
    boolean edited;
    String url;
    String encoding;

    TextFile(String text, String url, String encoding) {
        this.text = text;
        this.url = url;
        this.encoding = encoding;
    }

    @Override
    public void del() {
        edited = true;
        super.del();
    }

    @Override
    public boolean onEnter() {
        return false;
    }

    @Override
    public boolean paste(String chars) {
        edited = true;
        if (text.length() == 0)
            width = 0;
        return super.paste(chars);
    }

    @Override
    public boolean undo() {
        if (edited) {
            try {
                String path = S.getLocalPath(url);
                FileInputStream is = new FileInputStream(path);
                ByteArrayOutputStream bs = new ByteArrayOutputStream();
                byte[] buff = new byte[2048];
                int length;
                while ((length = is.read(buff)) != -1)
                    bs.write(buff, 0, length);
                setText(bs.toString(encoding));
                is.close();
                edited = false;
                return true;
            }
            catch (Exception e) {
                Toaster.postLongToast(e.getMessage());
            }
        }
        return false;
    }

    @Override
    public void save() {
        try {
            String path = S.getLocalPath(url);
            FileOutputStream output = new FileOutputStream(path);
            output.write(text.getBytes(encoding));
            output.close();
            edited = false;
            Toaster.postShortToast(C.saved_as + path);
        }
        catch (Exception e) {
            Toaster.postLongToast(e.getMessage());
        }
    }

    @Override
    boolean wrap(float w, float h) {
        if (text.length() == 0) {
            width = w;
            height = h;
            return  true;
        }
        return super.wrap(w, h);
    }

    @Override
    void onDestroy() {
        if (edited)
            save();
        super.onDestroy();
    }

    @Override
    void onClick(float x, float y) {
        if (!editing)
            startEditing(x, y);
        else
            super.onClick(x, y);
    }
}

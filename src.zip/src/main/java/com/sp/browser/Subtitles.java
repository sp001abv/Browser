package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.ArrayList;

class Subtitles {
    class Subtitle {
        long startTime;
        long stopTime;
        ArrayList<String> line = new ArrayList<String>();
    }

    String subtitlesFile;
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    ArrayList<Subtitle> subtitles = new ArrayList<Subtitle>();
    int subtitlesIndex;
    Subtitle subtitle;
    float positionY;
    float textSize = S.subtitle_text_size;
    int maxLines;
    boolean update;
    long subtitlesTime;
    long subtitlesTimeOffset;
    GLBitmapTextureRenderer renderer;

    Subtitles(float position) throws  Exception{
        positionY = position;
    }

    void onDraw(Canvas canvas) {
        float x;
        float y = textSize;
        paint.setTextSize(textSize);
        int index;
        for (int i = 0 ; i < subtitle.line.size(); i++, y += textSize) {
            String line = subtitle.line.get(i);
            boolean closeBold = false;
            boolean closeItalic = false;
            boolean closeUnderline = false;
            while ((index = line.indexOf(C.open)) >= 0)
            {
                int i2 = line.indexOf(C.close, index);
                if (i2>index) {
                    String tag = line.substring(index+1, i2).toLowerCase();
                    boolean open = true;
                    if (tag.charAt(0) == C.slash) {
                        tag = tag.substring(1);
                        open = false;
                    }
                    while (tag.charAt(0) == C.space) {
                        tag = tag.substring(1);
                    }
                    if (tag.startsWith("b")) {
                        if (open)
                            paint.setFakeBoldText(true);
                        else
                            closeBold = true;
                    }
                    else if (tag.startsWith("i")) {
                        if (open)
                            paint.setTextSkewX(-0.30f);
                        else
                            closeItalic = true;
                    }
                    else if (tag.startsWith("u")) {
                        if (open)
                            paint.setUnderlineText(true);
                        else
                            closeUnderline = true;
                    }
                    else if (tag.startsWith("font")) {
									/*
									String attr = getAttribute(line, "color");
									if (attr != null)
										color = Color.parseColor(attr);
									*/
                    }
                    else
                        break;
                    line = line.replace(line.substring(index, i2 + 1), C.empty);
                }
                else
                    break;
            }
            x = (canvas.getWidth()-paint.measureText(line))/2;
            paint.setColor(Color.BLACK);
            canvas.drawText(line, x+2, y+2, paint);
            paint.setColor(Color.WHITE);
            canvas.drawText(line, x, y, paint);
            if (closeBold)
                paint.setFakeBoldText(false);
            if (closeItalic)
                paint.setTextSkewX(0);
            if (closeUnderline)
                paint.setUnderlineText(false);

        }
    }

    void onOffset(float dx, float dy) {
        if (Math.abs(dx) > Math.abs(dy)) {
            subtitlesTimeOffset += dx;
            if (Math.abs(subtitlesTimeOffset) < 16)
                subtitlesTimeOffset = 0;
        }
        else {
            positionY += dy;
        }

        update = true;
    }

    final String TIME_SPLITTER = "-->";

    void parse(String path) throws Exception {
        FileInputStream inputStream = new FileInputStream(path);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] buff = new byte[2048];
        int length;
        String encoding = null;
        while ((length = inputStream.read(buff)) != -1){
            if (encoding == null)
                encoding = S.guessEncoding(buff, length);
            byteArrayOutputStream.write(buff, 0, length);
        }
        if (encoding == null) encoding = C.utf8;
        String[] source = byteArrayOutputStream.toString(encoding).split(String.valueOf(C.newline));
        inputStream.close();
        byteArrayOutputStream.close();

        Subtitle subtitle = null;
        for (int i = 0; i < source.length; i++) {
            if (source[i].contains(TIME_SPLITTER)) {
                String[] time = source[i].split(TIME_SPLITTER);
                if (time.length == 2) {
                    Integer startTime = S.parseTime(time[0]);
                    Integer stopTime = S.parseTime(time[1]);
                    if (startTime != null && stopTime != null && stopTime > startTime) {
                        subtitle = new Subtitle();
                        subtitle.startTime = startTime;
                        subtitle.stopTime = stopTime;
                    }
                }
            } else if (subtitle != null) {
                String line = source[i].trim();
                if (line.length() > 0) {
                    subtitle.line.add(line);
                } else {
                    if (maxLines < subtitle.line.size())
                        maxLines = subtitle.line.size();
                    subtitles.add(subtitle);
                    subtitle = null;
                }
            }
        }
    }

    void toggle(WebPage page) throws Exception {
        if (page.localFiles == null) {
            page.localFiles = new ArrayList<String>();
            page.loadLocalFiles(page.localFiles, false);
        }
        for (int i = 0; i < page.localFiles.size(); i++) {
            if (S.isSubtitle(page.localFiles.get(i))) {
                if (subtitlesFile == null) {
                    subtitlesFile = page.localFiles.get(i);
                    break;
                } else if (subtitlesFile.equals(page.localFiles.get(i))) {
                    subtitlesFile = null;
                }
            }
        }
        subtitles.clear();
        subtitlesTimeOffset = subtitlesTime = subtitlesIndex = maxLines = 0;
        subtitle = null;
        if (subtitlesFile != null)
            parse(page.siteUrl + C.slash + subtitlesFile);
    }

    void onDrawFrame(VideoSurfaceView videoView, int videoPosition) {
        if (subtitlesFile != null) {
            long time = videoPosition + subtitlesTimeOffset;
            if (subtitlesTime > time) {
                subtitle = null;
                subtitlesIndex = 0;
            }
            subtitlesTime = time;
            while (subtitle == null && subtitlesIndex < subtitles.size()) {
                if (subtitles.get(subtitlesIndex).stopTime < subtitlesTime) {
                    subtitlesIndex++;
                    continue;
                }
                if (subtitles.get(subtitlesIndex).startTime <= subtitlesTime) {
                    subtitle = subtitles.get(subtitlesIndex);
                    update = true;
                    subtitlesIndex++;
                }
                break;
            }
            if (subtitle != null) {
                if (renderer == null) {
                    renderer = videoView.createBitmapRenderer(videoView.getWidth(), (int)(textSize * 1.2f * maxLines), true);
                }
                if (update) {
                    onDraw(renderer.getCanvas(0, positionY, videoView.getWidth(), videoView.getHeight()));
                    update = false;
                }
                renderer.render();
                if (subtitle.stopTime < subtitlesTime) {
                    subtitle = null;
                }
            }
        }
    }
}

package com.sp.browser;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLConnection;

class DisqusThread extends WebDiv implements IDownload
{
    int updateCount;
    float maxWidth;
    DisqusThread(String url) {
        Pages.active().addItem(this);
        href = url;
        update();
    }

    void update() {
        Downloader.download(this);
    }

    @Override
    void copy(CopyBuilder builder) {
        WebText t = (WebText)items.get(0);
        if (t.sel1>=0 && t.sel2 > t.sel1)
            builder.append(href, false);
    }

    @Override
    boolean wrap(float w, float h) {
        if (maxWidth > 0) w = maxWidth;
        return super.wrap(w, h);
    }

    @Override
    void onClick(float x, float y) {
        update();
    }

    void addMessage(WebPage page, Integer depth, String avatar, String name, String created, Integer likes, String message) throws Exception {
        DisqusMessage disqusMessage = new DisqusMessage();
        page.divs.add(disqusMessage);
        if (depth == null)
            depth = 0;
        else if (depth > 20)
            depth = 20;
        depth *= S.text_size;
        disqusMessage.depth = depth;
        if (avatar != null)
            page.addImage(avatar, avatar.replace("avatar32", "avatar92"));
        StringBuilder sb = new StringBuilder();
        sb.append(name);
        sb.append(C.space);
        if (likes != null && likes > 0) {
            sb.append(C.space);
            sb.append(likes);
            sb.appendCodePoint(128077);
        }
        if (created != null) {
            sb.append(C.space);
            if (created.length() > 12)
                created = created.substring(11);
            sb.append(created);
        }
        page.addText(sb.toString());
        page.decode(message, true);
        page.addItem(page.divs.cut());
        disqusMessage.newrow = true;
    }

    void decode(WebPage page, String json) throws Exception {
        page.decoding = true;
        page.divs.add(this);
        WebText disqus;
        if (items.size() > 0) {
            while (items.size() > 2)
                items.remove(items.size()-1);
            disqus = (WebText) items.get(1);
        }
        else {
            disqus = new WebText();
            disqus.href = href;
            disqus.setText("Disqus");
            items.add(disqus);
            disqus = new WebText();
            disqus.setText(C.empty);
            items.add(disqus);
        }
        if (updateCount > 0) disqus.setText(String.valueOf(updateCount));
        int i = json.indexOf("disqus-threadData");
        if (i > 0) {
            int i2 = json.indexOf("</script>", i);
            if (i2 > 0) {
                json = json.substring(i, i2);
                int n = json.length()-1;
                i = 20;
                while (page.decoding && i>0 && i<n) {
                    i2 = json.indexOf("},{", i);
                    if (i2 < 0) i2 = n;
                    String post = json.substring(i, i2);
                    Integer likes = S.parseInteger(S.getJsonAttribute(post, "likes"));
                    String name = S.getJsonAttribute(post, "name");
                    if (name == null) break;
                    String created = S.getJsonAttribute(post, "createdAt");
                    String message = S.getJsonAttribute(post, "message");
                    if (message == null) break;
                    Integer depth = S.parseInteger(S.getJsonAttribute(post, "depth"));
                    String avatar = S.getJsonAttribute(post, "cache");
                    addMessage(page,depth,avatar,name,created,likes,message);
                    i = i2+3;
                }
            }
        }
        page.divs.cut();
        page.decoding = false;
    }

    @Override
    public void download(WebPage page) {
        page.downloadUrl(href, this, null, null);
    }

    @Override
    public void onResponse(WebPage page, URLConnection connection, InputStream inputStream) throws Exception {
        ByteArrayOutputStream source = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        int length;
        while ((length = inputStream.read(buff)) != -1)
            source.write(buff, 0, length);
        String json = source.toString();
        while (page.decoding)
            Thread.sleep(10);
        decode(page, json);
        updateCount++;
    }

    @Override
    public void onError(WebPage page, URLConnection connection, String error) {
        if (page.divs.last() != this)
            page.divs.add(this);
        page.addText(error, href);
        page.divs.cut();
        page.decoding = false;
        updateCount++;
    }
}

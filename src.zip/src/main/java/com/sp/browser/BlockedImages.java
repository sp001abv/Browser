package com.sp.browser;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Iterator;

class BlockedImages extends HashSet<String> {
    static final long serialVersionUID = 1;
    void load(){
        try
        {
            FileInputStream is = new FileInputStream(S.home_folder + C.blocked_images_file);
            int size = is.read();
            for(int i=0;i<size;i++){
                add(S.readString(is));
            }
            is.close();
        }
        catch (Exception e)
        {
        }
    }
    void save() {
        try
        {
            FileOutputStream os = new FileOutputStream(S.home_folder + C.blocked_images_file);
            os.write(size());
            for(Iterator<String> i = iterator(); i.hasNext();){
                S.writeString(os,i.next());
            }
            os.close();
        }
        catch (Exception e)
        {
        }
    }
}

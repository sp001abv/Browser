package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

import java.util.ArrayList;

class WebText extends WebItem {
    String text;
    ArrayList<String> line = null;
    int[] lpos = null;
    Paint paint;
    int sel1= -1;
    int sel2= -1;
    float wrapw = 0;

    WebText() {
        init(false, S.text_size);
    }

    WebText(boolean bold, float size) {
        init(bold, size);
    }

    void init(boolean bold, float size) {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTypeface(Typeface.SANS_SERIF);
        paint.setTextSize(size);
        paint.setColor(S.color_text);
        paint.setFakeBoldText(bold);
    }

    void drawSelection(Canvas canvas, float x, float y, int lpos, String l){
        if (sel1 >= 0 && sel2 >= 0) {
            int i1 = sel1 - lpos;
            int i2 = sel2 - lpos;
            int len = l.length();
            if ((i1 >=0 || i2 >=0) && (i1 <= len || i2 <= len)){
                if (i1 != i2) {
                    int i = i1 < i2 ? i1 : i2;
                    float x1 = i > 0 ? paint.measureText(l, 0, i) : 0;
                    float size = paint.getTextSize();
                    float dy = size * 0.25f;
                    i = i1 < i2 ? i2 : i1;
                    if (i > len) i = len;
                    float x2 = paint.measureText(l, 0, i);
                    int color = paint.getColor();
                    paint.setColor(S.color_selected);
                    canvas.drawRect(x + x1, y - size + dy, x + x2, y + dy, paint);
                    paint.setColor(color);
                }
            }
        }
    }

    int getPosition(float x, String l){
        float dx = x - rect.left;
        int i = 0;
        for(;i<l.length();i++){
            if (dx < paint.measureText(l, 0, i+1))
                break;
        }
        return i;
    }

    int getPosition(float x, float y){
        if (rect.contains(x,y)){
            if (line == null){
                return getPosition(x,text);
            }
            else {
                int i = (int)((y-rect.top)/paint.getTextSize());
                if (i < line.size())
                    return lpos[i] + getPosition(x, line.get(i));
            }
        }
        return -1;
    }

    int getLineIndex(int index) {
        if (lpos != null && paint != null) {
            for(int i = 1; i<lpos.length;i++){
                if (index <= lpos[i])
                    return i-1;
            }
            return lpos.length-1;
        }
        return -1;
    }

    float getPositionY(int index){
        int lineIndex = getLineIndex(index);
        if (lineIndex >= 0)
            return lineIndex * paint.getTextSize();
        return 0;
    }

    @Override
    void select(float x1, float y1, float x2, float y2){
        sel1 = getPosition(x1,y1);
        if (sel1 == -1) {
            boolean line1 = rect.top < y1 && rect.bottom > y1;
            boolean line2 = rect.top < y2 && rect.bottom > y2;
            if (!(
                    (rect.top > y1 && rect.bottom < y2) ||
                            (rect.left > x1 && line1 && !line2) ||
                            (rect.right < x2 && line2 && !line1) ||
                            (rect.left > x1 && rect.right < x2 && line1 && line2) ||
                            rect.contains(x2, y2)
            ))
                return;

            sel1 = 0;
        }
        sel2 = getPosition(x2,y2);
        if (sel2 == -1) sel2 = text.length();
    }

    @Override
    void copy(CopyBuilder builder){
        if (sel1 >= 0 && sel2 >= 0) {
            if (sel2 > sel1)
                builder.append(text.substring(sel1,sel2), newrow);
            else if (sel1 > sel2)
                builder.append(text.substring(sel2,sel1), newrow);
        }
    }

    void onDraw(Canvas canvas, float top, float bottom)
    {
        float size = paint.getTextSize();
        float x = rect.left;
        float y = rect.top + size;
        int end = line.size();
        for(int i = 0; i < end; i++) {
            String l = line.get(i);
            if ((y > top)) {
                drawSelection(canvas, x, y, lpos[i], l);
                canvas.drawText(l, x, y, paint);
            }
            if (y > bottom)
                break;
            y += size;
        }
    }

    @Override
    void onDraw(Canvas canvas) {
        if (line == null){
            if (text != null){
                drawSelection(canvas, rect.left, rect.bottom, 0, text);
                canvas.drawText(text, rect.left, rect.bottom, paint);
            }
        }
        else
            onDraw(canvas, 0, canvas.getHeight());
    }

    @Override
    boolean scale(float scale) {
        wrapw=0;
        paint.setTextSize(paint.getTextSize() * scale);
        return true;
    }

    @Override
    boolean wrap(float w, float h) {
        if (wrapw==w) return true;
        wrapw = w;
        line = null;
        line = null;
        lpos = null;
        height = paint.getTextSize();
        float sw;
        if (text.length() * height * 0.3f > w ||
                text.indexOf(C.newline) > 0 ||
                (sw = paint.measureText(text)) > w) {
            int i1 = 0;
            int i2 = 0;
            float aw = sw = 0;
            float acs = height * 0.75f;
            line = new ArrayList<String>();
            char[] c = new char[1];
            for (int i = 0; i < text.length(); i++) {
                c[0] = text.charAt(i);
                aw += acs;
                if (c[0] == C.newline) {
                    line.add(text.substring(i1, i));
                    i1 = i;
                    aw = sw = 0;
                    i2 = 0;
                }
                else if (c[0] == C.space) {
                    i2 = i + 1;
                }
                if (aw > w) {
                    if (sw == 0)
                        sw = paint.measureText(text.substring(i1, i+1));
                    else
                        sw += paint.measureText(c, 0, 1);
                    if (sw > w) {
                        if (i2 == 0) {
                            i2 = i;
                            aw = 0;
                        } else {
                            aw -= (i2 - i1) * acs;
                        }
                        line.add(text.substring(i1, i2));
                        i1 = i2;
                        i2 = 0;
                        sw = 0;
                    }
                }
            }
            line.add(text.substring(i1));
            int n = line.size();
            lpos = new int[n];
            int pos = 0;
            for (int i=0; i<n; i++) {
                lpos[i]=pos;
                pos+=line.get(i).length();
            }
            width = w;
            height *= n;
        } else {
            width = sw + height/2;
        }
        return true;
    }

    void setText(String value) {
        text = value;
        wrapw = 0;
        paint.setColor(href == null ? S.color_text : S.color_link);
    }

    @Override
    void onClick(float x, float y)
    {
        if (href != null){
            paint.setColor(S.color_visited);
            super.onClick(x, y);
        }
    }

    @Override
    void onDoubleClick(float x, float y){
        if (href == null){
            if (sel1 >= 0 && sel2 > sel1) {
                String selected = text.substring(sel1,sel2);
                if (selected.startsWith(C.http))
                    Pages.add(selected);
            }
        }
        else
            super.onDoubleClick(x, y);
    }

    @Override
    void find(String s, ArrayList<Finding> findings, boolean match){
        String t = match ? text : text.toLowerCase();
        int i = t.indexOf(s);
        while (i >= 0) {
            findings.add(new Finding(this, i, getPositionY(i)));
            i = t.indexOf(s, i+s.length());
        }
    }

    @Override
    void select(int index, int length)
    {
        if (length > 0) {
            sel1 = index;
            sel2 = index + length;
        }
        else {
            deselect();
        }
    }

    void deselect() {
        sel2 = sel1 = -1;
    }
}

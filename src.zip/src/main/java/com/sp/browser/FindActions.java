package com.sp.browser;

class FindActions extends Actions {
    class FindNextAction extends ActionEdit {
        @Override
        String getName() {
            return String.format("%s %d/%d", edit.text, count > 0 ? index+1 : 0, count);
        }

        @Override
        void onClick(float x, float y){
            String name = getName();
            if (!edit.editing) {
                if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.slash)))) {
                    find(1);
                    return;
                }
                else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.space)))) {
                    find(-1);
                    return;
                }
            }
            if (x < rect.left + S.action_text_size) {
                edit.text = C.empty;
                resize();
            }
        }

        @Override
        public void del() {
            super.del();
            page = null;
            resize();
        }

        @Override
        public void paste(String t) {
            super.paste(t);
            page = null;
            resize();
        }

        @Override
        public boolean startEditing(float x, float y) {
            if (edit.text.length() > 0 && x > rect.left + paint.measureText(edit.text))
                return false;
            return super.startEditing(x, y);
        }

        @Override
        public void stopEditing() {
            super.stopEditing();
            find(0);
        }

    }
    class FindCloseAction extends Action{
        @Override
        String getName() { return "close"; }

        @Override
        void onClick(float x, float y){
            close();
        }
    }

    WebPage page = null;
    FindNextAction findNextAction = null;
    int index = 0;
    int count = 0;

    FindActions() {
        findNextAction = new FindNextAction();
        items.add(findNextAction);
        items.add(new FindCloseAction());
    }

    void close() {
        if (!findNextAction.edit.editing)
            super.onBack();
    }

    void find(int next){
        String text = findNextAction.edit.text;
        if (text.length() > 1) {
            if (page != Pages.active()) {
                page = Pages.active();
                next = index = 0;
                count = page.find(text);
            }
            if (count > 0) {
                index += next;
                if (index == count) index = 0;
                if (index < 0) index = count - 1;
                page.find(text, index);
            }
        }
        resize();
    }

    @Override
    void show(float x, float y){
        if (findNextAction.edit.text == null || findNextAction.edit.text.length() < 2) {
            findNextAction.edit.text = Pages.getClipboardText();
            if (findNextAction.edit.text == null) {
                findNextAction.edit.text = C.empty;
            }
        }
        page = null;
        if (paint == null) init();
        find(0);
        super.show(x, y);
    }
    @Override
    boolean closeOnClick(){
        return false;
    }
    @Override
    boolean onBack(){
        return false;
    }
}

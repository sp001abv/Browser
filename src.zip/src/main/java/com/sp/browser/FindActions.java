package com.sp.browser;

class FindActions extends Actions {
    class FindAction extends ActionEdit {
        @Override
        String getName() {
            return String.format("%s %d/%d\t%s", edit.text, count > 0 ? index+1 : 0, count, match ? "Aa" : "A");
        }

        @Override
        void onClick(float x, float y){
            String name = getName(); 
            /*if (!edit.editing)*/ {
               if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.tab)))) {
                    match = ! match;
                    page = null;
                    find(0);
                    return;
                }
                else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.slash)))) {
                    find(1);
                    return;
                }
                else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.space)))) {
                    find(-1);
                    return;
                }
            }
            if (x < rect.left + S.action_text_size) {
                edit.text = C.empty;
                resize();
            }
            super.onClick(x, y);
        }

        @Override
        public boolean onUp(boolean shift, float dy) {
            find(-1);
            return true;
        }

        @Override
        public boolean onDown(boolean shift, float dy) {
            find(1);
            return true;
         }

        @Override
        public void del() {
            super.del();
            page = null;
            resize();
        }

        @Override
        public boolean paste(String t) {
            super.paste(t);
            page = null;
            resize();
            return false;
        }

        @Override
        public boolean startEditing(float x, float y) {
            if (edit.text.length() > 0 && x > rect.left + paint.measureText(edit.text))
                return false;
            return super.startEditing(x, y);
        }

        @Override
        public void stopEditing() {
            super.stopEditing();
            find(0);
        }

    }

    class ReplaceAction extends ActionEdit {
        @Override
        String getName() {
            return String.format("%s R/A", edit.text, count > 0 ? index+1 : 0, count);
        }

        @Override
        void onClick(float x, float y){
            String name = getName();
            /*if (!edit.editing)*/ {
                if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.slash)))) {
                    replace(true);
                    return;
                }
                else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.space)))) {
                    replace(false);
                    return;
                }
            }
            if (x < rect.left + S.action_text_size) {
                edit.text = C.empty;
                resize();
            }
            super.onClick(x, y);
        }

        @Override
        public boolean onUp(boolean shift, float dy) {
            if (shift)
                replace(true);
            else
                find(-1);
            return true;
        }

        @Override
        public boolean onDown(boolean shift, float dy) {
            if (shift)
                replace(false);
            else
                find(1);
            return true;
         }

        @Override
        public void del() {
            super.del();
            page = null;
            resize();
        }

        @Override
        public boolean paste(String t) {
            super.paste(t);
            page = null;
            resize();
            return false;
        }

        @Override
        public boolean startEditing(float x, float y) {
            if (edit.text.length() > 0 && x > rect.left + paint.measureText(edit.text))
                return false;
            return super.startEditing(x, y);
        }

        @Override
        public void stopEditing() {
            super.stopEditing();
        }

    }

    class FindCloseAction extends Action{
        @Override
        String getName() { return "close"; }

        @Override
        void onClick(float x, float y){
            close();
        }
    }

    WebPage page = null;
    FindAction findAction;
    ReplaceAction replaceAction;
    int index = 0;
    int count = 0;
    boolean match = false;

    FindActions() {
        findAction = new FindAction();
        replaceAction = new ReplaceAction();
        items.add(findAction);
        items.add(replaceAction);
        items.add(new FindCloseAction());
    }

    void close() {
        if (!findAction.edit.editing)
            super.onBack();
    }

    void find(int next){
        String text = findAction.edit.text;
        if (text.length() > 0) {
            if (page != Pages.active()) {
                page = Pages.active();
                next = index = 0;
                count = page.find(text, match);
            }
            if (count > 0) {
                index += next;
                if (index >= count) index = 0;
                if (index < 0) index = count - 1;
                page.find(index, text.length(), true);
            }
            else index = 0;
        }
        resize();
    }

    void replace(boolean all) {
        String text = replaceAction.edit.text;
        if (text.length() > 0) {
            if (page != Pages.active())
                find(0);
            while (count > 0 && index < count) {
                if (page.replace(index, text)) {
                    count = page.find(findAction.edit.text, match); 
                    if (text.contains(findAction.edit.text)) index++;
                }    
                else index++;
                if (index < count)
                    page.find(index, findAction.edit.text.length(), !all);
                if (!all) break;
            }
        }
                
        resize();
    }

    @Override
    void show(float x, float y){
        if (findAction.edit.text == null || findAction.edit.text.length() == 0) {
            findAction.edit.text = Pages.getClipboardText();
            if (findAction.edit.text == null) {
                findAction.edit.text = C.empty;
            }
        }
        if (replaceAction.edit.text == null || replaceAction.edit.text.length() == 0) {
            replaceAction.edit.text = findAction.edit.text;
        }
        page = null;
        if (paint == null) init();
        find(0);
        super.show(x, y);
    }

    @Override
    boolean closeOnClick(){
        return false;
    }
    @Override
    boolean onBack(){
        return false;
    }
}

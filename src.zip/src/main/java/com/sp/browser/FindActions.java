package com.sp.browser;

import android.graphics.RectF;

class FindActions extends Actions {
    class FindNextAction extends Action implements ITextEditor {
        String name = C.empty;
        @Override
        String getName() { return name; }

        @Override
        int getColor() {
            return Pages.active().focusedItem == this ? S.color_visited : S.color_link;
        }

        @Override
        void onClick(float x, float y){
            if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.slash))))
                find(1);
            else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.space))))
                find(-1);
            else {
                if (x < rect.left + S.action_text_size) {
                    text = C.empty;
                    update();
                }
                startEditing();
            }

        }

        @Override
        public boolean onEnter() {
            return true;
        }

        @Override
        public boolean onLeft() {
            return false;
        }

        @Override
        public boolean onRight() {
            return false;
        }

        @Override
        public void cut() {
            if (text.length() > 0) {
                text = text.substring(0, text.length() - 1);
                page = null;
            }
            update();
        }

        @Override
        public void paste(String t) {
            text += t;
            page = null;
            update();
        }

        @Override
        public RectF getRect() {
            return rect;
        }

        @Override
        public void stopEditing() {
            find(0);
        }

        void startEditing() {
            Pages.active().showSoftInput(this);
        }
    }
    class FindCloseAction extends Action{
        @Override
        String getName() { return "close"; }

        @Override
        void onClick(float x, float y){
            close();
        }
    }
    WebPage page = null;
    String text = null;
    FindNextAction findNextAction = null;
    int index = 0;
    int count = 0;
    FindActions() {
        findNextAction = new FindNextAction();
        items.add(findNextAction);
        items.add(new FindCloseAction());
    }
    void close() {
        super.onBack();
    }
    void find(int next){
        if (text.length() > 1) {
            if (page != Pages.active()) {
                page = Pages.active();
                next = index = 0;
                count = page.find(text);
            }
            if (count > 0) {
                index += next;
                if (index == count) index = 0;
                if (index < 0) index = count - 1;
                page.find(text, index);
            }
        }
        update();
    }
    void update(){
        findNextAction.name = String.format("%s %d/%d", text, count > 0 ? index+1 : 0, count);
        resize();
    }

    @Override
    void show(float x, float y){
        if (text == null || text.length() < 2) {
            text = Pages.getClipboardText();
            if (text == null) {
                text = C.empty;
                findNextAction.startEditing();
            }
        }
        page = null;
        if (paint == null) init();
        find(0);
        super.show(x, y);
    }
    @Override
    boolean closeOnClick(){
        return false;
    }
    @Override
    boolean onBack(){
        return false;
    }
}

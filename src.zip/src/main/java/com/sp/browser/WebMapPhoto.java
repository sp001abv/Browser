package com.sp.browser;

import android.graphics.Bitmap;

import java.io.InputStream;
import java.net.URLConnection;

class WebMapPhoto implements IDownload {
    String src;
    WebMapLocation location;
    int width;
    int height;
    boolean pano;
    float scale = S.default_scale;
    Bitmap bitmap = null;
    WebMapPhoto(String src, WebMapLocation location, int w, int h){
        pano = src.indexOf("-pi")>0;
        this.src = src.substring(0,src.indexOf(C.equals)+1);
        this.location = location;
        this.width = w;
        this.height = h;
        Downloader.download(this);
    }
    String getUrl(int w, int h){
        return src+String.format("w%d-h%d-k-no",w,h);
    }
    String getUrl(int w, int h, int pi, int ya, int fo){
        return src+String.format("w%d-h%d-k-no-pi-%d-ya%d-ro-0-fo%d",w,h,pi,ya,fo);
    }
    @Override
    public void download(WebPage page){
        int w = width;
        int h = height;
        int s = 200;
        while (w > s && h > s){
            w/=2;
            h/=2;
        }
        page.downloadUrl(getUrl(w, h), this, null, null);
    }

    @Override
    public void onResponse(WebPage page, URLConnection connection, InputStream inputStream) throws Exception{
        bitmap = S.decodeImage(inputStream);
    }

    @Override
    public void onError(WebPage page, URLConnection connection, String error){
    }

    public void onDestroy() {
        if (bitmap != null) {
            bitmap.recycle();
            bitmap = null;
        }
    }
}

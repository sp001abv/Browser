package com.sp.browser;

import java.util.ArrayList;

class CopyFileAsync implements Runnable {
    String destination;
    ArrayList<String> files;
    IProgress progress;
    WebPage page;
    CopyFileAsync(WebPage page, ArrayList<String> files, String destination, IProgress progress){
        this.page = page;
        this.files = files;
        this.destination = destination;
        this.progress = progress;
    }
    @Override
    public void run() {
        for (int i = 0; i < files.size(); i++) {
            String source = files.get(i);
            if (!S.copyFile(source, destination, progress)) {
                FileWriter.closeOutput();
                page.loadLocalFolder();
                page = null;
                return;
            }
        }
        progress.onProgress(null);
        FileWriter.closeOutput();
        page.loadLocalFolder();
        page = null;
    }
}

package com.sp.browser;

/*
class WebImageEditor extends WebItem {
    Canvas canvas;
    Bitmap bitmap;
    Action action;
    Paint paint;
    EditActions actions;
    ArrayList<Selection> selections = new ArrayList<Selection>();
    Selection selection;
    float blend;
    float x0, y0, x1, y1, x2, y2;
    float[] randoms;

    float random(int n) {
        if (randoms == null) {
            Random random = new Random();
            randoms = new float[512];
            for (int i = 0; i < randoms.length; i++)
                randoms[i] = random.nextFloat();
        }
        return randoms[n % randoms.length];
    }

    class Points extends ArrayList<PointF> {
        void offset(float dx, float dy) {
            for (int i = 0; i < size(); i++) {
                PointF p = get(i);
                p.x += dx;
                p.y += dy;
            }
        }

        void scale(float cx, float cy, float scale) {
            for (int i = 0; i < size(); i++) {
                PointF p = get(i);
                p.x = cx + (p.x - cx) * scale;
                p.y = cy + (p.y - cy) * scale;
            }
        }

        void move(float x1, float y1, float x0, float y0, float scale) {
            for (int i = 0; i < size(); i++) {
                PointF p = get(i);
                p.x = x1 + (p.x - x0) * scale;
                p.y = y1 + (p.y - y0) * scale;
            }
        }
    }

    class Line extends Points {
        float brushSize;
    }

    class Lines extends ArrayList<Line> {
        Paint paint;
        Lines() {
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setStyle(Paint.Style.STROKE);
        }

        void offset(float dx, float dy) {
            for (int i = 0; i < size(); i++) {
                get(i).offset(dx, dy);
            }
        }

        void scale(float cx, float cy, float scale) {
            for (int i = 0; i < size(); i++) {
                get(i).scale(cx, cy, scale);
            }
        }

        void move(float x1, float y1, float x0, float y0, float scale) {
            for (int i = 0; i < size(); i++) {
                get(i).move(x1, y1, x0, y0, scale);
            }
        }
    }

    class Selection
    {
        class Row extends ArrayList<Integer> { }
        Row[] rows;
        Points polyDest;
        Lines lines = new Lines();
        Paint paint;
        Rect rectSrc;
        Rect rectBlend;
        RectF rectDest;
        Canvas canvasBlend;
        Bitmap bitmapSrc;
        Bitmap bitmapBlend;
        Bitmap bitmapDest;
        Canvas canvasDest;
        float scale;
        float brushSize;
        int brushStrokes;
        float brushCurl;
        float brushWidth;
        float brushLength;
        ArrayList<Integer> brushColors;

        Selection() {
            brushWidth = 0.1f;
            brushSize = 32;
            brushStrokes = 1;
            brushCurl = 2;
            brushLength = 16;
            brushColors = new ArrayList<Integer>();
            brushColors.add(Color.BLACK);
            scale = 1.0f;
            polyDest = new Points();
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(S.color_selected);
            paint.setStrokeWidth(0.4f);
            rectDest = new RectF();
            rectDest.top = rectDest.left = Float.MAX_VALUE;
            rectDest.bottom = rectDest.right = Float.MIN_VALUE;
        }

        void drawLine(Canvas canvas, float x, float y, float dx, float dy, float curl, int n) {
            int s = (int)(brushLength / 4.0f + 0.5f);
            float dl = brushLength / s;
            float x2 = x;
            float y2 = y;
            for (int i = 0; i < s; i++) {
                x2 += dx * dl;
                y2 += dy * dl;
                canvas.drawLine(x, y, x2, y2, lines.paint);
                float a = (0.5f - random(n++)) * curl;
                float cosa = (float)Math.cos(a);
                float sina = (float)Math.sin(a);
                x = dx; y = dy;
                dx = cosa * x - sina * y;
                dy = sina * x + cosa * y;
                x = x2; y = y2;
            }
        }

        void drawLines(Canvas canvas) {
            lines.paint.setStrokeWidth(brushWidth);
            float curl = brushCurl * (float)(Math.PI * 0.1);
            int n = 0;
            for (int i = 0; i < lines.size(); i++) {
                Line line = lines.get(i);
                for (int j = 1; j < line.size(); j++) {
                    PointF p1 = line.get(j-1);
                    PointF p2 = line.get(j);
                    float dx = p2.x - p1.x;
                    float dy = p2.y - p1.y;
                    float dl = (float)Math.sqrt(dx * dx + dy * dy);
                    if (dl == 0) continue;
                    dx /= dl; dy /= dl;
                    int ns = n;
                    for (int s = 0; s < brushStrokes; s++) {
                        float x = p1.x + (0.5f - random(ns++)) * line.brushSize;
                        float y = p1.y + (0.5f - random(ns++)) * line.brushSize;
                        //if (!inPoly((int) x, (int) y))
                        //	continue;
                        lines.paint.setColor(brushColors.get(ns % brushColors.size()));
                        drawLine(canvas, x, y, dx, dy, curl, ns);
                    }
                    n++;
                }
            }
        }

        void onDraw(Canvas canvas) {
            if (bitmapBlend != null && rectDest != null) {
                canvas.drawBitmap(bitmapDest, null, rectDest, null);
                if (selection == this)
                    canvas.drawRect(rectDest, paint);
            } else if (selection == this && polyDest.size() > 1) {
                for (int i = 0; i < polyDest.size(); i++) {
                    PointF p1 = polyDest.get(i);
                    PointF p2 = polyDest.get(i < polyDest.size()-1 ? i+1 : 0);
                    canvas.drawLine(p1.x, p1.y, p2.x, p2.y, paint);
                }
            }
        }
        void blend(int x, int y, float alpha) {
            if (x >= 0 && y >= 0 && x < bitmapBlend.getWidth() && y < bitmapBlend.getHeight()) {
                int pixel = bitmapSrc.getPixel(x, y);
                bitmapBlend.setPixel(x, y, (((int) (alpha * 255) << 24) | (pixel & 0xFFFFFF)));
            }
        }

        void blend(float x1, float y1, float x2, float y2, float alpha) {
            if (!created())
                create(scale);

            x1-=rectDest.left;
            x2-=rectDest.left;
            y1-=rectDest.top;
            y2-=rectDest.top;
            float scale = bitmapBlend.getWidth()/ rectDest.width();
            x1*=scale;
            y1*=scale;
            x2*=scale;
            y2*=scale;

            float dy = y2 - y1;
            float dx = x2 - x1;
            if (Math.abs(dx) > Math.abs(dy)) {
                if (x2 > x1) {
                    for (int x = (int)x1 ; x <= x2; x++) {
                        int y = (int) (y1 + (dy * (x - x1)) / dx);
                        blend(x, y, alpha);
                    }
                } else {
                    for (int x = (int)x2 ; x <= x1; x++) {
                        int y = (int) (y1 + (dy * (x - x1)) / dx);
                        blend(x, y, alpha);
                    }
                }
            }
            else {
                if (y2 > y1) {
                    for (int y = (int)y1 ; y <= y2 ; y++) {
                        int x = (int) (x1 + (dx * (y - y1)) / dy);
                        blend(x, y, alpha);
                    }
                } else {
                    for (int y = (int)y2 ; y <= y1 ; y++) {
                        int x = (int) (x1 + (dx * (y - y1)) / dy);
                        blend(x, y, alpha);
                    }
                }
            }

            update();
        }

        boolean created() {
            return rectSrc != null;
        }

        void create() {
            create(scale);
        }

        void paint() {
            if (!created())
                create();
            lines.add(new Line());
        }

        void paint(float x, float y) {
            Line line = lines.get(lines.size()-1);
            line.brushSize = brushSize;
            x -= rectDest.left;
            y -= rectDest.top;
            float scale = bitmapBlend.getWidth()/ rectDest.width();
            x*=scale;
            y*=scale;
            line.add(new PointF(x, y));
            update();
        }


        void add(float x, float y) {
            if (rectDest.left > x) rectDest.left = x;
            if (rectDest.top > y) rectDest.top = y;
            if (rectDest.right < x) rectDest.right = x;
            if (rectDest.bottom < y) rectDest.bottom = y;
            PointF p = new PointF(x, y);
            polyDest.add(p);
        }

        void update() {
            if (rectSrc == null) {
                create(scale);
            }
            else {
                Rect r = screenToImage(rectDest);
                canvasDest.drawBitmap(WebImageEditor.this.bitmap, r, rectBlend, null);
                canvasDest.drawBitmap(bitmapBlend, 0, 0, null);
                drawLines(canvasDest);
            }
        }

        void create(float scale){
            if (rectSrc == null)
                rectSrc = screenToImage(rectDest);

            if (scale != 1.0f) {
                float cx = rectDest.centerX();
                float cy = rectDest.centerY();
                lines.scale(cx-rectDest.left, cy-rectDest.top, scale);
                rectDest.left = cx + (rectDest.left - cx) * scale;
                rectDest.top = cy + (rectDest.top - cy) * scale;
                rectDest.right = cx + (rectDest.right - cx) * scale;
                rectDest.bottom = cy + (rectDest.bottom - cy) * scale;
                polyDest.scale(cx, cy, scale);
            }

            rectBlend = screenToImage(rectDest);
            Point offset = new Point(rectBlend.left, rectBlend.top);
            rectBlend.offset(-rectBlend.left, -rectBlend.top);
            bitmapBlend = Bitmap.createBitmap(rectBlend.width(), rectBlend.height(), Bitmap.Config.ARGB_8888);
            canvasBlend = new Canvas(bitmapBlend);
            canvasBlend.drawBitmap(WebImageEditor.this.bitmap, rectSrc, rectBlend, null);
            bitmapSrc = Bitmap.createBitmap(bitmapBlend);
            bitmapDest = Bitmap.createBitmap(rectBlend.width(), rectBlend.height(), Bitmap.Config.ARGB_8888);
            canvasDest = new Canvas(bitmapDest);

            rows = new Row[bitmapBlend.getWidth()];
            for (int i = 0; i < rows.length; i++)
                rows[i] = new Row();

            for (int i = 0; i < polyDest.size(); i++) {
                Point p1 = screenToImage(polyDest.get(i));
                Point p2 = screenToImage(i < polyDest.size() - 1 ? polyDest.get(i+1) : polyDest.get(0));
                p1.x -= offset.x;
                p1.y -= offset.y;
                p2.x -= offset.x;
                p2.y -= offset.y;
                float dx = p2.x - p1.x;
                float dy = p2.y - p1.y;
                if (p2.x > p1.x){
                    for (int x = p1.x; x < p2.x; x++) {
                        if (x < 0 || x >= rows.length)
                            continue;
                        rows[x].add(p1.y + (int) (dy * (float) (x - p1.x) / dx));
                    }
                } else {
                    for (int x = p2.x; x < p1.x; x++) {
                        if (x < 0 || x >= rows.length)
                            continue;
                        rows[x].add(p1.y + (int) (dy * (float) (x - p1.x) / dx));
                    }
                }
            }
            for (int x = 0; x < bitmapBlend.getWidth(); x++) {
                for(int y = 0; y < bitmapBlend.getHeight(); y++) {
                    if (!inPoly(x, y)) {
                        bitmapBlend.setPixel(x, y,  0);
                    }
                }
            }
            update();
        }

        boolean inPoly(int x, int y) {
            if (x >= 0 && x < rows.length) {
                Row r = rows[x];
                int count = 0;
                for (int i = 0; i < r.size(); i++) {
                    if (y <= r.get(i))
                        count++;
                }
                return count % 2 == 1;
            }
            return false;
        }

        void offset(float dx, float dy) {
            rectDest.offset(dx, dy);
            polyDest.offset(dx, dy);
        }

        void move(float x1, float y1, float x0, float y0, float scale) {
            rectDest.left = x1 + (rectDest.left - x0) * scale;
            rectDest.right = x1 + (rectDest.right - x0) * scale;
            rectDest.top = y1 + (rectDest.top - y0) * scale;
            rectDest.bottom = y1 + (rectDest.bottom - y0) * scale;
            polyDest.move(x1, y1, x0, y0, scale);
        }

        boolean contains(float x, float y) {
            return rectDest.contains(x, y);
        }

        void scale(float step) {
            if (step == 1.0f)
                scale = step;
            else
                scale *= step;
            create(step);
        }

        void apply(Canvas canvas) {
            if (bitmapBlend != null) {
                Rect r = screenToImage(rectDest);
                canvas.drawBitmap(bitmapDest, null, r, null);
            }
        }

        boolean undo() {
            if (lines.size() > 0) {
                lines.remove(lines.size() - 1);
                update();
                return true;
            }
            return false;
        }

    }

    class EditAction extends Action {
        @Override
        int getColor() { return action == this ? S.color_visited : S.color_link; }
        @Override
        void onClick(float x, float y) { action = this; }
    }
    class SelectAction extends EditAction {
        @Override
        String getName() {return "select";}
    }
    class BlendAction extends EditAction {
        @Override
        String getName() {return String.format("blend %2.1f", blend);}
        @Override
        void onClick(float x, float y) {
            String name = getName();
            if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(dot)))) {
                blend += 0.125;
                if (blend > 1.0f) blend = 0.0f;
            }
            else if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(space)))) {
                blend -= 0.125;
                if (blend < 0) blend = 1.0f;
            }
            super.onClick(x, y);
        }
    }
    class ScaleAction extends Action {
        @Override
        String getName() {return selection != null ? String.format("scale %2.1f", selection.scale) :"scale";}
        @Override
        void onClick(float x, float y) {
            if (selection != null) {
                String name = getName();
                if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(dot))))
                    selection.scale(scale_step_8);
                else if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(space))))
                    selection.scale(1.0f / scale_step_8);
                else
                    selection.scale(1.0f);
            }
            else WebView.this.scale(rect.centerX(), rect.centerY() , bitmap.getWidth() / width);
        }
    }
    class RotateAction extends Action {
        @Override
        String getName() {return "rotate";}
        @Override
        void onClick(float x, float y) { rotateAngle += x > actions.rect.left + actions.rect.width() / 2 ? 22.5f :-22.5f ; }
    }
    class BrushAction extends EditAction {
        @Override
        String getName() {
            String name = "brush";
            if (selection != null)
                name += String.format(" %2.1f", selection.brushWidth * 10.0f);
            return name;
        }
        @Override
        void onClick(float x, float y) {
            if (selection == null)
                return;
            String name = getName();
            if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(dot)))) {
                selection.brushWidth *= scale_step_4;
                updateSelection();
            }
            else if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(space)))) {
                selection.brushWidth /= scale_step_4;
                updateSelection();
            }
            else
                super.onClick(x, y);
        }
    }
    class SizeAction extends EditAction {
        @Override
        String getName() {
            if (selection == null)
                return "size";
            return String.format("size %2.1f" , selection.brushSize);
        }
        @Override
        void onClick(float x, float y) {
            if (selection == null)
                return;
            String name = getName();
            if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(dot)))) {
                selection.brushSize *= scale_step_2;
                updateSelection();
            }
            else {
                selection.brushSize /= scale_step_2;
                updateSelection();
            }
        }
    }
    class StrokesAction extends EditAction {
        @Override
        String getName() {
            if (selection == null)
                return "strokes";
            return String.format("strokes %d" , selection.brushStrokes);
        }
        @Override
        void onClick(float x, float y) {
            if (selection == null)
                return;
            String name = getName();
            if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(space)))) {
                selection.brushStrokes++;
                updateSelection();
            }
            else {
                selection.brushStrokes--;
                updateSelection();
            }
        }
    }
    class CurlAction extends EditAction {
        @Override
        String getName() {
            if (selection == null)
                return "curl";
            return String.format("curl %2.1f" , selection.brushCurl);
        }
        @Override
        void onClick(float x, float y) {
            if (selection == null)
                return;
            String name = getName();
            if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(dot)))) {
                selection.brushCurl *= scale_step_8;
                updateSelection();
            }
            else {
                selection.brushCurl /= scale_step_8;
                updateSelection();
            }
        }
    }
    class PaintAction extends EditAction {
        @Override
        String getName() {
            if (selection == null)
                return "paint";
            return String.format("paint %2.1f" , selection.brushLength);
        }
        @Override
        void onClick(float x, float y) {
            if (selection != null){
                String name = getName();
                if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(dot)))) {
                    selection.brushLength *= scale_step_4;
                    updateSelection();
                }
                else if (x > actions.rect.left + actions.paint.measureText(name.substring(0, name.indexOf(space)))) {
                    selection.brushLength /= scale_step_4;
                    updateSelection();
                }
            }
            super.onClick(x, y);
        }
    }
    class SaveAction extends EditAction {
        @Override
        String getName() {return "save";}
        @Override
        void onClick(float x, float y) {
            if (selections.size() > 0){
                for (int i = 0; i < selections.size(); i++)
                    selections.get(i).apply(canvas);
                selections.clear();
                selection = null;
            }
            else {
                toast(saveBitmap(bitmap, S.output_folder, getFileNameFromTime()));
                super.onClick(x, y);
            }
        }
    }
    class UndoAction extends EditAction {
        @Override
        String getName() {return "undo";}
        @Override
        void onClick(float x, float y) {
            if (selection != null) {
                if (!selection.undo()) {
                    selections.remove(selection);
                    selection = null;
                }
            }
//					else {
//						pageUrl = file + S.download_folder;
//						localFiles = new ArrayList<String>();
//						loadLocalFiles(localFiles);
//						String last = null;
//						for (int i = 0; i < localFiles.size(); i++) {
//							if (S.isImage(localFiles.get(i))) {
//								last = localFiles.get(i);
//							}
//						}
//						if (last != null) {
//							Bitmap image = BitmapFactory.decodeFile(S.download_folder + last);
//							if (image != null) {
//								canvas.drawBitmap(image, 0, 0, null);
//								File file = new File(S.download_folder + last);
//								file.delete();
//								super.onClick(x, y);
//							}
//						}
//					}
        }
    }
    class CloseAction extends Action {
        @Override
        String getName() {return "close";}
        @Override
        void onClick(float x, float y) { Actions.active = null; }
    }
    class EditActions extends Actions {
        EditActions() {
            items.add(new SelectAction());
            items.add(new PaintAction());
            items.add(new BrushAction());
            items.add(new SizeAction());
            items.add(new CurlAction());
            items.add(new StrokesAction());
            items.add(new BlendAction());
            items.add(new ScaleAction());
            items.add(new RotateAction());
            items.add(new SaveAction());
            items.add(new UndoAction());
            items.add(new CloseAction());
            action = items.get(0);
        }
        @Override
        boolean closeOnClick() {
            return false;
        }
        @Override
        boolean closeOnBack() {
            return false;
        }
        @Override
        boolean onBack() { return false; }
    }

    WebImageEditor(float x, float y, WebImage image){
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);
        width = image.width;
        height = image.height;
        rect = image.rect;
        bitmap = image.bitmap;
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        if (S.image_max_size > bitmap.getByteCount()) {
            double scale = Math.sqrt(S.image_max_size / bitmap.getByteCount());
            w = (int)(bitmap.getWidth() * scale);
            h = (int)(bitmap.getHeight() * scale);
        }
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        canvas.drawBitmap(image.bitmap, null, new Rect(0,0, w, h), null);
        actions = new EditActions();
        Actions.active = actions;
        Actions.active.show(x, y);
    }


    void updateSelection() {
        if (selection != null)
            selection.update();
    }

    @Override
    void onDraw(Canvas canvas) {
        canvas.drawBitmap(bitmap, null, rect, null);
        for(int i = 0 ; i < selections.size(); i++)
            selections.get(i).onDraw(canvas);
    }

    @Override
    boolean scale(float scale) {
        //if (actions != Actions.active || action instanceof MoveAction ) {
        return super.scale(scale);
        //}
        //return false;
    }

    @Override
    void move(float left, float top, float right, float bottom) {
        float w = rect.width();
        float l = rect.left;
        float t = rect.top;
        super.move(left, top, right, bottom);
        if (selections.size() > 0) {
            float scale = (right - left) / w;
            for (int i = 0; i < selections.size(); i++) {
                selections.get(i).move(left, top, l, t, scale);
            }
        }
    }

    @Override
    boolean offset(float x, float y, float dx, float dy) {
        boolean hit = false;
        if (x0 != x || y0 != y) {
            hit = true;
            x1 = x0 = x;
            y1 = y0 = y;
        }

        x2 = x1 + dx;
        y2 = y1 + dy;

        boolean insideSelection = selection != null && selection.contains(x, y);

        if (action instanceof PaintAction && insideSelection) {
            if (hit) {
                selection.paint();
                selection.paint(x1, y1);
            }
            selection.paint(x2, y2);
        }
        else if (action instanceof BlendAction && insideSelection) {
            selection.blend(x1, y1, x2, y2, blend);
        }
        else if (action instanceof BrushAction) {
            if (selection != null) {
                if (hit) {
                    selection.brushColors.clear();
                    Point p = screenToImage(x1, y1);
                    selection.brushColors.add(bitmap.getPixel(p.x, p.y));
                }
                Point p = screenToImage(x2, y2);
                selection.brushColors.add(bitmap.getPixel(p.x, p.y));
                updateSelection();
            }
        }
        else {
            if (action instanceof SelectAction) {
                if (selection == null) {
                    selection = new Selection();
                    selections.add(selection);
                    selection.add(x1, y1);
                }
                else if (selection.created()) {
                    if (selection.contains(x, y))
                        selection.offset(dx, dy);
                    return false;
                }
                selection.add(x2, y2);
            }
            else {
                for (int i = 0 ; i < selections.size(); i++)
                    selections.get(i).offset(dx, dy);
                return super.offset(x, y, dx, dy);
            }
        }

        x1 = x2;
        y1 = y2;

        return false;
    }

    @Override
    void onClick(float x, float y) {
        if (Actions.active != actions) {
            Actions.active = actions;
            Actions.active.show(x, y);
        } else {
            if (selection != null && !selection.created()) {
                selection.create();
            }
            else {
                selection = null;
                for (int i = 0; i < selections.size(); i++) {
                    selection = selections.get(i);
                    if (selection.contains(x, y))
                        break;
                    else
                        selection = null;
                }
            }
        }
    }

    Rect screenToImage(RectF r) {
        Point lt = screenToImage(r.left, r.top);
        Point rb = screenToImage(r.right, r.bottom);
        return new Rect(lt.x, lt.y, rb.x, rb.y);
    }

    Point screenToImage(PointF p) {
        return screenToImage(p.x, p.y);
    }

    Point screenToImage(float x, float y) {
        x -= rect.left;
        y -= rect.top;
        if ((int)width != bitmap.getWidth()) {
            float scale = bitmap.getWidth() / width;
            x *= scale;
            y *= scale;
        }
        if (rotateAngle != 0) {
            double rad = rotateAngle * (-Math.PI / 180.0);
            double sin = Math.sin(rad);
            double cos = Math.cos(rad);
            double cx = bitmap.getWidth() / 2;
            double cy = bitmap.getHeight() / 2;
            double dx = x - cx;
            double dy = y - cy;
            x = (float)(dx * cos - dy * sin + cx);
            y = (float)(dy * cos + dx * sin + cy);
        }
        return new Point((int)(x+0.5f), (int)(y+0.5f));
    }


//			RectF imageToScreen(Rect r) {
//				PointF lt = imageToScreen(r.left, r.top);
//				PointF rb = imageToScreen(r.right, r.bottom);
//				return new RectF(lt.x, lt.y, rb.x, rb.y);
//			}
//
//
//			PointF imageToScreen(Point p) {
//				return imageToScreen(p.x, p.y);
//			}
//
//			PointF imageToScreen(int x, int y) {
//				PointF p = new PointF(x, y);
//				if ((int)width != bitmap.getWidth()) {
//					float scale = width / bitmap.getWidth();
//					p.x *= scale;
//					p.y *= scale;
//				}
//				p.x += rect.left;
//				p.y += rect.top;
//				return p;
//			}

}
*/
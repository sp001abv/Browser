package com.sp.browser;

import java.io.File;

class LocalFile extends WebTextEdit {

    LocalFile(String name, String url) {
        super(S.isLocalFolder(url) , S.action_text_size);
        href = url;
        setText(name);
        height = paint.getTextSize();
    }

    @Override
    void onClick(float x, float y) {
        if (sel1 >= 0 && sel2 > sel1)
            S.fileActions.show(this, x, y);
        else if (S.isLocalFolder(href))
            Pages.active().loadLocalFolder(href);
        else
            super.onClick(x, y);
    }

    @Override
    void onDoubleClick(float x, float y) {
        S.openFileAsActions.show(href, true, x, y);
    }

    void rename() {
        startEditing();
    }

    @Override
    public void stopEditing() {
        super.stopEditing();
        String path = S.getLocalPath(href);
        File file = new File(path);
        String name = file.getName();
        if (!name.equals(text)) {
            boolean folder = S.isLocalFolder(href);
            String url = folder ? S.getParentFolder(href) : S.getFolder(href);
            path = S.getLocalPath(url);
            if (file.renameTo(new File(path + text))) {
                href = url + text;
                if (folder)
                    href += C.slash;
            }
            else
                text = name;
        }
    }

    void open(float x, float y) {
        if (S.isLocalFolder(href)) {
            S.output_folder = S.getLocalPath(href);
            deselect();
        }
        else
            S.openFileAsActions.show(href, false, x, y);
    }
}

package com.sp.browser;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;


class VideoSurfaceView extends GLSurfaceView implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {

    interface Callback {
        void onDrawFrame( );
        void onSurfaceCreated();
        void onError(String error);
    }

    Callback mCallback;
    private boolean updateSurface = false;
    private GLSurfaceTextureRenderer mSurfaceTextureRenderer;
    private GLProgram mSurfaceTextureProgram;
    private GLProgram mBitmapTextureProgram;
    private int mVideoWidth;
    private int mVideoHeight;
    private float mAspectRatio;
    private float mZoom;
    private int mRotateAngle;
    public boolean render;


    VideoSurfaceView(Context context, Callback callback) {
        super(context);
        mCallback = callback;
        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(false);
        setRenderer(this);
        render = true;
        mZoom = 1;
        mAspectRatio = 0;
    }

    void release() {
        onPause();
    }

    SurfaceTexture getSurfaceTexture() {
        return mSurfaceTextureRenderer.mSurfaceTexture;
    }

    GLBitmapTextureRenderer createBitmapRenderer(int width, int height, boolean transparent) {
        return new GLBitmapTextureRenderer(mBitmapTextureProgram, width, height, transparent);
    }

    Bitmap copyFrame() {
        int width = getWidth();
        int height = getHeight();
        ByteBuffer bb = ByteBuffer.allocateDirect(width * height * 4);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        GLES20.glReadPixels(0, 0, width, height, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, bb);
        bb.rewind();
        byte[] tmp = new byte[width * 4];
        for (int i = 0; i < height / 2; i++) {
            bb.get(tmp);
            System.arraycopy(bb.array(), bb.limit() - bb.position(), bb.array(), bb.position() - width * 4, width * 4);
            System.arraycopy(tmp, 0, bb.array(), bb.limit() - bb.position(), width * 4);
        }
        bb.rewind();
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(bb);
        return bitmap;
    }

    public void onDrawFrame(GL10 glUnused) {
        try {
            synchronized (this){
                if (!updateSurface){
                    wait(250);
                }
                if (updateSurface) {
                    mSurfaceTextureRenderer.mSurfaceTexture.updateTexImage();
                    updateSurface = false;
                }
            }
            if (render) {
                GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
                GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT | GLES20.GL_COLOR_BUFFER_BIT);
                mSurfaceTextureRenderer.render();
            }
            mCallback.onDrawFrame();
        } catch (Exception e){
            mCallback.onError(e.getMessage());
        }
    }

    public void onFrameAvailable(SurfaceTexture surface) {
        synchronized(this){
            if (!updateSurface) {
                updateSurface = true;
                notifyAll();
            }
        }
    }

    public void onSurfaceChanged(GL10 glUnused, int width, int height) {
        adjustVideo();
    }

    void setVideoSize(int width, int height) {
        mVideoWidth = width;
        mVideoHeight = height;
        adjustVideo();
    }

    void setAspectRatio(float aspectRatio) {
        mAspectRatio = aspectRatio;
        adjustVideo();
    }

    void setZoom(float zoom) {
        mZoom = zoom;
        adjustVideo();
    }

    void setRotateAngle(int angle) {
        mRotateAngle = angle;
        adjustVideo();
    }

    private void adjustVideo() {
        if ( mVideoWidth == 0 || mVideoHeight == 0)
            return;
        float videoHeight = mVideoHeight;
        float videoWidth =  mAspectRatio == 1 ? mVideoWidth : videoHeight * mAspectRatio;

        boolean horizontal = mRotateAngle % 180 == 0;
        float width = horizontal ? getWidth() : getHeight();
        float height = horizontal ? getHeight() : getWidth();
        if (videoWidth == 0) {
            videoWidth = mVideoWidth;
            videoHeight = mVideoHeight;
        } else {
            float scaleWidth = width / videoWidth;
            float scaleHeight = height / videoHeight;
            float scale = scaleWidth < scaleHeight ? scaleWidth : scaleHeight;
            videoWidth *= scale;
            videoHeight *= scale;
        }
        mSurfaceTextureRenderer.scale(mZoom * videoWidth / width, mZoom * videoHeight / height);
        mSurfaceTextureRenderer.rotate(mRotateAngle);
    }

    public void onSurfaceCreated(GL10 glUnused, EGLConfig config) {
        mSurfaceTextureProgram = new GLProgram(GLSurfaceTextureRenderer.VERTEX_SHADER, GLSurfaceTextureRenderer.FRAGMENT_SHADER);
        mSurfaceTextureRenderer = new GLSurfaceTextureRenderer(mSurfaceTextureProgram);
        mSurfaceTextureRenderer.mSurfaceTexture.setOnFrameAvailableListener(this);

        mBitmapTextureProgram = new GLProgram(GLBitmapTextureRenderer.VERTEX_SHADER, GLBitmapTextureRenderer.FRAGMENT_SHADER);

        mCallback.onSurfaceCreated();

        synchronized(this) {
            updateSurface = false;
        }
    }
}

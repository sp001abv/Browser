package com.sp.browser;

class WebInput implements IWebInput {
    String name;
    String value;
    WebInput(String name, String value) {
        this.name = name;
        this.value = value;
    }
    @Override
    public String getName(){
        return name;
    }
    @Override
    public String getValue(){
        return value;
    }
}

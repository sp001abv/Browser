package com.sp.browser;

class WebInput extends WebItem {
    String text;
    WebInput(){
        text = null;
    }
    WebInput(String name, String value) {
        href = name;
        text = value;
    }
    String getName(){
        return href;
    }
    String getValue(){
        return text!=null?text:C.empty;
    }
}

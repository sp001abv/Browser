
package com.sp.browser;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

class WebServer extends Thread {
    private ServerSocket serverSocket;

    final static String OKAY = "200";
    final static String PARTIAL_CONTENT = "206";
    final static String BAD_REQUEST = "400";
    final static String PAGE_NOT_FOUND = "404";
    
    public static String WebDir ="/mnt/";
    public static String ServerIp ="127.0.0.1";
    public static int ServerPort = 8080;
    public static boolean isStarted = false;
    public static String LastError;

    public WebServer() throws IOException {
        
        InetAddress address = InetAddress.getByName(ServerIp);
        serverSocket = new ServerSocket(ServerPort, 100, address);
        serverSocket.setSoTimeout(5000);  //set timeout for listener
    }

    @Override
    public void run() {
        while (isStarted) {
            try {
                Socket socket = serverSocket.accept();
                new Client(socket).start();
            }
            catch (SocketTimeoutException s) { }
            catch (Exception e) {
                LastError = e.getMessage();
            }
        }
        try {
            serverSocket.close();
        }
        catch (Exception e) {
            LastError = e.getMessage();
        }
    }

    static boolean startStop() {
        try{
            if (isStarted){
                isStarted = false;
            }
            else {
                new WebServer().start();
                isStarted = true;
            }

        } catch (Exception e) {
            LastError = e.getMessage();
            return false;
        }
        return true;
    }


     class Client extends Thread {

        private Socket socket;

        public Client(Socket clientSocket) {
            socket = clientSocket;
        }

        @Override
        public void run() {
            try {
                InputStream input = socket.getInputStream();
                OutputStream output = socket.getOutputStream();
                socket.setSoTimeout(5000);
                socket.setKeepAlive(false);
                byte[] buffer = new byte[1500];
                int size;
                if ((size = input.read(buffer)) > 0) {
                    String req = new String(buffer, 0, size, C.utf8);
                    //log(req);
                    String[] header = req.split("\\r?\\n");
                    final String[] request = header[0].split(" ");
                    if (request.length == 3) {
                        long range1 = -1;
                        long range2 = range1;
                        for (int h = 1; h < header.length; h++) {
                            String[] values = header[h].split(":");
                            String name = values[0].trim();
                            if (name.equalsIgnoreCase("Range")) {
                                if (values.length > 1) { String[] v = values[1].split("=");
                                    String r = v.length > 1 ? v[1] : v[0];
                                    v = r.split("-");
                                    range1 = Long.parseLong(v[0]);
                                    if (v.length > 1)
                                        range2 = Long.parseLong(v[1]);
                                }
                            }
                            else if (name.equalsIgnoreCase("Connection")) {
                                if (values.length > 1 && values[1].trim().equalsIgnoreCase("Close"))
                                    socket.setKeepAlive(false);
                            }
                        }
                        final String location = request[1].trim();
                        String url = S.decodeUrl(location);
                        if (url.length() > 1) url = url.substring(1);
                        if (url.endsWith("/")) {
                            byte[] content = getDirectoryContent(url);
                            output.write(getHeader(OKAY, "text/html", content.length,
                                    range1, range2, socket.getKeepAlive(), false));
                            output.write(content);
                        } else {
                            if (url.startsWith(C.http)) {
                                output.write(getHeader(OKAY, getContentType(url)));
                                Pages.active().proxyUrl(url, output);
                            }
                            else {
                                if (!S.isContainerFile(url))
                                    url = WebDir + url;

                                FileReader fileReader = new FileReader(url);

                                output.write(getHeader(range1 >= 0 ? PARTIAL_CONTENT : OKAY,
                                        getContentType(url), fileReader.size,
                                        range1, range2, socket.getKeepAlive(), true));

                                readFile(fileReader, output, range1, range2);
                            }
                        }
                    }
                    else {
                        output.write(getHeader(BAD_REQUEST));
                    }
                }
            } catch (Exception e) {
                LastError = e.getMessage();
            }
            try {
                socket.close();
            }
            catch (Exception e) {
                LastError = e.getMessage();
            }
            socket = null;
        }
    }

    static void log(String s) {
        try {
            RandomAccessFile f = new RandomAccessFile("/mnt/sdcard/log.txt", "rw");
            if (f.length()>0)
                f.seek(f.length());
            f.writeChars(s);
            f.close();
        } catch (Exception e) {

        }

    }

    static byte[] getHeader(String status) {
        return getHeader(status, null);
    }

    static byte[] getHeader(String status, String contentType) {
        return getHeader(status, contentType, 0, -1, -1 ,false, false);
    }

    static byte[] getHeader(String status, String contentType, long length, long range1,  long range2, boolean keep, boolean acceptRanges) {
        StringBuilder sb = new StringBuilder();
        sb.append("HTTP/1.1 ").append(status).append(" \r\n");
        if (contentType != null) {
            if (acceptRanges)
                appendKeyValue(sb, "Accept-Ranges", "bytes");
            if (contentType != null)
                appendKeyValue(sb, "Content-Type", contentType);
            if (status.equals(PARTIAL_CONTENT)) {
                appendKeyValue(sb, "Content-Range", "bytes "
                                + range1 + "-"
                                + (range2 > range1 ? range2 : length-1)
                                + "/" + length);
                length = range2 > 0 ? range2 - range1 : length - range1;
            }
            if (length > 0)
                appendKeyValue(sb, "Content-Length", String.valueOf(length));
        }
        appendKeyValue(sb, "Connection", keep ? "Keep-Alive" : "Close");
        sb.append("\r\n");
        String s = sb.toString();
        //log(s);
        return s.getBytes();
    }

    static void readFile(FileReader fr, OutputStream output, long range1, long range2){
        try {
            if (range1 > 0)
                fr.seek(range1);
            byte[] buffer = new byte[512];
            int size;
            while ((size = fr.read(buffer)) > 0) {
                output.write(buffer, 0, size);
                if (range2 > 0) {
                    range1 += size;
                    if (range1 >= range2)
                        break;
                }
            }
        }
        catch(Exception e){
            LastError = e.getMessage();
        }
        if (fr != null) {
            try {
                fr.close();
            }
            catch (IOException e) {
                LastError = e.getMessage();
            }
        }
    }

    static String encode(String url) {
        return S.encodeUrl(url, C.utf8);
    }


    static void appendDirectoryContent(StringBuilder sb, String path, boolean directory) {
        ArrayList<String> files = new ArrayList<>();
        S.loadLocalFilesSorted(files, path, directory);
        for (String name : files) {
            sb.append("<a href=\"");
            sb.append(encode(name));
            if (directory)
                sb.append("/");
            sb.append("\" >");
            if (directory)
                sb.append("<b>");
            sb.append(name);
            if (directory)
                sb.append("</b>");
            sb.append("<br />");
        }
    }

    static byte[] getDirectoryContent(String path) {
        StringBuilder sb = new StringBuilder();
        sb.append("<html>");
        sb.append("<body>");
        sb.append("<h2>");
        sb.append("<br />");
        path = WebDir + path;
        appendDirectoryContent(sb, path, true);
        appendDirectoryContent(sb, path, false);
        sb.append("</body>");
        sb.append("</html>");
        return sb.toString().getBytes();
    }

    static String getContentType(String path) {
        String ext = S.getExt(path);
        if (S.isVideo(path))
            return "video/" + ext;
        if (S.isImage(path))
            return "image/" + ext;
        if (S.isText(path)) {
            if (S.isExt(ext, "html"))
                return "text/html";
            return "text/plain";
        }
        return "application/octet-stream";
    }

    static void appendKeyValue(StringBuilder sb, String key, String value) {
        sb.append(key).append(": ").append(value).append("\r\n");
    }
}

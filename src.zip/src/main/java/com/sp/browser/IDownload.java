package com.sp.browser;

import java.io.InputStream;
import java.net.URLConnection;

interface IDownload {
    void download();
    void onResponse(URLConnection connection, InputStream inputStream) throws Exception;
    void onError(URLConnection connection, String error);
}

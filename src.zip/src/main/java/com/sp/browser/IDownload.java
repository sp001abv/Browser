package com.sp.browser;

import java.io.InputStream;
import java.net.URLConnection;

interface IDownload {
    void download(WebPage page);
    void onResponse(WebPage page, URLConnection connection, InputStream inputStream) throws Exception;
    void onError(WebPage page, URLConnection connection, String error);
}

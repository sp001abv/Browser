package com.sp.browser;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

class FileReader
{
    ZipFile zipFile;
    InputStream zipInput;
    ContainerInput containerInput;
    RandomAccessFile fileInput;
    String name;
    String path;
    long size;

    FileReader(String url) throws Exception  {
        if (S.isZipEntry(url)) {
            String[] s = S.getFilePathAndEntryName(url, C.zip);
            path = s[0]; name = s[1];
            zipFile = new ZipFile(path);
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while ( entries.hasMoreElements() ) {
                ZipEntry ze = entries.nextElement();
                if (name.equals(ze.getName())) {
                    zipInput = zipFile.getInputStream(ze);
                    size = ze.getSize();
                    break;
                }
            }
        }
        else if (S.isContainerFile(url)) {
            String[] s = S.getFilePathAndEntryName(url, ContainerOutput.EXT);
            path = s[0]; name = s[1];
            containerInput = new ContainerInput(path);
            if (containerInput.find(name))
                size = containerInput.fileSize;
        }
        else {
            size = new File(url).length();
            fileInput = new RandomAccessFile(url, "r");
        }
    }

    void seek(long offset) throws IOException {
        if (fileInput !=null)
            fileInput.seek(offset);
        else if (containerInput != null)
            containerInput.seek(offset);
        else if (zipInput != null) {
            zipInput.reset();
            zipInput.skip(offset);
        }
    }

    int read(byte[] buffer) throws IOException {
        if (zipInput != null)
            return zipInput.read(buffer);
        if (containerInput != null)
            return containerInput.read(buffer);
        return fileInput.read(buffer);
    }

    void close() throws IOException {
        if (zipInput != null) {
            zipInput.close();
            zipFile.close();
        }
        if (containerInput != null)
            containerInput.close();
        if (fileInput != null)
            fileInput.close();
    }
}

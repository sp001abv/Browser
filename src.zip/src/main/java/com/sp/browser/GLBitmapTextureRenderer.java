package com.sp.browser;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.opengl.GLES20;
import android.opengl.GLUtils;

class GLBitmapTextureRenderer extends GLTextureRenderer {

    static final String VERTEX_SHADER =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 aPosition;" +
                    "attribute vec4 aTexture;" +
                    "varying vec2 vTexture;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "  vTexture = aTexture.xy;" +
                    "}";

    static final String FRAGMENT_SHADER =
            "precision mediump float;" +
                    "uniform sampler2D sTexture;" +
                    "varying vec2 vTexture;" +
                    "void main() {" +
                    "  gl_FragColor = texture2D(sTexture, vTexture);" +
                    "}";


    private Bitmap mBitmap;
    private Canvas mCanvas;
    private boolean mTransparent;
    private boolean mUpdate;

    GLBitmapTextureRenderer(GLProgram GLProgram, int width, int height, boolean transparent){
        super(GLES20.GL_TEXTURE_2D, GLProgram);
        mBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);
        mTransparent = transparent;
    }

    Canvas getCanvas(float x, float y, float w, float h){
        float width = mBitmap.getWidth();
        float height = mBitmap.getHeight();
        scale(width/ w, -height/ h);
        translate((2*x+width)/w-1.0f, 1.0f-(2*y+height)/h);
        if (mTransparent)
            mBitmap.eraseColor(Color.TRANSPARENT);
        mUpdate = true;
        return mCanvas;
    }

    @Override
    void bind() {
        super.bind();
        if (mBitmap != null && mUpdate) {
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, mBitmap, 0);
            mUpdate = false;
        }
    }

    @Override
    void render() {
        if (mTransparent){
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
            GLES20.glEnable(GLES20.GL_BLEND);
        }
        super.render();
        if (mTransparent){
            GLES20.glDisable(GLES20.GL_BLEND);
        }
    }
}

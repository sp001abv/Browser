package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.ArrayList;

class Actions {

    ArrayList<Action> items = new ArrayList<Action>();
    RectF rect = new RectF();
    Paint paint = null;
    final int offset = 2;

    static Actions active = null;

    void init() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(S.color_link);
        paint.setTextSize(S.action_text_size);
        paint.setTypeface(Typeface.SANS_SERIF);
        resize();
    }
    void resize(){
        if (rect.left < offset) rect.left = offset;
        if (rect.top < offset) rect.top = offset;
        rect.bottom = rect.top;
        rect.right = rect.left;
        for (int i = 0; i < items.size(); i++){
            Action item = items.get(i);
            String name = item.getName();
            float w = paint.measureText(name);
            if ((rect.right - rect.left) < w) rect.right = rect.left + w;
        }
        rect.right += paint.getTextSize();
        rect.bottom += (items.size() + 0.5f) * paint.getTextSize();
    }
    void show(float x, float y){
        if (paint==null)
            init();
        x-=rect.width()/2;
        y-=rect.height()/2;
        if (x<offset) x=offset;
        if (y<offset) y=offset;
        rect.offsetTo(x, y);
        active = this;
    }
    void onClick(float x, float y){
        if (rect.contains(x, y)) {
            int i = (int)((y - rect.top) / paint.getTextSize());
            if (i > items.size()-1) i = items.size()-1;
            items.get(i).onClick(x, y);
        }
        if (closeOnClick() && active == this)
            active = null;
    }
    void onDoubleClick(float x, float y){
    }
    boolean closeOnClick(){
        return active==this;
    }
    boolean closeOnBack(){
        return true;
    }
    boolean onBack() {
        if (active==this){
            active = null;
            return true;
        }
        return false;
    }
    int getItemIndex(float x, float y){
        return rect.contains(x,y) ? (int)((y-rect.top)/paint.getTextSize()) : -1;
    }
    void onDraw(Canvas canvas) {
        final float border = 1;
        paint.setColor(S.color_text);
        canvas.drawRect(rect, paint);
        float left = rect.left+border;
        float top = rect.top+border;
        paint.setColor(S.color_background);
        canvas.drawRect(left, top, rect.right-border, rect.bottom-border, paint);
        float y = top + paint.getTextSize();
        left += 3 * border;
        for (int i = 0; i < items.size(); i++){
            items.get(i).onDraw(canvas, left, y, rect.right, paint);
            y += paint.getTextSize();
        }
    }
    boolean onScroll(float x1, float y1, float x2, float y2, float distanceX, float distanceY){
        if (rect.contains(x1,y1) || rect.contains(x2,y2)){
            rect.offset(-distanceX,-distanceY);
            return true;
        }
        return false;
    }
}

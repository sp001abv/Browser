package com.sp.browser;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

class S {

    static String home_folder = "/sdcard/Browser/";
    static Cipher cipher;

    static MainActions mainActions = new MainActions();
    static MainActions2 mainActions2 = new MainActions2();
    static Actions activeActions = null;
    static Bookmarks bookmarks = new Bookmarks();
    static BlockedImages blockedImages = new BlockedImages();
    static FindActions find = new FindActions();
    static OpenFileAsActions openFileAsActions = new OpenFileAsActions();
    static FileActions fileActions = new FileActions();

    static int color_link = Color.rgb(0, 170, 215);
    static int color_text = Color.rgb(170, 170, 170);
    static int color_visited = Color.rgb(0, 100, 200);
    static int color_selected = Color.rgb(100, 0, 100);
    static int color_background = Color.BLACK;
    static int image_hash_size = 104857600;
    static int text_size = 24;
    static int action_text_size = 30;
    static int mark_size = 10;
    static int subtitle_text_size = 40;

    static boolean sibling_folders = false;
    static boolean full_screen = false;
    static boolean codec_player = false;
    static boolean block_images = false;
    static boolean portrait_layout = false;
    static boolean show_fps = false;

    static String root_folder = "/sdcard/";
    static String download_folder = root_folder + "Download/";
    static String output_folder = download_folder;

    static float image_max_size = 0;
    static int jpeg_quality = 85;
    static float default_scale = 3.0f;
    static float fling_treshold = 1000;
    static float fling_to_scroll = 400;
    static float scroll_attenuation = 0.5f;
    static boolean write_map_cache = false;
    static int selected_map = WebMap.open_street_map;
    static double[] home_location = null;
    static int gps_update_interval = 1000;
    static int gps_update_distance = 10;
    static float pointer_dx = 0.0f;
    static float pointer_dy = 0.0f;
    static float slide_interval = 5000;
    static int slide_mode = 1;
    static String youtube_download_sites = "https://qdownloader.io/download?url=";
    static float scroll_to_zoom = 1.0f / 120.0f;
    static final String boundary = "---------------------------7e3962680510";

    static int fpsCount = 0;
    static long fpsLogTime = 0;
    static String fps;

    static String lastVideoUrl = null;
    static int lastVideoPosition = 0;
    static int lastVideoAspectRatio = 0;

    static String guessEncoding(byte[] buff, int length) {
        // A 1010	// B 1011	// C 1100	// D 1101	// E 1110 // S 1000
        final byte e = (byte)0xE0;
        final byte c = (byte)0xC0;
        final byte s = (byte)0x80;
        length -= 2;
        for(int i = 0; i < length; i++) {
            if ((buff[i] & e) == c) {
                return ((buff[i + 1] & c) == s) ? C.utf8 : C.windows1251;
            }
        }
        return null;
    }

    static String formatTime(int ms) {
        int seconds = ms / 1000;
        int minutes = seconds / 60;
        return minutes < 60 ? String.format("%02d:%02d", minutes, seconds % 60) :
                String.format("%d:%02d:%02d", minutes / 60, minutes % 60, seconds % 60);
    }

    static String formatTimeStamp(int ms) {
        int seconds = ms / 1000;
        int minutes = seconds / 60;
        return minutes < 60 ? String.format("%02d:%02d.%03d", minutes, seconds % 60, ms % 1000) :
                String.format("%d:%02d:%02d.%03d", minutes / 60, minutes % 60, seconds % 60, ms % 1000);
    }

    static String formatMinutes(String format, int ms) {
        int seconds = ms / 1000;
        int minutes = seconds / 60;
        return String.format(format, minutes, seconds % 60);
    }

    static String getYearFromDate(String date) {
        return date.substring(0, 4);
    }

    static String getArchiveFolder(String date) {
        String path = output_folder + getYearFromDate(date) + C.slash + date + C.slash;
        File f = new File(path);
        if (!f.exists())
            f.mkdirs();
        return path;
    }

    static String getDateFromFileName(String name) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            if (Character.isDigit(name.charAt(i))) {
                sb.append(name.charAt(i));
                if (sb.length() == 8)
                    break;
            }
        }
        if (sb.length() == 8) {
            String date = sb.toString();
            int year = Integer.parseInt(getYearFromDate(date));
            int month = Integer.parseInt(date.substring(4, 6));
            int day = Integer.parseInt(date.substring(6));
            if (year > 2000 && year < 2100 && month > 0 && month < 13 && day > 0 && day < 32) {
                return date;
            }
        }
        return null;
    }

    static boolean haveSameStorage(String url, String path) {
        if (path.charAt(path.length()-1) != C.slash)
            return false;
        String regex = String.valueOf(C.slash);
        if (isLocalFile(url))
            url = getLocalPath(url);
        return url.split(regex)[2].equals(path.split(regex)[2]);
    }

    static String moveFile(String url, String path) {
        String result = null;
        if (isLocalFile(url))
            url = getLocalPath(url);
        try {
            if (!url.equals(path) && (new File(url)).renameTo(new File(path)))
                result = C.moved;
            else
                result = "cannot move " + url;
            result += C.space + "to" + C.space + path;
        } catch (Exception e) {
            result = "error " + e.getMessage();
        }
        return result;
    }

    static Bitmap downscaleBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth() / 2;
        int height = bitmap.getHeight() / 2;
        return Bitmap.createScaledBitmap(bitmap,  width, height, true);
    }

    static Bitmap decodeImage(InputStream inputStream){
        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
        if (slide_mode == 1 && image_max_size > 0)
            while (bitmap.getByteCount() > image_max_size)
                bitmap = downscaleBitmap(bitmap);
        return bitmap;
    }

    static Rect getCrop(Bitmap bitmap, int width, int height, RectF rect) {
        if (rect.top < 0 || rect.left < 0 || rect.right > width || rect.bottom > height) {
            float scale = bitmap.getHeight() / rect.height();
            int left = (int) (-rect.left * scale);
            if (left < 0) left = 0;
            int top = (int) (-rect.top * scale);
            if (top < 0) top = 0;
            int right = bitmap.getWidth() + (int) ((width-rect.right) * scale) - 1;
            int bottom = bitmap.getHeight() + (int) ((height-rect.bottom) * scale) - 1;
            if (right > bitmap.getWidth()) right = bitmap.getWidth();
            if (bottom > bitmap.getHeight()) bottom = bitmap.getHeight();
            if (left >= 0 && top >=0 && right > left && bottom > top)
                return new Rect(left, top, right, bottom);
        }
        return null;
    }

    static String saveBitmap(Bitmap bitmap, String path, String name) {
        String result = null;
        try {
            name += ".jpg";
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, jpeg_quality, os);
            result = saveBuffer(os.toByteArray(), path, name);
            os.close();
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }

    static String saveBuffer(byte[] buffer, String path, String name) {
        String result = null;
        try {
            FileWriter os = new FileWriter(path, name, buffer.length);
            os.write(buffer, 0, buffer.length);
            os.close();
            result = C.saved_as + path + name;
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }

    public static Bitmap rotateBitmap(Bitmap source, float angle)
    {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    static boolean fpsUpdated() {
        long elapsedTime = SystemClock.elapsedRealtime();
        long dt = (elapsedTime-fpsLogTime);
        final int period = 1000;
        if ((dt>=period)) {
            fpsLogTime = elapsedTime;
            fps = String.format("fps %4.1f", (float) (fpsCount * 1000) / (float) dt);
            fpsCount = 1;
            return true;
        }
        fpsCount++;
        return false;
    }

    static String readString(FileInputStream is) throws IOException {
        int n = is.read();
        byte[] b = new byte[n]; is.read(b);
        return new String(b);
    }

    static void writeString(FileOutputStream os, String s) throws IOException {
        os.write(s.length());
        os.write(s.getBytes());
    }

    static void writeDouble(FileOutputStream os,double value) throws IOException {
        byte[] bytes = new byte[8];
        ByteBuffer.wrap(bytes).putDouble(value);
        os.write(bytes);
    }

    static double readDouble(FileInputStream is) throws IOException {
        byte[] bytes = new byte[8];
        is.read(bytes);
        return ByteBuffer.wrap(bytes).getDouble();
    }

    static boolean isTextType(String type) { return type != null && type.startsWith(C.text);	}

    static boolean isImageType(String type) {
        return type != null && type.startsWith(C.image);
    }

    static boolean isVideoType(String type) { return type != null && type.startsWith(C.video); }

    static boolean isExt(String url, String ext) {  return url.startsWith(ext);  }

    static String getExt(String url) {
        int i;
        if (url.startsWith(C.http) && (i=url.lastIndexOf(C.question))>0)
            url = url.substring(0,i);
        i =	url.lastIndexOf(C.dot)+1;
        return i > 0 ? url.substring(i) : null;
    }

    static String removeExt(String url) {
        int i = url.lastIndexOf(C.dot);
        return i > 0 ? url.substring(0, i) : url;
    }

    static boolean isImage(String url) {
        if (url == null) return false;
        url = getExt(url.toLowerCase());
        if (url == null) return false;
        return isExt(url, "jpg") || isExt(url,"jpeg") || isExt(url, "png") ||
                isExt(url, "gif") || isExt(url,"pic") || isExt(url,"ico");
    }

    static boolean isGoogleVideo(String url) {
        return url.contains(C.google_video);
    }

    static boolean isVideo(String url) {
        if (url == null) return false;
        url = url.toLowerCase();
        if (isGoogleVideo(url))
            return true;
        url = getExt(url);
        if (url == null) return false;
        return isExt(url, "mp4") || isExt(url, "wmv") || isExt(url, "mkv") ||
                isExt(url, "avi") || isExt(url, "mov") || isExt(url, "ts") || isExt(url, "mpg") ||
                isExt(url, "m3u8") || isExt(url, "flv")  || isExt(url, "f4v");
    }

    static boolean isMedia(String url) {
        return isImage(url) || isVideo(url);
    }

    static boolean isText(String url) {
        if (url == null) return false;
        url = getExt(url.toLowerCase());
        if (url == null) return false;
        return isExt(url, "txt") || isExt(url, "srt") || isExt(url, "nfo") ||
                isExt(url, "html") || isExt(url, "xml") || isExt(url, "sh") ||
                isExt(url, "java") || isExt(url, "h") || isExt(url, "cpp");
    }

    static boolean isSubtitle(String url) {
        if (url == null) return false;
        url = getExt(url.toLowerCase());
        if (url == null) return false;
        return isExt(url, "srt");
    }

    static boolean isZip(String url) {
        if (url == null) return false;
        url = getExt(url.toLowerCase());
        if (url == null) return false;
        return isExt(url, C.zip);
    }

    static boolean isZipEntry(String url) {
        if (url == null) return false;
        return url.startsWith(C.zip);
    }

    static String[] getFilePathAndEntryName(String url, String extension) {
        String path = url.substring(url.indexOf(C.column) + 3);
        String split = C.dot + extension + C.slash;
        int index = path.indexOf(split);
        if (index < 0) index = path.toLowerCase().indexOf(split);
        index += split.length();
        String fileName = path.substring(index);
        path = path.substring(0, index-1);
        return new String[] {path, fileName};
    }

    static long getZipEntrySize(String url) {
        String[] s = getFilePathAndEntryName(url, C.zip);
        String path = s[0];
        String fileName = s[1];
        long size = 0;
        try {
            ZipFile zf = new ZipFile(path);
            Enumeration<? extends ZipEntry> entries = zf.entries();
            while ( entries.hasMoreElements() ) {
                ZipEntry ze = entries.nextElement();
                if (fileName.equals(ze.getName())) {
                    size = ze.getSize();
                    break;
                }
            }
            zf.close();
        } catch (IOException e) {

        }
        return size;
    }

    static boolean isContainer(String url) {
        if (url == null) return false;
        url = getExt(url.toLowerCase());
        if (url == null) return false;
        return isExt(url, ContainerOutput.EXT);
    }

    static boolean isContainerFile(String url) {
        if (url == null) return false;
        return url.startsWith(ContainerOutput.EXT);
    }

    static long getContainerFileSize(String url) {
        String[] s = getFilePathAndEntryName(url, ContainerOutput.EXT);
        String path = s[0];
        String fileName = s[1];
        try {
            ContainerInput container = new ContainerInput(path);
            if (container.find(fileName))
                return container.fileSize;
        }
        catch (Exception e) {};
        return 0;
    }

    static boolean isLocalFile(String url) {
        return url.startsWith(C.file);
    }

    static String getLocalPath(String url) {
        return isLocalFile(url) ? url.substring(url.indexOf(C.column)+3) : url;
    }

    static boolean isLocalFolder(String url) {
        return (isLocalFile(url) && (url.charAt(url.length()-1) == C.slash || isZip(url) || isContainer(url)))
                || isMtpFolder(url);
    }

    static boolean isRemoteDesktop(String url) {
        if (url == null) return false;
        return url.toLowerCase().startsWith(C.remotedesktop);
    }


    static boolean isMapLocation(String url) {
        if (url == null) return false;
        return getMapLocation(url) != null;
    }

    static boolean isDigit(char c){
        return Character.isDigit(c) || c==C.dot || c == '-';
    }

    static double[] getMapLocation(String location) {
        int i = 0;
        if (i < location.length() && (i = location.indexOf(C.comma, i)) > 0){
            int i1 = i-1;
            while(i1>=0 && isDigit(location.charAt(i1))) i1--;
            if(i-i1>5){
                int i2 = i+1;
                int len = location.length();
                while(i2<len && isDigit(location.charAt(i2))) i2++;
                if(i2-i>5){
                    String lat = location.substring(i1+1,i);
                    String lon = location.substring(i+1,i2);
                    if (lat.indexOf(C.dot)>0 && lon.indexOf(C.dot)>0){
                        Double latitude = parseDouble(lat);
                        Double longitude = parseDouble(lon);
                        if (latitude != null && longitude != null)
                            return new double[]{latitude, longitude};
                    }
                }
            }
            i++;
        }
        return null;
    }

    static Double parseDouble(String s) {
        try{
            return Double.parseDouble(s);
        }catch(Exception e){}
        return null;
    }

    static Integer parseInteger(String i) {
        try{
            return Integer.parseInt(i);
        }catch(Exception e){}
        return null;
    }


    static Integer parseTime(String time) {
        Integer ms = 0;
        int i = time.indexOf(C.dot);
        if (i < 0) i = time.indexOf(C.comma);
        if (i >=0 )	ms = parseInteger(time.substring(i+1).trim());
        if (ms != null) {
            if (i > 0) time = time.substring(0, i);
            String[] hms = time.split(String.valueOf(C.column));
            int m = 1000;
            for (i = hms.length-1; i>=0; i--){
                Integer s = parseInteger(hms[i].trim());
                if (s == null) return null;
                ms += s*m;
                m *= 60;
            }
            return ms;
        }
        return null;
    }

    static String decodeUrl(String url){
        try{
            return URLDecoder.decode(url, C.utf8);
        }
        catch (Exception e) {
            return  url;
        }
    }

    static String encodeUrl(String url, String encoding){
        try{
            if(encoding == null) encoding = C.utf8;
            return URLEncoder.encode(url, encoding);
        }
        catch (Exception e)  {
            return  url;
        }
    }

    static String buildWebServerUrl(String url) {
        StringBuilder b = new StringBuilder();
        b.append(C.http);
        b.append(C.column);
        b.append(C.slash);
        b.append(C.slash);
        b.append(WebServer.ServerIp);
        b.append(C.column);
        b.append(WebServer.ServerPort);
        b.append(C.slash);
        b.append(encodeUrl(url, C.utf8));
        return b.toString();
    }

    static boolean isMtpFile(String url) {
        return url.startsWith(C.mtp);
    }

    static boolean isMtpFolder(String url) {
        return isMtpFile(url) && url.charAt(url.length()-1) == C.slash;
    }

    static String getMimeType(String type){
        return type + C.slash + "*";
    }

    static float getFileSize(File f) {
        float size = f.length();
        if (f.isDirectory()) {
            File files[] = f.listFiles();
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    size += getFileSize(files[i]);
                }
            }
        }
        return size;
    }

    static String getFolderName(String url) {
        return url.substring(url.lastIndexOf(C.slash, url.length()-2)+1, url.length()-1);
    }

    static String getFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash)+1);
    }

    static String getParentFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash, url.length()-2)+1);
    }

    static void loadLocalFilesSorted(ArrayList<String> locals, String path, boolean directory) {
        File folder = new File(path);
        File files[] = folder.listFiles();
        if (files != null) {
            for (File f : files) {
                if ((directory && f.isDirectory()) ||
                        (!directory && f.isFile())) {
                    String fileName = f.getName();
                    addSorted(locals, fileName);
                }
            }
        }
    }

    static void addSorted(ArrayList<String> sorted, String s) {
        for (int i = 0; i < sorted.size(); i++) {
            String s1 = sorted.get(i);
            if (s.compareToIgnoreCase(s1) < 0) {
                sorted.set(i, s);
                s = s1;
                i--;
            }
        }
        sorted.add(s);
    }

    static boolean deleteFile(File file)
    {
        if (file.isDirectory())
        {
            File[] files = file.listFiles();
            for(int i = 0; i < files.length; i++) {
                if (!deleteFile(files[i]))
                    return false;
            }
        }
        return file.delete();
    }

    static boolean deleteFile(String path) {
        return deleteFile(new File(path));
    }

    static boolean copyFile(String source, String destination, IProgress progress) {
        try {
            if (source.charAt(source.length()-1) == C.slash)
            {
                String folderName = getFolderName(source);
                File destinationFolder = new File(destination + folderName);
                if (!destinationFolder.exists())
                    destinationFolder.mkdir();
                if (isMtpFolder(source))
                    return Mtp.copyMtpFolder(source, destinationFolder.getPath() + C.slash, progress);
                File sourceFolder = new File(source);
                File files[] = sourceFolder.listFiles();
                if (files != null) {
                    for (int i = 0; i < files.length; i++) {
                        String fileName = files[i].getName();
                        if (files[i].isDirectory()) fileName += C.slash;
                        if (!copyFile(source + fileName, destinationFolder.getPath() + C.slash, progress))
                            return false;
                    }
                }
            }
            else
            {
                String name = getFileName(source);
                if (source.equals(destination + name))
                    name = "copy of " + name;
                if (isMtpFile(source))
                    return Mtp.copyMtpFile(source, destination + name, progress);
                FileReader input = new FileReader(source);
                FileWriter output = new FileWriter(destination, name, input.size);
                byte[] buffer = new byte[1024];
                int bytesRead;
                int bytesCopied = 0;
                while( (bytesRead = input.read(buffer)) > 0){
                    if (bytesCopied % 1048576 == 0) {
                        if (!progress.onProgress(name + C.space + formatSize(bytesCopied) + C.slash + formatSize(input.size))) {
                            input.close();
                            output.close();
                            return false;
                        }
                    }
                    output.write(buffer, 0, bytesRead);
                    bytesCopied+=bytesRead;
                }
                input.close();
                output.close();
            }
            return true;
        }
        catch (Exception e) {
            progress.onProgress(e.getMessage());
            return false;
        }
    }

    static String getFileName(String url) {
        int i;
        if (url.startsWith(C.http)) {
            i = url.indexOf(C.question);
            if (i > 0) {
                url = url.substring(0, i);
            }
        }
        i = url.lastIndexOf(C.slash);
        if (i > 0)
            url = url.substring(i+1);
        return url;
    }

    static String formatSize(float size) {
        final String[] units = new String[] { "kB", "MB", "GB", "TB" };
        if (size > 9999) {
            for (int i = 0; i < units.length; i++) {
                size /= 1024;
                if (size < 10)
                    return String.format("%5.3f%s", size, units[i]);
                else if (size < 100)
                    return String.format("%5.2f%s", size, units[i]);
                else if (size < 1000)
                    return String.format("%5.1f%s", size, units[i]);
            }
        }
        return String.format("%dB", (long)size);
    }

    static String getFileNameFromTime() {
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss");
        return df.format(Calendar.getInstance().getTime());
    }

    static int getCodePoint(String html, int radix, int i1, int i2){
        int code = 0;
        for(int j = i1; j < i2; j++)
            code = code * radix + Character.digit(html.charAt(j), radix);
        return code;
    }

    static void appendCodePoint(StringBuilder sb, int code) {
        try {
            sb.appendCodePoint(code);
        } catch (Exception e) {
            sb.append(e.getMessage());
        }
    }

    static String getHtmlText(String html, int i1, int i2) {
        StringBuilder sb = new StringBuilder();
        for (int i=i1; i<i2; i++) {
            char c = html.charAt(i);
            while (c == C.amp){
                int index = i+1;
                int n = 0;
                if (index>=i2 || html.charAt(index)==C.amp)
                    break;
                for (int j=n+index; n<9 ;n++, j++) {
                    if (j >= i2) {
                        n=0;
                        break;
                    }
                    if (html.charAt(j)==C.semicol)
                        break;
                }
                if (n==0 || n==9)
                    break;

                if (html.charAt(index) == '#'){
                    int code = html.charAt(index+1)=='x' || html.charAt(index+1)=='X'?
                            getCodePoint(html,16,index+2,index+n):
                            getCodePoint(html,10,index+1,index+n);
                    if (code != 0) {
                        appendCodePoint(sb, code);
                        c = 0;
                        i+=n+1;
                    }
                    break;
                } else {
                    boolean found = false;
                    for(int e=0; e<C.ecode.length && !found; e++) {
                        if (C.ecode[e].length() == n){
                            for(int s = 0; s < n; s++){
                                if (C.ecode[e].charAt(s) != html.charAt(index+s))
                                    s=n;
                                if (s == n-1) {
                                    found = true;
                                    c = C.esymb[e];
                                    i+=n+1;
                                }
                            }
                        }
                    }
                    if (!found)
                        break;
                }
            }
            if (c == C.backslash && i + 1 < i2) {
                char next = html.charAt(i+1);
                if (next == 'n') {
                    c = C.newline;
                    i++;
                }
                else if (next == C.quote || next == C.backslash || next == C.slash) {
                    c = next;
                    i++;
                }
                else if (next == C.amp) {
                    c = C.amp;
                    i++;
                }
                else if (next == 'u') {
                    int code = getCodePoint(html,16,i+2,i+6);
                    i+=5;
                    appendCodePoint(sb, code);
                    continue;
                }
                else if (next == 'U') {
                    int code = getCodePoint(html,16,i+2,i+10);
                    i+=9;
                    appendCodePoint(sb, code);
                    continue;
                }
            }
            if (c != 0)
                sb.append(c);
        }
        return sb.toString();
    }

    static String getAttributes(String html, int beginIndex, int endIndex) {
        return endIndex>=beginIndex ? html.substring(beginIndex, endIndex) : null;
    }

    static String getAttribute(String html, String name)
    {
        if (html != null)
        {
            String attr = name;
            int length = html.length();
            int i = html.indexOf(attr);
            if (i < 0) i = html.indexOf(attr.toUpperCase());
            if (i > 0)
            {
                int i2;
                i += attr.length();
                if (i>=length)
                    return null;
                i = html.indexOf(C.equals, i);
                if (i < 0)
                    return null;
                i++;
                while (i < length && html.charAt(i) == C.space)
                    i++;
                if (i>=length)
                    return null;
                char q = html.charAt(i);
                if (q == C.backslash) i++;
                else if (q == C.open_square_bracket) q = C.close_square_bracket;
                else if (!(q == C.quote || q == C.apostr)) {
                    q=C.space;
                    i--;
                }
                i++;
                i2 = html.indexOf(q, i);
                if (i2 < 0)
                    i2 = html.length();
                return getHtmlText(html,i, i2);
            }
        }
        return null;
    }

    static String getJsonAttribute(String src, String name) {
        return getJsonAttribute(src, src.indexOf(C.quote+name+C.quote));
    }

    static String getJsonAttribute(String src, int index) {
        if (index > 0 && index < src.length()) {
            int i = src.indexOf(C.column, index);
            if (i > 0) {
                i++;
                char c = src.charAt(i);
                while (c == C.space) {
                    i++;
                    c = src.charAt(i);
                }
                if (!(c == C.quote || c == C.apostr)) {
                    c = C.comma;
                    i--;
                }
                i++;
                int i2 = i;
                while (true) {
                    i2 = src.indexOf(c, i2);
                    if (i2 < i) break;
                    if (src.charAt(i2) == C.quote && src.charAt(i2 - 1) == C.backslash)
                        i2++;
                    else
                        return getHtmlText(src, i, i2);
                }
            }
        }
        return null;
    }

}

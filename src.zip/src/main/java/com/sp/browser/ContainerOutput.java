package com.sp.browser;

import java.io.IOException;
import java.io.RandomAccessFile;

class ContainerOutput {
    final static int NAME_SIZE = 2;
    final static int FILE_SIZE = 5;
    final static String EXT = "cr";

    RandomAccessFile container;
    long nameLength;
    long fileSize;
    long fileOffset;
    ContainerOutput(String path, String name, long size) throws IOException {
        container = new RandomAccessFile(path,  "rw");
        byte[] nameBytes = name.getBytes(C.utf8);
        nameLength = nameBytes.length;
        fileSize = size;
        container.seek(container.length());
        write(nameLength, NAME_SIZE);
        write(nameBytes);
        write(fileSize, FILE_SIZE);
        fileOffset = container.getFilePointer();
    }

    void write(long value, int size) throws IOException
    {
        byte[] buffer = new byte[size];
        for (int i=0; i< buffer.length; i++) {
            buffer[i] = (byte) (value & 0xFF);
            value = value >> 8;
        }
        write(buffer);
    }

    void write(byte[] buffer) throws IOException {
        write(buffer, 0, buffer.length);
    }

    void write(byte[] buffer, int offset, int size) throws IOException {
        if (S.cipher != null)
            S.cipher.cipher(container.getFilePointer(), buffer, offset, size);
        container.write(buffer, 0, size);
    }

    void close() throws IOException {
        if (fileOffset + fileSize != container.length())
            container.setLength(fileOffset - nameLength - NAME_SIZE - FILE_SIZE);
        container.close();
    }
}


package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

class ActionEdit extends Action implements ITextEditor {
    WebTextEdit edit = new WebTextEdit();

    @Override
    public boolean startEditing(float x, float y) {
       return edit.startEditing(x, y);
    }

    @Override
    public boolean onEnter() {
        return edit.onEnter();
    }

    @Override
    public boolean onLeft(boolean shift, boolean home) {
        return edit.onLeft(shift, home);
    }

    @Override
    public boolean onRight(boolean shift, boolean end) {
        return edit.onRight(shift, end);
    }

    @Override
    public boolean onUp(boolean shift, float dy) {
        return edit.onUp(shift, dy);
    }

    @Override
    public boolean onDown(boolean shift, float dy) {
        return edit.onDown(shift, dy);
    }

    @Override
    public void del() {
        edit.del();
    }

    @Override
    public void paste(String text) {
        edit.paste(text);
    }

    @Override
    public void save() {
        edit.save();
    }

    @Override
    public void copy(CopyBuilder builder) {
        edit.copy(builder);
    }

    @Override
    public RectF getRect() {
        return edit.rect;
    }

    @Override
    public void stopEditing() {
        edit.stopEditing();
    }

    @Override
    int getColor() {
        return edit.editing ? S.color_visited : S.color_link;
    }

    @Override
    void onDraw(Canvas canvas, float left, float bottom, float right, Paint paint) {
        edit.move(left, bottom - paint.getTextSize(), right, bottom);
        edit.paint.setTextSize(paint.getTextSize());
        if (edit.editing) {
            edit.paint.setColor(getColor());
            edit.onDraw(canvas);
        }
        else
            super.onDraw(canvas, left, bottom, right, paint);
    }
}

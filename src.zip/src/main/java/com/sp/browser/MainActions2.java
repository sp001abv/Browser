package com.sp.browser;

import android.graphics.RectF;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

class FullScreenAction extends Action{
    @Override
    String getName() { return  "full screen"; }

    @Override
    int getColor(){
        return S.full_screen ? S.color_visited : S.color_link;
    }

    @Override
    void onClick(float x, float y){ Pages.activity.toggleFullScreen(); }
}
class ViewSourceAction extends Action {
    @Override
    String getName() { return "view source"; }

    @Override
    int getColor(){ return Pages.active().sourceVisible() ? S.color_visited : S.color_link; }

    @Override
    void onClick(float x, float y){
        Pages.active().viewSource();
    }
}

class CodecPlayerAction extends Action{
    @Override
    String getName() { return  "codec player"; }

    @Override
    int getColor(){
        return S.codec_player ? S.color_visited : S.color_link;
    }

    @Override
    void onClick(float x, float y){
        S.codec_player = !S.codec_player;
    }
}


class SiblingFoldersAction extends Action {
    @Override
    String getName() { return "sibling folders"; }

    @Override
    int getColor(){ return S.sibling_folders ?  S.color_visited : S.color_link; }

    @Override
    void onClick(float x, float y){
        S.sibling_folders = !S.sibling_folders;
    }
}
class BlockImagesAction extends Action {
    @Override
    String getName() { return "block images"; }

    @Override
    int getColor(){ return S.block_images ? S.color_visited : S.color_link; }

    @Override
    void onClick(float x, float y){
        S.block_images = !S.block_images;
        if (!S.block_images) S.blockedImages.save();
    }
}
class SaveCookiesAction extends Action {
    @Override
    String getName() { return "save cookies"; }

    @Override
    void onClick(float x, float y){
        Cookies.save();
        super.onClick(x, y);
    }
}

class ShowFpsAction extends Action{
    @Override
    String getName() { return "fps"; }
    @Override
    int getColor(){
        return S.show_fps ? S.color_visited : S.color_link;
    }
    @Override
    void onClick(float x, float y){
        S.show_fps=!S.show_fps;
        Logger.clear();
    }
}

class MainActions2 extends Actions {
    class WebServerAction extends Action {
        boolean showIp;
        @Override
        String getName() { return showIp ? WebServer.ServerIp : "web server"; }

        @Override
        int getColor(){ return WebServer.isStarted ? S.color_visited : S.color_link; }

        @Override
        void onClick(float x, float y){
            if (x > rect.left + rect.width() / 2) {
                editing = true;
                if (showIp)
                    toggleIpAddress();
                else
                    showIp = true;
            }
            else if (!WebServer.startStop())
                Toaster.postLongToast(WebServer.LastError);
            else
                editing = false;
        }

        void toggleIpAddress() {
            if (WebServer.isStarted)
                WebServer.startStop();
            try {
                String ip1 = WebServer.ServerIp;
                for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                    NetworkInterface intf = en.nextElement();
                    for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                        InetAddress inetAddress = enumIpAddr.nextElement();
                        String ip = inetAddress.getHostAddress();
                        if (ip.indexOf(C.column) < 0) {
                            if (ip1.equals(WebServer.ServerIp))
                                ip1 = ip;
                            if (WebServer.ServerIp.equals(C.empty)) {
                                WebServer.ServerIp = ip;
                                return;
                            }
                            if (ip.equals(WebServer.ServerIp))
                                WebServer.ServerIp = C.empty;
                        }
                    }
                }
                WebServer.ServerIp = ip1;
            } catch (SocketException ex) {
                Toaster.postLongToast(ex.toString());
            }
        }

    }

    class PortraitAction extends Action implements ITextEditor {
        String key = C.empty;
        @Override
        String getName() { return Pages.active().focusedItem == this ? key : "portrait"; }

        @Override
        int getColor() {
            return S.portrait_layout || Pages.active().focusedItem == this ? S.color_visited : S.color_link;
        }

        @Override
        void onClick(float x, float y){
            if (Pages.active().focusedItem == null) {
                if (x < rect.left + paint.measureText(getName())) {
                    S.portrait_layout=!S.portrait_layout;
                    Pages.active().invalidateLayout();
                } else {
                    startEditing();
                }
            }
        }

        @Override
        public boolean onEnter() {
            return true;
        }

        @Override
        public boolean onLeft() {
            return false;
        }

        @Override
        public boolean onRight() {
            return false;
        }

        @Override
        public void cut() {
            if (key.length() > 0) {
                key = key.substring(0, key.length() - 1);
            }
            update();
        }

        @Override
        public void paste(String t) {
            key += t;
            update();
        }

        void update() {
            Pages.active().postInvalidate();
        }

        @Override
        public RectF getRect() {
            return rect;
        }

        @Override
        public void stopEditing() {
            editing = false;
            S.activeActions = null;
            S.cipher = key.length() > 0 ? new Cipher(key) : null;
        }

        void startEditing() {
            Pages.active().showSoftInput(this);
            editing = true;
        }
    }

    boolean editing;

    MainActions2(){
        items.add(new ViewSourceAction());
        items.add(new SiblingFoldersAction());
        items.add(new CodecPlayerAction());
        items.add(new BlockImagesAction());
        items.add(new SaveCookiesAction());
        items.add(new FullScreenAction());
        items.add(new WebServerAction());
        items.add(new PortraitAction());
        items.add(new ShowFpsAction());
    }

    @Override
    boolean closeOnClick() {
        return !editing;
    }
}

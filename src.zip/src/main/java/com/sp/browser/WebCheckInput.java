package com.sp.browser;

class WebCheckInput extends WebText implements IWebInput {
    String value;
    WebCheckInput(String name, String value, boolean checked){
        href = name;
        setText("✓");
        this.value = value;
        setChecked(checked);
    }

    @Override
    void onClick(float x, float y)
    {
        setChecked(!getChecked());
    }

    boolean getChecked() {
        return paint.getColor() == S.color_visited;
    }

    void setChecked(boolean selected){
        paint.setColor(selected ? S.color_visited : S.color_link);
    }

    @Override
    public String getName() {
        return href;
    }

    @Override
    public String getValue() {
        return getChecked() ? value : null;
    }
}

package com.sp.browser;

class WebTH extends WebTD {
}

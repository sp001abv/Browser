package com.sp.browser;

class Downloader implements Runnable {
    boolean running = true;
    private static Queue<Downloader> downloaders = new Queue<Downloader>();
    private static Queue<IDownload> downloads = new Queue<IDownload>();

    static void start() {
        for (int i = 0; i < 3; i++) {
            Downloader downloader = new Downloader();
            downloaders.add(downloader);
            new Thread(downloader).start();
        }
    };

    static void stop() {
        for (Downloader downloader = downloaders.poll(); downloader != null; downloader = downloaders.poll())
            downloader.running = false;
    };

    static void download(IDownload download) {
        downloads.add(download);
    }

    static void clear() {
        for(IDownload download = downloads.poll(); download !=null; download = downloads.poll()) {
            if (download instanceof WebImage) {
                WebImage image = (WebImage)download;
                image.download = true;
            }
        }
    }

    public void run() {
        while (running){
            IDownload download = downloads.poll();
            if (download != null) {
                download.download();
            }
            else {
                try{ Thread.sleep(100); }
                catch (InterruptedException e) {  return ;}
            }
        }
    }
}

package com.sp.browser;

class WebMapLocation {
    float x;
    float y;
    double lat;
    double lon;
    WebMapLocation(){};
    WebMapLocation(double[] ll){ update(ll);}
    WebMapLocation(float x, float y){
        this.x=x;
        this.y=y;
        lon=x*360-180;
        lat=(180/Math.PI)*Math.atan(Math.sinh((1.0-2.0*y)*Math.PI));
    }
    void update(double lat, double lon){
        this.lat=lat;
        this.lon=lon;
        x=(float)((180+lon)/360);
        y=(float)(0.5*(1.0-Math.log(Math.tan(Math.PI*(0.25+lat/360)))/Math.PI));
    }
    void update(double[] ll){
        update(ll[0],ll[1]);
    }
    double distance(WebMapLocation l){
        return distance(l.lat,l.lon);
    }
    double distance(double lat2, double lon2){
        double φ1 = Math.toRadians(lat);
        double φ2 = Math.toRadians(lat2);
        double Δφ = φ2-φ1;
        double Δλ = Math.toRadians(lon2-lon);
        double sinΔφ = Math.sin(Δφ/2);
        double sinΔλ = Math.sin(Δλ/2);
        double a = sinΔφ*sinΔφ + Math.cos(φ1)*Math.cos(φ2)*sinΔλ*sinΔλ;
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return 6371008.8 * c;
    }
}

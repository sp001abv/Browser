package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

class RemoteDesktop extends WebItem implements GLTextureView.Callback {

    final class Inputs extends Queue<byte[]>
    {
        static final byte MOUSE_LEFTDOWN 	=	1;
        static final byte MOUSE_LEFTUP		=	2;
        static final byte MOUSE_RIGHTCLICK	= 	3;
        static final byte MOUSE_WHEEL		=	4;
        static final byte MOUSE_MOVE		=	5;

        static final byte KEY_DOWN			=	11;
        static final byte KEY_UP			=	12;

        final int setInt(byte[] b, int i, int v) {
            b[i++] =(byte)(v);
            b[i++] =(byte)(v>>8);
            b[i++] =(byte)(v>>16);
            b[i++] =(byte)(v>>24);
            return i;
        }

        final int setChar(byte[] b, int i, char v) {
            b[i++] =(byte)(v);
            b[i++] =(byte)(v>>8);
            return i;
        }

        final class ByteArrayBuilder {
            byte[] b;
            int i;
            ByteArrayBuilder(int capacity){
                b = new byte[capacity];
            }
            final void addByte(byte v) {
                b[i++] = (v);
            }
            final void addInt(int v) { i = setInt(b, i, v); }
            final void addChar(char v) { i = setChar(b, i, v); }
        }

        void addEvent(byte type)
        {
            byte[] b = new byte[1];
            b[0] = type;
            add(b);
        }

        void addEvent(byte type, int data)
        {
            ByteArrayBuilder b = new ByteArrayBuilder(6);
            b.addByte(type);
            b.addInt(data);
            add(b.b);
        }

        void addEvent(byte type, int x, int y)
        {
            ByteArrayBuilder b = new ByteArrayBuilder(10);
            b.addByte(type);
            b.addInt(x-left);
            b.addInt(y-top);
            add(b.b);
        }

        void addKeyEvent(byte type, char key)
        {
            ByteArrayBuilder b = new ByteArrayBuilder(3);
            b.addByte(type);
            b.addChar(key);
            add(b.b);
        }

    }

    int index;
    boolean connected;
    int left;
    int top;
    int w;
    int h;
    int size = 0;
    Inputs inputs = new Inputs();
    GLTextureView view;
    Socket screenSocket;
    InputStream screenInputStream;
    OutputStream screenOutputStream;
    String url;
    float pointer_x;
    float pointer_y;
    WebPage page;

    RemoteDesktop(WebPage page, String url)
    {
        this.page = page;
        this.url = url;
        if (test) {
            createView();
            return;
        }
        connect();
    }


    void createView() {
        view = new GLTextureView(page.getContext(), this);
        page.addView(view);
    }

    @Override
    void onDraw(Canvas canvas) {
				/*
				if (bitmap != null) {
					int x = ((int)width-w)/2;
					int y = ((int)height-h)/2;
					canvas.drawBitmap(bitmap, x, y, null);
				}
				*/
    }

    @Override
    boolean wrap(float w, float h) {
        width = w;
        height = h;
        return true;
    }

    final int[] controlKeyScanCode = {29, 42, 54, 56, 97, 100, 1};
    boolean[] controlKeyDown = new boolean[controlKeyScanCode.length];

    boolean canSend(int code, boolean down) {
        for(int i = 0; i < controlKeyScanCode.length; i++) {
            if (controlKeyScanCode[i] == code) {
                if (down) {
                    if (controlKeyDown[i])
                        return false;
                    else
                        controlKeyDown[i] = true;
                }
                else if (controlKeyDown[i])
                    controlKeyDown[i] = false;
                else
                    return false;
                break;
            }
        }
        return true;
    }

    @Override
    boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (canSend(event.getScanCode(), true))
                inputs.addKeyEvent(Inputs.KEY_DOWN, (char) event.getScanCode());
        }
        else if (event.getAction() == KeyEvent.ACTION_UP) {
            if (canSend(event.getScanCode(), false))
                inputs.addKeyEvent(Inputs.KEY_UP, (char) event.getScanCode());
        }
        return false;
    }

    boolean keyBoardActivated = false;
    @Override
    void onClick(float x, float y) {
        if (!keyBoardActivated) {
            page.showSoftInput(null);
            keyBoardActivated = true;
        }
    }

    @Override
    void onTouch(MotionEvent event) {
        float x = event.getX() + S.pointer_dx;
        float y = event.getY() + S.pointer_dy;
        if  (x >= left && x < left+w && y>=top && y < top+h)
        {
            if (event.getAction() == MotionEvent.ACTION_DOWN)
                inputs.addEvent(Inputs.MOUSE_LEFTDOWN);
            else if (event.getAction() == MotionEvent.ACTION_UP)
                inputs.addEvent(Inputs.MOUSE_LEFTUP);
        }
    }

    @Override
    void onMouseMove(float x, float y) {
        pointer_x = x;
        pointer_y = y;
        if  (x >= left && x < left+w && y>=top && y < top+h)
            inputs.addEvent(Inputs.MOUSE_MOVE, (int)x, (int) y);
    }


    @Override
    boolean onBack(float x, float y) {
        if (y < 5)
            return false;
        inputs.addEvent(Inputs.MOUSE_RIGHTCLICK);
        return true;
    }

    @Override
    boolean onScroll(float x, float y, float scroll) {
        inputs.addEvent(Inputs.MOUSE_WHEEL, (int)scroll);
        return true;
    }

    @Override
    boolean offset(float x, float y, float dx, float dy) {
        onMouseMove(pointer_x + dx, pointer_y + dy);
        return false;
    }

    Socket audioSocket;
    InputStream audioInputStream;
    OutputStream audioOutputStream;
    AudioTrack audioTrack;
    AudioRecord audioRecord;
    boolean audioConnected;

    void sendAudio() {
        try {
            int sampleRate = 16000;
            audioOutputStream.write(sampleRate & 0xFF);
            audioOutputStream.write(sampleRate >> 8);
            int bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            final byte[] buffer = new byte[bufferSize / 8];
            audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO,  AudioFormat.ENCODING_PCM_16BIT, bufferSize);
            audioRecord.startRecording();
            while (audioConnected) {
                int result = audioRecord.read(buffer, 0, buffer.length);
                if (result > 0) {
                    audioOutputStream.write(buffer, 0, result);
                }
            }
        }
        catch (Exception e) {
            if (audioConnected)
                onError(e.getMessage());
        }
        if (audioRecord != null) {
            audioRecord.stop();
            audioRecord.release();
            audioRecord = null;
        }
    }

    void receiveAudio() {
        try {
            audioSocket = new Socket(url.substring(C.remotedesktop.length()), 18081);
            audioInputStream = new BufferedInputStream(audioSocket.getInputStream());
            audioOutputStream = audioSocket.getOutputStream();
            int channels = audioInputStream.read() & 0xFF;
            channels = channels == 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            int encoding = audioInputStream.read() & 0xFF;
            encoding = encoding == 8 ? AudioFormat.ENCODING_PCM_8BIT : AudioFormat.ENCODING_PCM_16BIT;
            int sampleRate = (audioInputStream.read() & 0xFF) | (audioInputStream.read() & 0xFF) << 8;
            int minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channels, encoding);
            int sendAudio = audioInputStream.read() & 0xFF;
            if (sendAudio == 1){
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        sendAudio();
                    }
                }).start();
            }
            audioTrack = new AudioTrack(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
                    new AudioFormat.Builder()
                            .setEncoding(encoding)
                            .setSampleRate(sampleRate)
                            .setChannelMask(channels)
                            .build(),
                    minBufferSize, AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE);
            audioTrack.play();
            byte[] chunk = new byte[minBufferSize];
            audioConnected = true;
            while (audioConnected) {
                int len = audioInputStream.read(chunk);
                if (len > 0)
                    audioTrack.write(chunk, 0, len);
            }
        }
        catch (Exception e){
            if (audioConnected)
                onError(e.getMessage());
        }
        if (audioTrack != null) {
            audioTrack.pause();
            audioTrack.release();
            audioTrack = null;
        }
    }

    void connect() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    screenSocket = new Socket(url.substring(C.remotedesktop.length()), 18080);
                    screenInputStream = new BufferedInputStream(screenSocket.getInputStream());
                    screenOutputStream = screenSocket.getOutputStream();
                    h = (screenInputStream.read() & 0xFF) | (screenInputStream.read() & 0xFF) << 8;
                    w = (screenInputStream.read() & 0xFF) | (screenInputStream.read() & 0xFF) << 8;
                    if (w > 0 && h > 0 && w <= 1920 && h <= 1280) {
                        left = ((int)width - w)/2;
                        top = ((int)height-h)/2;
                        size = w * h;
                        int receiveAudio = screenInputStream.read() & 0xFF;
                        if(receiveAudio == 1)
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    receiveAudio();
                                }
                            }).start();
                        connected = true;
                        new Handler(page.getContext().getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                createView();
                            }
                        });
                        send();
                    }
                    else {
                        onError(String.format("w %d, h %d", w, h));
                    }
                }
                catch (Exception e){
                    onError(e.getMessage());
                }
            }
        }).start();
    }

    void send() throws Exception
    {
        while (connected) {
            byte[] input = inputs.poll();
            if (input != null)
                screenOutputStream.write(input);
            else
                SystemClock.sleep(50);
        }
    }

    void receive() throws Exception
    {
        int[][] frame = view.getTexture();
        boolean[] update = view.getUpdate();
        while (connected) {
            int segmentIndex = 0;
            int[] segment = frame[segmentIndex];
            int segmentSize = segment.length;
            int i = 0;
            int color;
            do {
                int n = (screenInputStream.read() & 0xFF);
                if ((n & 0x80) != 0) {
                    int bytes = (n & 0x3F) >> 4;
                    color = (n & 0x40) << 1;
                    n &= 0x0F;
                    for (int j = 0; j < bytes; j++)
                        n = (n << 8) | (screenInputStream.read() & 0xFF);
                    if (color == 0)
                        color = screenInputStream.read() & 0xFF;
                }
                else {
                    color = n; n = 1;
                }

                index += n;
                if (color != 0x80)
                {
                    color = color << 8 | (screenInputStream.read() & 0xFF);
                    color = (((color & 0x1F) << 19 | (color & 0x3E0) << 6 | (color & 0x7C00) >> 7));// | 0x000000;
                    do {
                        while (i >= segmentSize) {
                            i -= segmentSize;
                            segment = frame[++segmentIndex];
                        }
                        segment[i++] = color;
                        if (!update[segmentIndex]) update[segmentIndex] = true;
                    } while (--n > 0);
                }
                else {
                    i += n;
                }
                if (index >= size-1)
                {
                    if (index >= size) {
                        throw new Exception(String.format("index %d size %d", index, size));
                    }
                    index = 0;
                }
            } while (index > 0);
            view.onUpdateAvailable();
        }
    }


    @Override
    void onDestroy() {
        connected = false;
        audioConnected = false;
        if (screenSocket != null) {
            try {
                if (screenSocket.isConnected())
                    screenSocket.close();
            } catch (IOException e) {
            }
            screenSocket = null;
        }
        if (audioSocket != null) {
            try {
                if (audioSocket.isConnected())
                    audioSocket.close();
            } catch (IOException e) {
            }
            audioSocket = null;
        }
        if (view != null) {
            view.release();
            page.removeView(view);
            view = null;
        }
        page = null;
    }

    GLBitmapTextureRenderer fpsRenderer;
    Paint fpsPaint;
    void setFps()
    {
        if (fpsRenderer == null) {
            fpsRenderer = new GLBitmapTextureRenderer(view.mTextureRenderer.mProgram, S.text_size *5, S.text_size, false);
            fpsPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            fpsPaint.setTextSize(S.text_size);
        }
        Canvas canvas = fpsRenderer.getCanvas(0, 0, width, height);
        fpsPaint.setColor(S.color_background);
        canvas.drawRect(0, 0, S.text_size * 5, S.text_size, fpsPaint);
        fpsPaint.setColor(S.color_text);
        canvas.drawText(S.fps, 0, S.text_size, fpsPaint);
    }

    @Override
    public void onDrawFrame() {
        if (test) {
            if (S.fpsUpdated())
                setFps();
            if (fpsRenderer != null)
                fpsRenderer.render();
        }
    }

    final boolean test = false;

    void startScreenUpdate() {
        view.createTexture(w,h);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (test) {
                        int testColor = 0;
                        int[][] frame = view.getTexture();
                        boolean[] update = view.getUpdate();
                        while (connected) {
                            int segmentIndex = 0;
                            int[] segment = frame[segmentIndex];
                            int segmentSize = segment.length;
                            int i = 0;
                            index = 0;
                            do {
                                int n = 5;
                                index += n;
                                do {
                                    while (i >= segmentSize) {
                                        i -= segmentSize;
                                        segment = frame[++segmentIndex];
                                    }
                                    segment[i++] = testColor++;
                                    update[segmentIndex] = true;
                                } while (--n > 0);
                                if (index >= size)
                                    index = 0;
                            } while (index > 0);
                            view.onUpdateAvailable();
                        }
                    }
                    else
                        receive();
                }
                catch (Exception e){
                    if (connected)
                        onError(e.getMessage());
                }
            }
        }).start();
    }


    @Override
    public void onSurfaceCreated() {
        if (test) {
            w = 1680; h= 1050;
            size = w * h;
            connected = true;
        }
        startScreenUpdate();
    }

    String lastError;
    void  handleError() {
        page.removeItem(this);
        page.addText(lastError);
        page.invalidateLayout();
        onDestroy();
    }

    @Override
    public void onError(String error) {
        lastError = error;
        connected = false;
        audioConnected = false;
        new Handler(page.getContext().getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                handleError();
            }
        });
    }

}

package com.sp.browser;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

class FileActions extends Actions {
    class FileOpenAction extends Action{
        @Override
        String getName() { return file.text; }
        @Override
        void onClick(float x, float y){
            open();
        }
    }
    class FileCopyAction extends Action implements IProgress {
        String progress;
        public boolean onProgress(String pr) {
            if (progress == null) return false;
            if (progress == null || pr == null || pr.length() > progress.length()) {
                progress = pr;
                resize();
            }
            else {
                progress = pr;
            }
            Pages.active().postInvalidate();
            return true;
        }
        @Override
        String getName() {
            String name = "copy";
            if (progress != null)
                name += C.space + progress;
            return name;
        }
        @Override
        int getColor(){
            return action == this ? S.color_visited : S.color_link;
        }
        @Override
        void onClick(float x, float y){
            if (progress != null) {
                progress = null;
                return;
            }
            act(this);
        }
    }
    class FileCutAction extends Action{
        @Override
        String getName() { return "del"; }
        @Override
        int getColor(){
            return action == this ? S.color_visited : S.color_link;
        }
        @Override
        void onClick(float x, float y){
            act(this);
        }
    }
    class FilePasteAction extends Action{
        @Override
        String getName() { return "paste"; }
        @Override
        void onClick(float x, float y){
            paste();
        }
    }
    class FileStatAction extends Action{
        @Override
        String getName() { return stat == null ? "stat" : stat; }
        @Override
        void onClick(float x, float y){
            act(this);
            stat();
        }
    }
    class FileDeleteAction extends Action{
        @Override
        String getName() { return "delete"; }
        @Override
        int getColor(){
            return action == this ? S.color_visited : S.color_link;
        }
        @Override
        void onClick(float x, float y){
            if (action == this)
                delete();
            act(this);
        }
    }
    LocalFile file;
    String stat;
    Action action;
    ArrayList<String> selectedFiles;
    FileActions() {
        items.add(new FileOpenAction());
        items.add(new FileCutAction());
        items.add(new FileCopyAction());
        items.add(new FilePasteAction());
        items.add(new FileDeleteAction());
        items.add(new FileStatAction());
    }

    @Override
    void show(float x, float y) {
        stat = null;
        super.show(x , y);
        resize();
        rect.offsetTo(x, y);
    }

    void show(LocalFile file, float x, float y) {
        this.file = file;
        show(x, y);
    }
    void open(){
        file.open(rect.left, rect.top);
    }

    void act(Action a){
        if (action != a) {
            selectedFiles = Pages.active().getSelectedFiles();
            if (selectedFiles.size() == 0)
                selectedFiles.add(S.getLocalPath(file.href));
            action = a;
        } else  {
            action = null;
        }
    }

    void paste(){
        if (action != null) {
            WebPage page = Pages.active();
            if (S.isLocalFolder(page.pageUrl))
            {
                if (action.getClass().equals(FileCutAction.class)) {
                    page.move(selectedFiles);
                    action = null;
                } else {
                    FileCopyAction fileCopyAction = (FileCopyAction)action;
                    fileCopyAction.progress = C.empty;
                    page.copy(selectedFiles, fileCopyAction);
                }
            } else {
                page.paste(S.getLocalPath(file.href));
                action = null;
            }
        } else if (S.isLocalFolder(file.href)){
            String text = Pages.getClipboardText();
            if (text != null) {
                File f = new File(S.getLocalPath(file.href + text));
                if (text.indexOf(C.dot) > 0)
                    try { f.createNewFile(); } catch (IOException e) { }
                else
                    f.mkdir();
                if (file.href.equals(Pages.active().pageUrl))
                    Pages.active().loadLocalFolder();
            }
        }
    }

    void delete() {
        Pages.active().delete(selectedFiles);
    }

    void stat() {
        stat = Pages.active().stat(selectedFiles);
    }

    @Override
    boolean closeOnClick(){
        return action == null;
    }

    @Override
    boolean onBack(){
        action = null;
        return super.onBack();
    }
}

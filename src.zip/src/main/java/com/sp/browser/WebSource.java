package com.sp.browser;

import android.graphics.Canvas;

import java.util.Hashtable;

class WebSource extends WebText {
    boolean visible = false;
    Hashtable<WebItem, Integer> pos1 = new Hashtable<WebItem, Integer>();
    Hashtable<WebItem, Integer> pos2 = new Hashtable<WebItem, Integer>();

    WebSource(String text) {
        this.text = text + C.newline;
    }

    @Override
    boolean wrap(float w, float h) {
        if (rect.width() < 1) {
            super.wrap(w, h);
            h /= 2;
            rect.set(0, h, w, h + height);
        }
        return true;
    }

    @Override
    void onDraw(Canvas canvas)
    {
        paint.setColor(S.color_background);
        float top = canvas.getHeight() *0.5f;
        canvas.drawRect(0, top - paint.getTextSize(), canvas.getWidth(), canvas.getHeight(), paint);
        paint.setColor(S.color_text);
        onDraw(canvas,top, canvas.getHeight());
    }

    void show(WebItem item) {
        sel1 = pos1.get(item);
        sel2 = pos2.get(item);
        showSelection();
    }

    void showSelection() {
        Pages.active().pan_source = true;
        Pages.active().pan_dY = Pages.active().getHeight() * 0.6f - rect.top - getPositionY(sel1);
    }

    @Override
    void select(int index, int length)
    {
        sel1 = index;
        sel2 = index + length;
        showSelection();
    }

}

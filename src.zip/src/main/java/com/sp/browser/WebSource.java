package com.sp.browser;

import android.graphics.Canvas;

class WebSource extends WebText {
    boolean visible = false;

    WebSource(String text) {
        this.text = text + C.newline;
    }

    @Override
    boolean wrap(float w, float h) {
        if (rect.width() < 1) {
            super.wrap(w, h);
            h /= 2;
            rect.set(0, h, w, h + height);
        }
        return true;
    }

    @Override
    void onDraw(Canvas canvas)
    {
        paint.setColor(S.color_background);
        float top = canvas.getHeight() *0.5f;
        canvas.drawRect(0, top - paint.getTextSize(), canvas.getWidth(), canvas.getHeight(), paint);
        paint.setColor(S.color_text);
        onDraw(canvas,top, canvas.getHeight());
    }

    void show(WebItem item) {
        sel1 = item.srcpos1;
        sel2 = item.srcpos2;
        showSelection();
    }

    void showSelection() {
        Pages.active().pan_source = true;
        Pages.active().pan_dY = Pages.active().getHeight() * 0.6f - rect.top - getPosition(sel1);
    }

    @Override
    void select(String s, int index)
    {
        sel1 = index;
        sel2 = sel1 + s.length();
        showSelection();
    }

}

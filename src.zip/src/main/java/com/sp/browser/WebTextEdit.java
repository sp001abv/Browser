package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.RectF;

class WebTextEdit extends WebText implements ITextEditor {
    boolean editing;
    RectF cursor= new RectF();

    WebTextEdit() {
        super();
    }

    WebTextEdit(boolean bold, float size) {
        init(bold, size);
    }

    @Override
    public boolean startEditing(float x, float y) {
        if (editing)
            return false;
        editing = true;
        if (sel1 < 0 || sel1 == sel2)
            sel2 = sel1 = getPosition(x, y);
        if (sel1 < 0)
            sel1 = sel2 = text.length();
        return true;
    }

    @Override
    public void stopEditing() {
        editing = false;
    }

    @Override
    public boolean onEnter() {
        return line == null;
    }

    @Override
    public boolean onTab(boolean shift) {
        if (line == null) return false;
        return paste("   ");
    }

    @Override
    public boolean onLeft(boolean shift, boolean home) {
        if (sel1 > 0) {
            if (home) {
                int i = getLineIndex(sel1);
                sel1 = i >= 0 && lpos[i] > 0 ? lpos[i] + 1 : 0;
            }
            else
                sel1 -= 1;
            if (!shift)
                sel2 = sel1;
            return true;
        }
        return false;
    }

    @Override
    public boolean onRight(boolean shift, boolean end) {
        if (sel1 < text.length()) {
            if (end) {
                int i = getLineIndex(sel1);
                sel1 = i >= 0 ? lpos[i] + line.get(i).length() : text.length();
            }
            else
                sel1 += 1;
            if (!shift)
                sel2 = sel1;
            return true;
        }
        return false;
    }

    @Override
    public boolean onUp(boolean shift, float dy) {
        if (sel1 > 0) {
            int lineIndex = getLineIndex(sel1);
            if (lineIndex > 0) {
                int i = sel1 - lpos[lineIndex];
                float x = i > 0 ? paint.measureText(line.get(lineIndex), 0, i) : 0;
                if (dy > 0) {
                    lineIndex-=dy/paint.getTextSize();
                    if (lineIndex<0) lineIndex = 0;
                } else lineIndex--;
                sel1 = lpos[lineIndex] + getPosition(x+rect.left, line.get(lineIndex));
                if (!shift)
                    sel2 = sel1;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean onDown(boolean shift, float dy) {
        if (sel1 >= 0) {
            int lineIndex = getLineIndex(sel1);
            if (lineIndex >= 0 && lineIndex < lpos.length-1) {
                int i = sel1 - lpos[lineIndex];
                float x = i > 0 ? paint.measureText(line.get(lineIndex), 0, i) : 0;
                if (dy>0) {
                    lineIndex+=dy/paint.getTextSize();
                    if (lineIndex >= lpos.length) lineIndex = lpos.length-1;
                } else lineIndex++;
                sel1 = lpos[lineIndex] + getPosition(x+rect.left, line.get(lineIndex));
                if (!shift)
                    sel2 = sel1;
                return true;
            }
        }
        return false;
    }

    @Override
    public  void del(){
        if (text.length() > 0) {
            int s1 = sel1 < sel2 ? sel1 : sel2;
            int s2 = sel1 < sel2 ? sel2 : sel1;
            if (s1 < text.length()) {
                if (s1 > 0) {
                    StringBuilder sb = new StringBuilder();
                    if (s2 > s1) {
                        sb.append(text.substring(0, s1));
                    } else {
                        sb.append(text.substring(0, s1-1));
                        s1 -= 1;
                    }
                    sb.append(text.substring(s2));
                    text = sb.toString();
                }
                else {
                    text = text.substring(s2);
                    s1 = 0;
                }
            }
            else {
                text = text.substring(0, text.length() - 1);
                s1 = text.length();
            }
            sel2 = sel1 = s1;
            if (line != null) {
                invalidate();
            }
        }
    }

    @Override
    public void save() {}

    @Override
    public void copy(CopyBuilder builder) {
        super.copy(builder);
    }

    @Override
    public boolean undo() {
        return false;
    }

    @Override
    public boolean paste(String chars) {
        if (sel1 != sel2) 
            del();
    
        if (sel1 < text.length()) {
            StringBuilder sb = new StringBuilder();
            if (sel1 > 0)
                sb.append(text.substring(0, sel1));
            sb.append(chars);
            sb.append(text.substring(sel2));
            sel1 += chars.length();
            text = sb.toString();
        }
        else {
            text += chars;
            sel1 = text.length();
        }
        sel2 = sel1;
        if (line == null) {
            float w = paint.measureText(text) + paint.getTextSize();
            if (w > width) {
                width = w;
                invalidate();
                return  true;
            }
        } else
            invalidate();
        return false;
    }

    @Override
    public RectF rect() {
        return rect;
    }

    @Override
    public RectF cursor() {
        return cursor;
    }

    @Override
    void onClick(float x, float y)
    {
        if (!editing && href != null)
            super.onClick(x, y);
        else
            sel2 = sel1 = getPosition(x,y);
    }

    @Override
    void onDoubleClick(float x, float y){
        if (editing) {
            sel1 = 0;
            sel2 = text.length();
        }
        else
            super.onDoubleClick(x, y);
    }

    @Override
    void onDestroy() {
        if (editing)
            stopEditing();
    }

    @Override
    void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (editing)
            drawCursor(canvas);
    }

    void drawCursor(Canvas canvas){
        int lineIndex = getLineIndex(sel1);
        int pos = lineIndex >= 0 ? lpos[lineIndex] : 0;
        String l = lineIndex >= 0 ? line.get(lineIndex) : text;
        float x = rect.left;
        float y = rect.top + paint.getTextSize() * 0.15f;
        if (sel1 > pos) x += paint.measureText(l, 0, sel1-pos);
        if (lineIndex > 0) y += lineIndex * paint.getTextSize();
        cursor.set(x, y, x+paint.getTextSize() * 0.1f, y + paint.getTextSize());
        int color = paint.getColor();
        paint.setColor(Color.CYAN);
        canvas.drawRect(cursor, paint);
        paint.setColor(color);
    }

    void invalidate() {
        wrapw = 0;
        wrap(width, height);
    }


}

package com.sp.browser;

import android.graphics.Canvas;

class ImageActions extends Actions {
    class ImageSlideshowAction extends Action{
        @Override
        String getName() {
            return String.format("slideshow %d/%d %3.1f", S.slide_mode, C.slide_modes, S.slide_interval / 1000.f);
        }
        @Override
        int getColor(){
            return S.color_link;
        }
        @Override
        void onClick(float x, float y){
            String text = getName().substring(0, getName().indexOf(C.dot));
            float split = rect.left + paint.measureText(text);
            if(x > split) {
                slideshow.setInterval(1);
            }
            else {
                text = text.substring(0, text.lastIndexOf(C.space));
                split = rect.left + paint.measureText(text);
                if (x > split) {
                    slideshow.setInterval(-1);
                }
                else {
                    text = text.substring(0, text.lastIndexOf(C.slash));
                    split = rect.left + paint.measureText(text);
                    if (x > split) {
                        slideshow.setMode(1);
                    }
                    else {
                        text = text.substring(0, text.lastIndexOf(C.space));
                        split = rect.left + paint.measureText(text);
                        if (x > split) {
                            slideshow.setMode(-1);
                        }
                        else {
                            closeOnClick = true;
                            slideshow.toggleRun();
                        }
                    }
                }
            }
        }
    }

    class ImageRotateAction extends Action{
        @Override
        String getName() { return slideshow.rotate; }
        @Override
        int getColor(){
            return S.color_link;
        }
        @Override
        void onClick(float x, float y){
            String text = getName().substring(0, getName().indexOf(C.degree));
            float split = rect.left + paint.measureText(text);
            slideshow.rotate(x < split ? -90 : 90);
        }
    }

    class ImageSaveAction extends Action{
        @Override
        String getName() { return "save " + slideshow.getImageDim(); }
        @Override
        int getColor(){
            return S.color_link;
        }
        @Override
        void onClick(float x, float y){
            String caption = getName();
            int i = caption.indexOf(C.space);
            boolean crop = false;
            boolean closeup = false;
            x -= rect.left;
            if (x > paint.measureText(caption.substring(0, i))) {
                crop = true;
                i = caption.indexOf(C.times);
                if (i > 0 && x > paint.measureText(caption.substring(0, i))) {
                    if (x < paint.measureText(caption.substring(0, i+1))) {
                        slideshow.downscaleImage();
                        return;
                    }
                    closeup = true;
                }
            }
            slideshow.saveImage(crop, closeup);
        }
    }

    class ImageExifAction extends Action{
        @Override
        String getName() {
            String name = "exif";
            if (exifInfo != null && exifInfo.exif != null)
                name += exifInfo.getIndexes();
            return name;
        }
        @Override
        int getColor(){ return S.color_link; }
        @Override
        void onClick(float x, float y){
            if (exifInfo != null) {
                String text = getName().substring(0, getName().indexOf(C.space));
                float split = rect.left + paint.measureText(text);
                if (x > split)
                    exifInfo.next();
                else
                    exifInfo = null;
            }
            else
                exifInfo = new ExifInfo(slideshow.media);
        }
    }

    ExifInfo exifInfo;
    boolean closeOnClick;
    Slideshow slideshow;

    ImageActions(Slideshow slideshow) {
        this.slideshow = slideshow;
        items.add(new ImageSlideshowAction());
        items.add(new ImageRotateAction());
        items.add(new ImageSaveAction());
        items.add(new ImageExifAction());
    }

    @Override
    void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (exifInfo != null)
            exifInfo.onDraw(canvas, slideshow.media, rect);
    }

    @Override
    void show(float x, float y) {
        closeOnClick = false;
        super.show(x, y);
    }

    @Override
    boolean closeOnClick(){
        return closeOnClick;
    }

    void onDestroy() {
        slideshow = null;
    }

}

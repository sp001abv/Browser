package com.sp.browser;

class AdaptiveVideo extends  WebText {
    AdaptiveVideo(String name, String videoUrl, String audioUrl) {
        href = videoUrl + C.newline + audioUrl;
        setText(name);
    }

    @Override
    void onDoubleClick(float x, float y) {
        S.openFileAsActions.show(href, false, x, y);
    }
}

package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.RectF;

import java.util.ArrayList;

class PanoImage extends WebItem {

    private ArrayList<Tile> tiles = new ArrayList<Tile>();
    private float tileWidth = 0;

    PanoImage(float tileWidth, float tileHeight){
        this.tileWidth = tileWidth;
        width = 10e6f;
        height = tileHeight;
    }
    void addTile(String url){
        tiles.add(new Tile(url,null));
    }
    @Override
    void onDraw(Canvas canvas) {
        if (tiles.size()==0 || tileWidth==0) return;
        float l = rect.left;
        RectF r = new RectF(l, rect.top, l+tileWidth, rect.top + height);
        int i = 0;
        while(r.left<canvas.getWidth()){
            if (r.right>0 && tiles.get(i).bitmap != null)
                canvas.drawBitmap(tiles.get(i).bitmap, null, r, null);
            r.offset(tileWidth-0.5f,0);
            i++;
            if (i==tiles.size())
                i=0;
        }
    }

    @Override
    boolean offset(float x, float y, float dx, float dy) {
        super.offset(x, y, dx, dy);
        if (rect.left > 0) {
            rect.left -= tileWidth * tiles.size();
            rect.right = rect.left + width;
        }
        return true;
    }

    @Override
    boolean scale(float scale)
    {
        tileWidth*=scale;
        return super.scale(scale);
    }

    @Override
    public void onDestroy() {
        for(int i = 0; i < tiles.size(); i++) {
            tiles.get(i).onDestroy();
        }
    }
}

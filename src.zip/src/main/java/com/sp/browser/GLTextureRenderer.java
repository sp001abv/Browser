package com.sp.browser;

import android.opengl.GLES20;
import android.opengl.Matrix;

import java.nio.FloatBuffer;

class GLTextureRenderer {
    private final float[] mPositionData = {
            // X, Y, Z
            -1.0f, -1.0f, 0,
            1.0f, -1.0f, 0,
            -1.0f,  1.0f, 0,
            1.0f,  1.0f, 0,
    };

    private final float[] mTextureData = {
            // U, V
            0.f, 0.f,
            1.f, 0.f,
            0.f, 1.f,
            1.f, 1.f,
    };

    GLProgram mProgram;
    protected float[] muMVPMatrix;
    private int muMVPMatrixHandle;
    private int maPositionHandle;
    private int maTextureHandle;

    private int mTextureType;
    int mTextureID;
    GLTextureRenderer(int type, GLProgram program) {
        mProgram = program;
        mTextureType = type;
        muMVPMatrix = new float[16];
        Matrix.setIdentityM(muMVPMatrix, 0);

        maPositionHandle = GLES20.glGetAttribLocation(mProgram.id(), "aPosition");
        setVertexAttribData(maPositionHandle, mPositionData);

        maTextureHandle = GLES20.glGetAttribLocation(mProgram.id(), "aTexture");
        setVertexAttribData(maTextureHandle, mTextureData);

        muMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram.id(), "uMVPMatrix");

        int[] textures = new int[1];
        GLES20.glGenTextures(1, textures, 0);
        mTextureID = textures[0];
        GLES20.glBindTexture(mTextureType, mTextureID);

        GLES20.glTexParameterf(mTextureType, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameterf(mTextureType, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(mTextureType, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(mTextureType, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
    }

    void setVertexAttribData(int handle, float[] data) {
        int[] buffers = new int[1];
        GLES20.glGenBuffers(buffers.length, buffers, 0);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffers[0]);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.length * 4, FloatBuffer.wrap(data), GLES20.GL_STATIC_DRAW);
        GLES20.glVertexAttribPointer(handle, data.length / 4, GLES20.GL_FLOAT, false,0, 0);
    }

    void rotate(double angle) {
        angle = Math.PI * angle / 180.0;
        float cosa = (float)Math.cos(angle);
        float sina = (float)Math.sin(angle);
        muMVPMatrix[1] = -muMVPMatrix[0]*sina;
        muMVPMatrix[0] *= cosa;
        muMVPMatrix[4] = muMVPMatrix[5]*sina;
        muMVPMatrix[5] *= cosa;
    }

    void scale(float x, float y) {
        muMVPMatrix[0] = x;
        muMVPMatrix[5] = y;
    }

    void translate(float x, float y) {
        muMVPMatrix[12] = x;
        muMVPMatrix[13] = y;
    }

    void use() {
        mProgram.use();
        GLES20.glEnableVertexAttribArray(maPositionHandle);
        GLES20.glEnableVertexAttribArray(maTextureHandle);
        GLES20.glUniformMatrix4fv(muMVPMatrixHandle, 1, false, muMVPMatrix, 0);
    }

    void bind(){
        use();
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(mTextureType, mTextureID);
    }

    void draw() {
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glBindTexture(mTextureType, 0);
        GLES20.glUseProgram(0);
    }

    void render() {
        bind();
        draw();
    }

}

package com.sp.browser;

import android.text.InputType;

import java.io.IOException;
import java.util.ArrayList;

class WebForm extends WebText {
    ArrayList<IWebInput> inputs = new ArrayList<IWebInput>();
    String method;
    WebFileInput uploadFile;
    WebForm(String action, String method){
        href = action;
        this.method = method != null ? method.toUpperCase() :C.GET;
        setText("GO!");
    }
    WebItem addInput(String type, String name, String value, String tag) {
        if (name == null) return null;
        if (value == null) value = C.empty;
        IWebInput input = null;
        if (type == null)
            inputs.add(new WebInput(name, value));
        else
        if (type.equals("password"))
            input = new WebTextInput(InputType.TYPE_TEXT_VARIATION_PASSWORD, name, value);
        else if (type.equals("text") || type.equals("url") || type.equals("search") || type.equals("identity"))
            input = new WebTextInput(InputType.TYPE_TEXT_VARIATION_NORMAL, name, value);
        else if (type.equals("checkbox"))
            input = new WebCheckInput(name, value, tag.contains("checked"));
        else if (type.equals("radio"))
            input = new WebRadioInput(name, value, tag.contains("checked"));
        else if (type.equals("hidden") || type.equals("submit"))
            inputs.add(new WebInput(name, value));
        else if (type.equals("file"))
            input = new WebFileInput(name, value);
        else
            inputs.add(new WebInput(name, value));

        if (input != null) inputs.add(input);
        return (WebItem) input;
    }
    WebSelectInput addSelect(String name) {
        if (name == null) return null;
        WebSelectInput input = new WebSelectInput(name);
        inputs.add(input);
        return input;
    }
    void addOption(String name, String value, boolean selected){
        if (inputs.size()>0){
            IWebInput input = inputs.get(inputs.size()-1);
            if (input instanceof WebSelectInput){
                WebSelectInput select = (WebSelectInput)input;
                WebSelectInput.Option option = select.addOption(name,value);
                if (selected) select.onOptionSelected(option);
            }
        }
    }
    String getData(String encoding) {
        StringBuilder data = new StringBuilder();
        for (int i = 0; i < inputs.size(); i++) {
            IWebInput input = inputs.get(i);
            String value = input.getValue();
            if (value != null){
                if (data.length() > 0) data.append(C.amp);
                data.append(input.getName());
                data.append(C.equals);
                data.append(S.encodeUrl(value, encoding));
            }
        }
        return data.toString();
    }

    void addInput(StringBuilder data, IWebInput input) {
        String value = input.getValue();
        if (value != null) {
            data.append(S.boundary);
            data.append(C.newline);
            data.append("Content-Disposition: form-data; name=");
            data.append(C.quote);
            data.append(input.getName());
            data.append(C.quote);
            if (input == uploadFile) {
                data.append(C.semicol);
                data.append(C.space);
                data.append("filename");
                data.append(C.equals);
                data.append(C.quote);
                data.append(value);
                data.append(C.quote);
                data.append(C.newline);
                data.append("Content-Type: application/octet-stream");
                data.append(C.newline);
                data.append(C.newline);
            }
            else {
                data.append(C.newline);
                data.append(C.newline);
                data.append(value);
                data.append(C.newline);
            }
        }
    }

    byte[] getMultipartData() throws IOException {
        StringBuilder data = new StringBuilder();
        for (int i = 0; i < inputs.size(); i++) {
            IWebInput input = inputs.get(i);
            if (input != uploadFile)
                addInput(data, input);
        }
        addInput(data, uploadFile);
        return data.toString().getBytes(C.utf8);
    }


    @Override
    void onClick(float x, float y)
    {
        Pages.add(href, true, this);
    }
}

package com.sp.browser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

class Bookmarks extends Actions {
    ArrayList<String> bookmarks_files = null;
    int bookmarks_file = 0;
    int bookmarks_count = 0;
    boolean close = true;

    int index(String url){
        for(int i=0;i<items.size();i++){
            if (items.get(i).getName().equals(url))
                return i;
        }
        return -1;
    }
    void bookmark(String url){
        if (index(url) >= 0) {
            items.remove(index(url));
            bookmarks_count--;
        }
        else {
            items.add(bookmarks_count, new LoadBookmarkAction(url));
            bookmarks_count++;
        }
        save();
        if (paint != null) resize();
    }
    int moved_index = -1;
    @Override
    boolean onScroll(float x1, float y1, float x2, float y2,  float distanceX, float distanceY){
        if (moved_index == -1){
            float x = x2;
            float y = y2;
            if (x>(rect.left+rect.width()/2))
                return super.onScroll(x1, y1, x2, y2,distanceX,distanceY);
            int index = getItemIndex(x, y);
            if (index < bookmarks_count)
                moved_index = index;
        }
        else {
            int index = getItemIndex(x2, y2);
            if (index != -1 && index != moved_index && index < bookmarks_count){
                Action item = items.get(index);
                items.set(index, items.get(moved_index));
                items.set(moved_index, item);
                moved_index = index;
            }
        }
        return moved_index != -1;
    }
    @Override
    boolean onBack() {
        moved_index = -1;
        return super.onBack();
    }
    @Override
    void onClick(float x, float y){
        if (moved_index != -1) {
            save();
            onBack();
        }
        else {
            int index = getItemIndex(x, y);
            close = index < bookmarks_count;
            super.onClick(x,y);
        }
    }
    @Override
    void onDoubleClick(float x, float y)
    {
        int index = getItemIndex(x, y);
        if (index != -1 && index < bookmarks_count){
            items.remove(index);
            bookmarks_count--;
            save();
            if (paint != null) resize();
        }
    }

    boolean closeOnClick(){
        return close;
    }

    void load(String file){
        for(int i = 0; i < bookmarks_files.size(); i++) {
            if (bookmarks_files.get(i).equals(file)) {
                bookmarks_file = i;
                break;
            }
        }
        load();
        resize();
    }

    void load(){
        try
        {
            if (bookmarks_files == null)
            {
                bookmarks_files =  new ArrayList<String>();
                File f = new File(S.home_folder);
                File files[] = f.listFiles();
                if (files != null) {
                    for (int i=0; i < files.length; i++) {
                        String filename = files[i].getName();
                        if (filename.endsWith(C.bookmarks_file_extension)) {
                            if (filename.startsWith("favorite"))
                                bookmarks_file = bookmarks_files.size();
                            bookmarks_files.add(filename);

                        }
                    }
                }
            }

            if (bookmarks_files.size() > 0) {
                items.clear();
                FileInputStream is = new FileInputStream(S.home_folder + bookmarks_files.get(bookmarks_file));
                bookmarks_count = is.read();
                for (int i = 0; i < bookmarks_count; i++) {
                    items.add(new LoadBookmarkAction(S.readString(is)));
                }
                is.close();
                for (int i = 0; i < bookmarks_files.size(); i++) {
                    if (i != bookmarks_file)
                        items.add(new LoadBookmarksAction(bookmarks_files.get(i)));
                }
            }
            else {
                bookmarks_files.add(C.bookmarks_default_file);
            }

            items.add(new BookmarkAction());
        }
        catch (Exception e)
        {
            Logger.log(e.getMessage());
        }
    }
    void save() {
        try
        {
            FileOutputStream os = new FileOutputStream(S.home_folder+bookmarks_files.get(bookmarks_file));
            os.write(bookmarks_count);
            for(int i=0;i<bookmarks_count;i++){
                S.writeString(os,items.get(i).getName());
            }
            os.close();
        }
        catch (Exception e)
        {
            Logger.log(e.getMessage());
        }
    }
}

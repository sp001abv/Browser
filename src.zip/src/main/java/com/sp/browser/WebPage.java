package com.sp.browser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.view.GestureDetector;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

class WebPage extends LinearLayout implements IDownload
{
    String pageUrl;
    String pageEncoding;
    String referer;
    String pageType;
    WebForm form;
    WebSource webSource;
    ArrayList<Finding> findings = new ArrayList<Finding>();
    ArrayList<WebImage> images = new ArrayList<WebImage>();
    Slideshow slideshow;
    String siteUrl = null;
    WebItem lastAddedItem = null;
    ArrayList<WebItem> dom = new ArrayList<WebItem>();
    GestureDetector gestureDetector;
    GestureDetector gestureDetector2;
    ScaleGestureDetector scaleDetector;
    ITextEditor focusedItem;
    float panX = 0;
    float panY = 0;
    float pan_dX = 0;
    float pan_dY = 0;
    float scroll_velx = 0;
    float scroll_vely = 0;
    float rotateAngle = 0;
    boolean double_tap = false;
    boolean scaling = false;
    boolean pan_source = false;
    float pointer_x;
    float pointer_y;
    boolean pan_select = false;
    boolean pan_scroll = false;
    float ev_x1 = 0;
    float ev_y1 = 0;
    boolean invalidLayout = true;

    WebPage(Context context, String url, String referer, WebForm form, String type) {
        super(context);
        this.referer = referer;
        this.form = form;
        this.pageType = type;
        setBackgroundColor(S.color_background);
        Pages.activity.setContentView(this);
        if (url!=null) {
            setSiteUrl(url);
            if (S.isLocalFile(url))
                url=S.decodeUrl(url);
            pageUrl = url;
            if (type != null && type.equals(C.download))
                Downloader.download(this);
            else if (S.isRemoteDesktop(url))
                addItem(new RemoteDesktop(this, pageUrl));
            else if (S.isVideoType(type) || S.isVideo(url))
                addWebPlayer(url);
            else if (S.isLocalFolder(url))
                loadLocalFolder();
            else if (S.isMapLocation(url))
                addItem(new WebMap(url));
            else
                Downloader.download(this);
        }
        GestureDetector.OnGestureListener gestureListener = new GestureDetector.OnGestureListener(){
            @Override
            public boolean onDown(MotionEvent p1){
                scroll_velx = scroll_vely = 0;
                scaling = double_tap = false;
                return false;
            }

            @Override
            public void onShowPress(MotionEvent p1){
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e){
                if (double_tap)
                    onDoubleClick(e.getX()+ S.pointer_dx, e.getY()+ S.pointer_dy);
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                Actions aa = Actions.active;
                float x1 = e1.getX() + S.pointer_dx;
                float y1 = e1.getY() + S.pointer_dy;
                float x2 = e2.getX() + S.pointer_dx;
                float y2 = e2.getY() + S.pointer_dy;
                if (aa != null && aa.onScroll(x1, y1, x2, y2, distanceX, distanceY))
                    postInvalidate();
                else {
                    if (!double_tap && !scaling) {
                        pan(x1, y1, x2, y2, distanceX, distanceY);
                    }
                }
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e){
                if (Actions.active == null && !(dom.size() == 1 && dom.get(0) instanceof WebPlayer)){
                    S.mainActions.show(e.getX(), e.getY());
                    postInvalidate();
                }
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velX, float velY){
                if ((Math.abs(velY) > S.fling_treshold || Math.abs(velX) > S.fling_treshold) &&
                        !(dom.size() == 1 && (
                                dom.get(0) instanceof WebPlayer ||
                                        //dom.get(0) instanceof WebImageEditor ||
                                        dom.get(0) instanceof RemoteDesktop))){
                    ev_x1 = e1.getX();
                    ev_y1 = e1.getY();
                    scroll_velx = velX/S.fling_to_scroll;
                    scroll_vely = velY/S.fling_to_scroll;
                    postInvalidate();
                    return true;
                }
                return false;
            }
        };
        GestureDetector.SimpleOnGestureListener gestureListener2 = new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                onClick(e.getX()+ S.pointer_dx, e.getY()+ S.pointer_dy);
                return true;
            }
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                double_tap = true;
                return true;
            }
        };
        gestureDetector = new GestureDetector(getContext(), gestureListener);
        gestureDetector2 = new GestureDetector(getContext(), gestureListener2);
        ScaleGestureDetector.SimpleOnScaleGestureListener scaleListener  = new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                if (scaling == false){
                    ev_x1 = detector.getFocusX();
                    ev_y1 = detector.getFocusY();
                    scaling = true;
                }
                zoom(ev_x1, ev_y1, detector.getScaleFactor());
                return true;
            }
        };
        scaleDetector = new ScaleGestureDetector(context, scaleListener);
    }

    static String buildUrl(String siteUrl, String pageUrl, String url) {
        if (url.startsWith(C.http) || S.isLocalFile(url) || S.isMapLocation(url) || url.startsWith(C.magnet)
                || url.startsWith(C.acestream) || S.isMtpFile(url) || S.isRemoteDesktop(url)){

        }
        else if (siteUrl!=null && url.charAt(0) == C.slash)
        {
            if (url.charAt(1) == C.slash)
                url = siteUrl.substring(0,siteUrl.indexOf(C.column)+1) + url;
            else
                url = siteUrl + url;
        } else {
            String pageBase = pageUrl.substring(0, pageUrl.lastIndexOf(C.slash) + 1);
            if (url.charAt(0) == C.dot && url.charAt(1) == C.slash)
                url = pageBase + url.substring(2);
            else
                url = pageBase + url;
        }
        return url;
    }

    static String getSite(String url) {
        if (url != null && url.startsWith(C.http)) {
            int i = url.indexOf(C.slash, 8);
            if (i > 0)
                return url.substring(0, i);
        }
        return url;
    }

    static boolean isBigImage(Bitmap bitmap) {
        return bitmap != null && bitmap.getHeight() > 800;
    }

    public boolean onBack() {
        if (dom.size() == 1)
            return dom.get(0).onBack(pointer_x, pointer_y);
        return false;
    }

    public void find(String text, int index)
    {
        text = text.toLowerCase();
        if (sourceVisible()) {
            webSource.select(text, findings.get(index).index);
        }
        else {
            for(int i=0; i<dom.size(); i++)
                dom.get(i).select(text, 0);
            Finding finding = findings.get(index);
            WebItem item = finding.item;
            item.select(text, finding.index);
            float height = getHeight()*0.3f;
            if (item.rect.top != height)
                height -= finding.position;
            pan(0, item.rect.top - height);
        }
    }

    public int find(String text)
    {
        text = text.toLowerCase();
        findings.clear();
        if (sourceVisible()) {
            webSource.find(text, findings);
        }
        else for(int i=0; i<dom.size(); i++){
            dom.get(i).find(text, findings);
        }
        return findings.size();
    }


    ArrayList<String> getSelectedFiles() {
        ArrayList<String> files = new ArrayList<String>();
        for (int i = 0; i < dom.size(); i++) {
            if (dom.get(i) instanceof LocalFile) {
                LocalFile file = (LocalFile) dom.get(i);
                if (file.sel1 >=0 && file.sel2 > file.sel1) {
                    files.add(S.getLocalPath(file.href));
                }
            }
        }
        return files;
    }

    void move(ArrayList<String> files) {
        String destination = S.getLocalPath(pageUrl);
        for (int i = 0; i < files.size(); i++) {
            File f = new File(files.get(i));
            f.renameTo(new File(destination + f.getName()));
        }
        loadLocalFolder();
    }

    void copy(ArrayList<String> files,  FileActions.FileCopyAction action){
        new Thread(new CopyFileAsync(this, files, S.getLocalPath(pageUrl), action)).start();
    }

    void delete(ArrayList<String> files) {
        for (String path : files) {
            if (path.startsWith(String.valueOf(C.slash)))
                S.deleteFile(path);
            else if (S.isMtpFile(path))
                Mtp.deleteMtpFile(path);
        }
        loadLocalFolder();
    }

    String stat(ArrayList<String> files) {
        float size = 0;
        for (String path : files) {
            size += S.isMtpFile(path) ? Mtp.getMtpFileSize(path) :
                    S.isZipEntry(path) ? S.getZipEntrySize(path) :
                            S.isContainerFile(path) ? S.getContainerFileSize(path) :
                                    S.getFileSize(new File(path));
        }
        return S.formatSize(size);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (focusedItem != null)
        {
            int keyCode = event.getKeyCode();
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                switch (keyCode) {
                    case KeyEvent.KEYCODE_DEL:
                        focusedItem.del();
                        postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_DPAD_LEFT:
                        if (focusedItem.onLeft(event.isShiftPressed(), false))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_DPAD_RIGHT:
                        if (focusedItem.onRight(event.isShiftPressed(), false))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_DPAD_UP:
                        if (focusedItem.onUp(event.isShiftPressed(), 0)) {
                            postInvalidate();
                        }
                        return true;
                    case KeyEvent.KEYCODE_DPAD_DOWN:
                        if (focusedItem.onDown(event.isShiftPressed(), 0)) {
                            postInvalidate();
                        }
                        return true;
                    case KeyEvent.KEYCODE_MOVE_HOME:
                        if (focusedItem.onLeft(event.isShiftPressed(), true))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_MOVE_END:
                        if (focusedItem.onRight(event.isShiftPressed(), true))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_PAGE_UP:
                        if (focusedItem.onUp(event.isShiftPressed(), getHeight()/2)) {
                            pan_dY = getHeight()/2;
                            postInvalidate();
                        }
                        return true;
                    case KeyEvent.KEYCODE_PAGE_DOWN:
                        if (focusedItem.onDown(event.isShiftPressed(), getHeight()/2)) {
                            pan_dY = -getHeight()/2;
                            postInvalidate();
                        }
                        return true;
                    case KeyEvent.KEYCODE_BACK:
                        focusedItem.stopEditing();
                        hideSoftInput();
                        return true;
                    case KeyEvent.KEYCODE_TAB:
                        focusedItem.paste("    ");
                        postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_ENTER:
                        if (focusedItem.onEnter()) {
                            focusedItem.stopEditing();
                            hideSoftInput();
                            return true;
                        }
                    case KeyEvent.KEYCODE_X:
                    case KeyEvent.KEYCODE_V:
                    case KeyEvent.KEYCODE_C:
                    case KeyEvent.KEYCODE_F:
                        if (event.isCtrlPressed()) {
                            if (keyCode == KeyEvent.KEYCODE_X) {
                                CopyBuilder builder = new CopyBuilder();
                                focusedItem.cut(builder);
                                String text = builder.toString();
                                Pages.setClipboardText(text);
                                if (text != null)
                                    postInvalidate();

                            }
                            else if (keyCode == KeyEvent.KEYCODE_C) {
                                CopyBuilder builder = new CopyBuilder();
                                focusedItem.copy(builder);
                                String text = builder.toString();
                                Pages.setClipboardText(text);
                            }
                            else if (keyCode == KeyEvent.KEYCODE_V) {
                                String text = Pages.getClipboardText();
                                if (text != null) {
                                    focusedItem.paste(text);
                                    postInvalidate();
                                }
                            }
                            return true;
                        }
                    default: {
                        char c = (char) event.getUnicodeChar();
                        if (c > 0) {
                            focusedItem.paste(String.valueOf(c));
                            postInvalidate();
                            return true;
                        }
                    }
                }
            } else if (event.getAction() == KeyEvent.ACTION_MULTIPLE) {
                if (keyCode == KeyEvent.KEYCODE_UNKNOWN) {
                    focusedItem.paste(event.getCharacters());
                    postInvalidate();
                    return true;
                } else {
                    char c = (char)event.getUnicodeChar();
                    if (c > 0) {
                        for(int i = 0; i < event.getRepeatCount(); i++) {
                            focusedItem.paste(String.valueOf(c));
                            postInvalidate();
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        else if (dom.size() == 1 &&  dom.get(0).onKeyEvent(event))
            return true;
        return super.dispatchKeyEvent(event);
    }

    boolean softInputVisible() {
        Rect r = new Rect();
        getWindowVisibleDisplayFrame(r);
        int height = getHeight();
        return height - r.height() > height / 10;
    }

    void hideSoftInput() {
        if (softInputVisible()) {
            InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(0, 0);
        }
        if (isFocusable())
            setFocusable(false);
        if (isFocusableInTouchMode())
            setFocusableInTouchMode(false);
        focusedItem = null;
        postInvalidate();
    }

    void showSoftInput(ITextEditor item) {
        focusedItem = item;
        if (!softInputVisible()) {
            if (!isFocusableInTouchMode())
                setFocusableInTouchMode(true);
            if (!isFocusable())
                setFocusable(true);
            InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(this, 0);
            postInvalidate();
        }
    }

    String getMediaHref(boolean next) {
        return getMediaUrlHref(pageUrl, next);
    }

    String getMediaUrlHref(String url, boolean next){
        if (S.isLocalFile(url))
            return getLocalMediaFile(url, next);

        WebPage page = Pages.active() == this ? Pages.prev() : Pages.active();
        if (page != null) {
            String href = page.getMediaHref(url, next);
            if (S.isVideo(href) || S.isImage(href))
                return href;
        }
        String[] prevNextUrl = getPrevNextUrl(url);
        if (prevNextUrl != null)
            return next ? prevNextUrl[1] : prevNextUrl[0];
        return null;
    }

    ArrayList<String> getMediaHref()
    {
        ArrayList<String> href = new ArrayList<String>();
        for (int i=0; i<dom.size(); i++){
            dom.get(i).addMediaHref(href);
        }
        return href;
    }

    String getMediaHref(String url, boolean next) {
        ArrayList<String> href = getMediaHref();
        for (int i=0; i < href.size(); i++){
            if (href.get(i).equals(url)) {
                return next ? (i < href.size()-1 ?  href.get(i+1) : null):
                        (i > 0 ?  href.get(i-1) : null);
            }
        }
        return null;
    }

    void addWebPlayer(String url) {
        addItem(new WebPlayer(this, url));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e)
    {
        scaleDetector.onTouchEvent(e);
        gestureDetector.onTouchEvent(e);
        gestureDetector2.onTouchEvent(e);
        if (dom.size() == 1)
            dom.get(0).onTouch(e);
        return true;
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (0 != (e.getSource() & InputDevice.SOURCE_CLASS_POINTER)) {
            if (e.getAction() == MotionEvent.ACTION_SCROLL) {
                scroll(e.getX(), e.getY(), e.getAxisValue(MotionEvent.AXIS_VSCROLL));
                return true;
            }
            else if (e.getAction() == MotionEvent.ACTION_HOVER_MOVE) {
                pointer_x = e.getX() + S.pointer_dx;
                pointer_y = e.getY() + S.pointer_dy;
                if (dom.size() == 1)
                    dom.get(0).onMouseMove(pointer_x , pointer_y);
            }
        }
        return super.onGenericMotionEvent(e);
    }

    String copy(){
        CopyBuilder builder = new CopyBuilder();

        if (sourceVisible())
            webSource.copy(builder);
        else for(int i=0;i<dom.size();i++)
            dom.get(i).copy(builder);

        return builder.toString();
    }

    void paste(String text){
        if (focusedItem != null) {
            focusedItem.paste(text);
        }
    }

    void onDestroy(){
        decoding = false;
        if (slideshow != null) {
            slideshow.onDestroy();
            slideshow = null;
        }
        for(int i=0; i<dom.size(); i++)
            dom.get(i).onDestroy();
        dom.clear();
    }

    void pan(float dx, float dy) {
        pan_dX -= dx;
        pan_dY -= dy;
        postInvalidate();
    }

    void pan(float x1, float y1, float x2, float y2, float dx, float dy) {
        boolean source = sourceVisible() && y1 > getHeight()/2;
        if (centered() && !source){
            ev_x1 = x1;
            ev_y1 = y1;
            pan(dx,dy);
        } else {
            if (ev_x1!=x1 && ev_y1!=y1){
                ev_x1 = x1;
                ev_y1 = y1;
                pan_scroll = Math.abs(dx)<Math.abs(dy);
                pan_select = dx<0 && !(pan_scroll);
            }
            if (pan_select){
                if (sourceVisible() && y1 > getHeight() / 2){
                    webSource.select(x1,y1,x2,y2);
                }
                else {
                    if (y2 > getHeight() - S.text_size)
                        y2 = dom.get(dom.size()-1).rect.bottom + S.text_size;
                    for(int i=0;i<dom.size();i++){
                        dom.get(i).select(x1, y1, x2, y2);
                    }
                }
                postInvalidate();
            }
            else {
                if (pan_scroll) dx = 0;
                pan_source = source;
                if (pan_source){
                    pan_dY = -dy;
                    pan_dX = -dx;
                    postInvalidate();
                }
                else pan(dx ,dy);
            }
        }
    }

    void rotate(float x, float y, float scroll) {
        rotateAngle += (int)(scroll * 5);
        postInvalidate();
    }

    void scale(float x, float y, float scale) {
        WebItem item = getItem(x,y);
        if (item == null) return;
        if (item.scale(scale) && centered()){
            scale-=1.0f;
            panX+=(panX-x)*scale;
            panY+=(panY-y)*scale;
        }
        invalidateLayout();
    }

    void zoom(float x, float y, float scale) {
        if (centered() && x < S.text_size)
            rotate(x, y, (1.0f - scale) * 20f);
        else
            scale(x, y, scale);
    }

    void scroll(float x, float y, float scroll) {
        if (dom.size() == 1 && dom.get(0).onScroll(x, y, scroll))
            ;
        else if (scroll_velx == 0 && scroll_vely == 0 && ((centered() && (x < getWidth()-S.text_size))))
        {
            int i = (int)Math.abs(scroll * S.scroll_to_zoom);
            if (i >= C.scale_step.length) i = C.scale_step.length - 1;
            zoom(x, y, scroll > 0 ? C.scale_step[i] : 1.0f / C.scale_step[i]);
        }
        else {
            scroll = -25.0f * scroll;
            float height = getHeight();
            pan_source = sourceVisible() && y > height/2;
            if (pan_source){
                pan_dY = -scroll;
                postInvalidate();
                return;
            }
            if (sourceVisible()) height/=2;
            height *= 0.75f;
            if (scroll <  0) {
                if (panY == 0)
                    return;
                if (scroll < -height) scroll = -height;
                if (panY - scroll > 0)
                    scroll = panY;
            } else if (scroll > 0 && dom.size() > 0) {
                WebItem item = dom.get(dom.size()-1);
                if (item.width>0 && item.height>0){
                    float bottom = item.rect.bottom;
                    if (bottom == height || (bottom-panY) < height)
                        return;
                    if (scroll > height) scroll = height;
                    if (bottom - scroll < height)
                        scroll = bottom - height;
                }
            }
            pan(0, scroll);
        }
    }

    void onClick(float x, float y) {
        Actions aa = Actions.active;
        if (aa != null && aa.rect.contains(x,y)) {
            aa.onClick(x, y);
            postInvalidate();
            return;
        } else if (aa == null && x == S.pointer_dx && y < getHeight()*0.75f){
            S.mainActions.show(x, y);
            postInvalidate();
            return;
        }

        if (focusedItem != null && !focusedItem.getRect().contains(x, y)) {
            focusedItem.stopEditing();
            hideSoftInput();
        }

        if (dom.size() == 1 && dom.get(0) instanceof WebImage)
        {
            if (slideshow == null)
                slideshow = new Slideshow(this, images.get(0));
            slideshow.onClick(x, y);
            postInvalidate();
            return;
        }

        WebItem item = getItem(x, y);
        if (item != null) {
            if (sourceVisible())
                webSource.show(item);
            else
                item.onClick(x, y);
            postInvalidate();
        }
    }

    void onDoubleClick(float x, float y) {
        Actions aa = Actions.active;
        if (aa != null){
            aa.onDoubleClick(x, y);
            postInvalidate();
            return;
        }
        WebItem item = getItem(x, y);
        if (item != null){
            item.onDoubleClick(x,y);
            postInvalidate();
        }
    }

    void setSiteUrl(String url){
        siteUrl = getSite(url);
    }


    String getAbsUrl(String url) {
        if (url == null) return null;
        if (url.length() < 3) return siteUrl;
        return buildUrl(siteUrl, pageUrl, url);
    }

    String[] getPrevNextUrl(String url) {
        int i1 = 0;
        int i2 = 0;
        for(int i = url.length()-1; i > 0; i--) {
            if (Character.isDigit(url.charAt(i))) {
                if (i2 == 0)
                    i2 = i1 = i;
                else
                    i1 = i;
            }
            else if (i2 > 0) {
                break;
            }
        }
        if (i1 > 0){
            try {
                int n = Integer.parseInt(url.substring(i1, i2+1));
                String format = String.format("%%0%dd", i2-i1+1);
                String prev = url.substring(0, i1) + String.format(format, n-1);
                if (i2 < url.length() - 1)
                    prev += url.substring(i2+1);
                String next = url.substring(0, i1) + String.format(format, n+1);
                if (i2 < url.length() - 1)
                    next += url.substring(i2+1);
                return new String[]{prev, next};
            }
            catch (Exception e){
                return null;
            }
        }
        return null;
    }
    void addPrevNextPageUrl() {
        String[] url = getPrevNextUrl(pageUrl);
        if (url != null) {
            addText(url[0], url[0]);
            newrow = true;
            addText(url[1], url[1]);
        }
        else addText(pageUrl);
    }

    Queue<WebDiv> divs = new Queue<WebDiv>();

    WebDiv openDiv(WebDiv div) {
        WebDiv pdiv = divs.last();
        if (pdiv != null){
            if (div.getClass().equals(WebTR.class)) {
                if (pdiv.getClass().equals(WebTR.class)) {
                    closeDiv(WebTR.class);
                }
            }
            else if (div.getClass().equals(WebTD.class)) {
                if (pdiv.getClass().equals(WebTD.class)) {
                    closeDiv(WebTD.class);
                }
            }
        }
        div.newrow = newrow;
        newrow = false;
        div.srcpos1 = srcpos1;
        divs.add(div);
        return div;
    }

    void openTD(WebTD td, String attributes) {

        String attr = S.getAttribute(attributes, "colspan");
        if (attr != null) {
            Integer colspan = S.parseInteger(attr);
            if (colspan != null)
                td.colspan = colspan;
        }
        attr = S.getAttribute(attributes, "rowspan");
        if (attr != null) {
            Integer rowspan = S.parseInteger(attr);
            if (rowspan != null)
                td.rowspan = rowspan;
        }
        newrow = false;
        openDiv(td);
    }

    void closeDiv(Class<?> type) {
        WebDiv div = divs.cut();
        if (div == null) return;
        if (div.items.size() == 0 && !type.equals(WebTD.class)) {
            newrow = div.newrow;
            return;
        }
        srcpos1 = div.srcpos1;
        if (type.equals(WebDiv.class) && div.items.size() == 1) {
            WebItem item = div.items.get(0);
            boolean nr = newrow;
            newrow = item.newrow;
            addItem(item);
            newrow = nr;
            div.items.clear();
            return;
        }
        div.srcpos2 = srcpos2;
        newrow = div.newrow;
        addItem(div);
        if (div instanceof WebTable) {
            ((WebTable) div).init();
        }
        else if (type.equals(WebTable.class)) {
            closeDiv(type);
        }
    }

    WebItem addItem(WebItem item){
        item.newrow = newrow;
        newrow = false;
        lastAddedItem = item;
        item.srcpos1 = srcpos1;
        item.srcpos2 = srcpos2;
        WebDiv div = divs.last();
        if (div != null) {
            if (div.getClass().equals(WebTable.class)) {
                if (!item.getClass().equals(WebTR.class)) {
                    if (!item.getClass().equals(WebText.class)) {
                        openDiv(new WebTR());
                        addItem(item);
                    }
                    return item;
                }
            }
            else if (div.getClass().equals(WebTR.class)) {
                if (!item.getClass().equals(WebTD.class)) {
                    openDiv(new WebTD());
                    addItem(item);
                    return item;
                }
            }
            div.items.add(item);
            return item;
        }
        dom.add(item);
        return item;
    }

    void removeItem(WebItem item){
        if (images.contains(item))
            images.remove(item);
        if (dom.contains(item))
            dom.remove(item);
        else for(int i = dom.size()-1; i>=0; i--){
            WebItem last = dom.get(i);
            if (last.remove(item)){
                break;
            }
        }
    }

    WebItem getItem(float x, float y){
        for(int i = 0; i < dom.size(); i++){
            WebItem item = dom.get(i).get(x, y);
            if (item != null)
                return item;
        }
        return null;
    }

    boolean centered() {
        return dom.size() == 1 && (dom.get(0) instanceof WebImage //|| dom.get(0) instanceof WebImageEditor
                || dom.get(0) instanceof  WebMap
                || dom.get(0) instanceof WebPlayer
                || dom.get(0) instanceof RemoteDesktop
                || dom.get(0) instanceof PanoImage);
    }

    void invalidateLayout(){
        invalidLayout = true;
        postInvalidate();
    }

    void layout(){
        //lc++;
        //log(String.format("layout %d",lc),2,false);
        float x = 0;
        float y = 0;
        float h = 0;
        if (scroll_velx != 0 || scroll_vely != 0){
            scroll_velx -= scroll_velx*S.scroll_attenuation;
            scroll_vely -= scroll_vely*S.scroll_attenuation;
            if (Math.abs(scroll_velx)<0.01f) scroll_velx = 0;
            if (Math.abs(scroll_vely)<0.01f) scroll_vely = 0;
            if (scroll_velx != 0 || scroll_vely != 0){
                if (centered() && !(sourceVisible() && ev_y1 > getHeight()/2))
                    pan(-15.0f*scroll_velx,-15.0f*scroll_vely);
                else
                    scroll(ev_x1,ev_y1,scroll_vely);
            } else {
                postInvalidate();
            }
        }
        if (pan_source) {
            webSource.offset(ev_x1, ev_y1,  pan_dX, pan_dY);
            pan_source = false;
            pan_dX = pan_dY = 0;
        }
        else {
            float dx = pan_dX;
            float dy = pan_dY;
            if (dx != 0 || dy != 0) {
                pan_dX = pan_dY = 0;
                if (centered()) {
                    if (dom.get(0).offset(ev_x1, ev_y1, dx, dy)) {
                        panX += dx;
                        panY += dy;
                    }
                }
                else {
                    for (int i = 0; i < dom.size(); i++)
                        dom.get(i).offset(ev_x1, ev_y1, dx, dy);
                    panX += dx;
                    panY += dy;
                }
            }
            else if (invalidLayout){
                invalidLayout = false;
                float width = getWidth();
                float height = getHeight();
                if (sourceVisible())
                    webSource.wrap(width, height);
                if (images.size() == 1 && !centered()){
                    WebImage image = images.get(0);
                    Bitmap bitmap = image.bitmap;
                    if (isBigImage(bitmap)) {
                        dom.clear();
                        pageUrl = image.src;
                        image.href = null;
                        image.rect.left = image.rect.right;
                        dom.add(image);
                    }
                }
                if (centered()) {
                    WebItem item = dom.get(0);
                    if (item.rect.width() <= S.text_size) {
                        if (item.wrap(width, height)) {
                            rotateAngle = 0;
                            int i = S.slide_mode == 1 ? 0 : pageUrl.indexOf(C.at);
                            if (i > 0 && pageUrl.length() > ++i)
                            {
                                String[] fit = pageUrl.substring(i).split(String.valueOf(C.backslash) + String.valueOf(C.dot));
                                if (fit.length < 6)
                                    i = 0;
                                else {
                                    Integer fw = S.parseInteger(fit[0]);
                                    Integer fh = S.parseInteger(fit[1]);
                                    Integer fx = S.parseInteger(fit[2]);
                                    Integer fy = S.parseInteger(fit[3]);
                                    Integer fr = S.parseInteger(fit[4]);
                                    if (fw != null && fh != null && fx != null && fx != null && fr != null){
                                        item.width = fw;
                                        item.height = fh;
                                        panX = fx;
                                        panY = fy;
                                        rotateAngle = fr;
                                    }
                                    else i= 0;
                                }
                            }
                            if (i <= 0)
                            {
                                if (S.slide_mode == 1 && item.height < height && item.width < width && item.height > 0 && item.width > 0) {
                                    float wr = width/item.width;
                                    float hr = height/item.height;
                                    if (hr < wr) {
                                        item.width *= hr;
                                        item.height = height;
                                    }
                                    else {
                                        item.width = width;
                                        item.height *= wr;
                                    }
                                }
                                panX = (width - item.width) / 2;
                                panY = (height - item.height) / 2;
                            }
                        }
                    }
                    item.move(panX, panY, panX + item.width, panY + item.height);
                }
                else {
                    for(int i = 0; i < dom.size(); i++) {
                        WebItem item = dom.get(i);
                        item.wrap(width, height);
                        if (item.newrow || x + item.width >= width) {
                            x = 0; y += h; h = 0;
                        }
                        item.move(x + panX, y + panY, x + panX + item.width, y + panY + item.height);
                        x += item.width;
                        if (h < item.height) h = item.height;
                    }
                }
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            drawAll(canvas);
            if (S.show_fps) {
                if (S.fpsUpdated()) {
                    String s = S.fps;
                    if (dom.size() == 1 && dom.get(0) instanceof WebImage) {
                        WebImage image = (WebImage)dom.get(0);
                        s += C.space + S.formatSize(image.bitmap.getByteCount());
                    }
                    Logger.log(s , 0, false);
                }
            }
        }
        catch (Exception e) {
            Logger.log(e.getMessage());
        }
    }

    void drawAll(Canvas canvas){
        if (!decoding) {
            float h = canvas.getHeight();
            layout();
            for(int i = 0; i < dom.size(); i++) {
                WebItem item = dom.get(i);
                if (rotateAngle != 0) {
                    canvas.save();
                    canvas.rotate(rotateAngle, item.rect.centerX(), item.rect.centerY());
                }
                if (item.intersects(h))
                    item.onDraw(canvas);
                if (rotateAngle != 0) {
                    canvas.restore();
                }
            }
            if (slideshow != null)
                slideshow.onDraw(canvas);
            if (sourceVisible())
                webSource.onDraw(canvas);
        }
        Actions aa = Actions.active;
        if (aa!=null)
            aa.onDraw(canvas);

        Logger.draw(canvas);
    }

    PanoImage addPanoImage(float tileWidth, float tileHeight){
        PanoImage item = new PanoImage(tileWidth, tileHeight);
        addItem(item);
        return item;
    }

    WebText addText(String text,String href){
        if (text == null) return null;
        if (text.length() == 0) return null;
        WebText item = new WebText(font_bold, S.text_size * font_scaling);
        if (href != null)
            item.href = getAbsUrl(href);
        item.setText(text);
        addItem(item);
        return item;
    }

    WebText addText(String text){
        return addText(text, null);
    }

    WebImage addImage(Bitmap bitmap, String href) {
        WebImage image = new WebImage(bitmap, href);
        addItem(image);
        images.add(image);
        return image;
    }

    WebImage addImage(String url, String href)
    {
        if (url == null) return null;
        if (url.length() == 0) return null;
        String src = getAbsUrl(url);
        if (S.blockedImages.contains(src)) return null;
        if (href != null) {
            href = getAbsUrl(href);
            if (href.endsWith("javascript:;")) {
                href = src.replace("small", "big");
            }
            else {
                int i = src.indexOf("?width=");
                if (i > 0)
                    href = src.substring(0, i);
            }
        }
        WebImage image = new WebImage(src, href);
        addItem(image);
        images.add(image);
        return image;
    }

    boolean newrow = false;
    int srcpos1 = -1;
    int srcpos2 = -1;
    boolean font_bold = false;
    float font_scaling = 1.0f;


    void viewSource ()
    {
        if (webSource != null) {
            webSource.visible = !webSource.visible;
            invalidLayout = true;
        }
    }

    boolean sourceVisible ()
    {
        return webSource != null && webSource.visible;
    }

    void download(URLConnection connection, InputStream inputStream) throws Exception
    {
        String fileName = connection !=null ? connection.getHeaderField("Content-Disposition") : null;
        if (fileName != null) {
            int i = fileName.indexOf(C.equals);
            if (i > 0) {
                fileName = fileName.substring(i+1);
                if (fileName.startsWith(String.valueOf(C.quote))) {
                    fileName = fileName.substring(1, fileName.length()-1);
                }
            }
        }
        else {
            fileName = S.getFileName(S.decodeUrl(pageUrl));
        }
        fileName = S.download_folder + fileName;
        addText(pageUrl, pageUrl);
        newrow = true;
        WebText dl = addText("downloading...", null);
        addText(fileName, C.file+fileName);
        invalidateLayout();
        new UrlDownloader(connection, inputStream, fileName, new WebProgress(this));
        dl.setText("downloaded");
    }
    void decode (URLConnection connection, InputStream inputStream, String contentType) throws Exception
    {
        pageEncoding = null;
        if (contentType.contains(C.utf8))
            pageEncoding = C.utf8;
        else if (contentType.contains(C.windows1251))
            pageEncoding = C.windows1251;
        else
            pageEncoding = connection != null ? connection.getContentEncoding() : null;
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        byte[] buff = new byte[2048];
        int length;
        while ((length = inputStream.read(buff)) != -1){
            if (pageEncoding == null)
                pageEncoding = S.guessEncoding(buff, length);
            os.write(buff, 0, length);
        }
        if (pageEncoding==null) pageEncoding=C.utf8;
        String text = os.toString(pageEncoding);
        decoding = true;
        if (siteUrl!=null && (siteUrl.contains("youtube.com") || siteUrl.contains("youtu.be"))) {
            webSource = new WebSource(text);
            decodeyoutube(text);
        }
        else if (S.isTextType(pageType) || (contentType != null && contentType.equalsIgnoreCase("text/plain") )) {
            addItem(new TextFile(text, pageUrl, pageEncoding));
        }
        else {
            webSource = new WebSource(text);
            decode(text, false);
            while(divs.last() != null)
                closeDiv(divs.last().getClass());
            if (dom.size() == 0 && siteUrl != null && siteUrl.equals("https://t.co")) {
                int i1 = text.indexOf("URL=");
                if (i1 > 0) {
                    i1+=4;
                    int i2 = text.indexOf(C.quote, i1);
                    if (i2 > 0) {
                        String url = text.substring(i1, i2);
                        if (url.contains(C.video)){
                            pageUrl = "https://www.savetweetvid.com/downloader";
                            setSiteUrl(pageUrl);
                            form = new WebForm(pageUrl, C.POST);
                            form.addInput(null, "url", url, null);
                            referer = "https://www.savetweetvid.com/";
                            downloadUrl(pageUrl, this, referer, form);
                            return;
                        }
                    }
                }
            }
            if (!centered()){
                newrow=true;
                addPrevNextPageUrl();
            }
        }
        decoding = false;
    }

    boolean addStreams(String src, String name){
        name += C.backslash; name += C.quote; name += C.column; name += C.open_square_bracket;
        int i1 = src.indexOf(name);
        if(i1>0){
            i1+=name.length();
            int i2 = src.indexOf(C.close_square_bracket, i1);
            if (i2>i1){
                newrow = true;
                srcpos1 = i1;
                src = src.substring( i1, i2);
                ArrayList<String> streams = new ArrayList<>();
                ArrayList<Integer> pos1 = new ArrayList<>();
                ArrayList<Integer> pos2 = new ArrayList<>();
                i1 = 0;
                int braces = 0;
                for(i2 = 0; i2 < src.length(); i2++) {
                    char c = src.charAt(i2);
                    if (c == C.open_brace) {
                        if (braces == 0)
                            i1 = i2;
                        braces++;
                    }
                    else if (c == C.close_brace) {
                        braces--;
                        if (braces == 0) {
                            String stream = S.getHtmlText(src, i1, i2);
                            if (stream.contains("lsig=")) {
                                pos1.add(srcpos1+i1);
                                pos2.add(srcpos1+i2);
                                streams.add(stream);
                            }
                        }
                    }
                }
                if (streams.size() == 0)
                    return false;
                String[] urls = new String[streams.size()];
                int audioUrlIndex = 0;
                for (int i = 0; i < streams.size(); i++) {
                    String stream = streams.get(i);
                    String url = S.getJsonAttribute(stream, "url");
                    if (url == null)
                        return false;
                    urls[i] = url;
                    if (audioUrlIndex == 0 && url.contains("mime=audio%2Fmp4")) {
                        audioUrlIndex = i;
                    }
                }
                for (int i = 0; i < streams.size(); i++){
                    String stream = streams.get(i);
                    srcpos1 = pos1.get(i);
                    srcpos2 = pos2.get(i);
                    String quality = S.getJsonAttribute(stream, stream.indexOf("qualityLabel"));
                    if (quality == null)
                        continue;
                    String type = S.getJsonAttribute(stream, "mimeType");
                    if (type == null || !type.contains("video/mp4"))
                        continue;
                    if (audioUrlIndex == 0)
                        addText(quality, urls[i]);
                    else
                        addItem(new AdaptiveVideo(quality, urls[i], urls[audioUrlIndex]));
                }
                if (audioUrlIndex != 0) {
                    srcpos1 = pos1.get(audioUrlIndex);
                    srcpos2 = pos2.get(audioUrlIndex);
                    addText("audio", urls[audioUrlIndex]);
                }
                return true;
            }
        }
        return false;
    }

    void addThumbnail(String src, int i1)
    {
        String ss = "hqdefault.webp";
        i1 = src.indexOf(ss, i1+1);
        if (i1 > 0) {
            int i2 = src.lastIndexOf(C.http, i1);
            if (i2 > 0 && i2 < i1) {
                String thumb = S.getHtmlText(src, i2, i1+ss.length());
                srcpos1 = i2;
                srcpos2 = i1;
                if (thumb != null) addImage(thumb, null);
            }
        }
    }

    void decodeyoutube (String src)
    {
        addThumbnail(src, 0);

        openDiv(new WebDiv());
        String title = null;
        int i1 = src.indexOf("videoDetails\":{");
        if (i1 > 0 && (i1 = src.indexOf("title", i1)) > 0 && (title = S.getJsonAttribute(src, i1)) != null) {
            srcpos1 = i1;
            srcpos2 = i1 + title.length();
        }
        else if ((i1 = src.indexOf("\"content\\\"")) > 0)
        {
            i1 = src.indexOf("\"video\\\"", i1)+1;
            if (i1 > 0) {
                i1 = src.indexOf("\"title\\\"", i1)+1;
                if (i1 > 0) {
                    int i2 = src.indexOf(C.comma, i1)+1;
                    if (i2 > i1) {
                        String json = S.getHtmlText(src, i1, i2);
                        title = S.getJsonAttribute(json, 1);
                        srcpos1 = i1;
                        srcpos2 = i2;
                    }
                }
            }
        }
        if (title != null)
            addText(title);

        newrow = true;

        if (addStreams(src, "formats")) {
            addStreams(src, "adaptiveFormats");
        }
        else {
				/*
				WebForm form = new WebForm("https://bitdownloader.com/download?video=", POST);
				form.addInput(null, "url", pageUrl, null);
                addItem(form);
                */
            String[] sites = S.youtube_download_sites.split(String.valueOf(C.newline));
            for(String site : sites ) {
                String url = site + S.encodeUrl(pageUrl,C.utf8);
                addText(url, url);
                newrow = true;
            }
        }

        closeDiv(WebDiv.class);

        i1 = 0;
        while ((i1 = src.indexOf("compactVideoRenderer",i1))>0)
        {
            int i2 = src.indexOf("videoId", i1);
            String videoId = S.getJsonAttribute(src, i2);
            if (videoId != null)
            {
                i2 = src.indexOf("title\":{\"runs\":[{\"text", i1);
                title = S.getJsonAttribute(src, i2 + 22);
                if (title != null) {
                    srcpos1 = i1;
                    srcpos2 = i2;
                    String url = getAbsUrl("/watch?v=" + videoId);
                    String thumbnal = getAbsUrl("//i.ytimg.com/vi/" + videoId + "/mqdefault.jpg");
                    openDiv(new WebDiv());
                    addImage(thumbnal, url);
                    addText(title, url);
                    closeDiv(WebDiv.class);
                }
            }
            i1++;
        }

        i1 = src.indexOf("related_videos");
        if(i1>0){
            i1+=16;
            int i2 = src.length();
            int op = 0;
            for(int i=i1;i<i2;i++){
                char c = src.charAt(i);
                if (c == C.open_brace)
                    op++;
                else if (c == C.close_brace)
                    op--;
                else if (c == C.close_square_bracket && op == 0)
                    break;
                else if (c == C.comma && op == 0){
                    String json = S.getHtmlText(src,i1,i);
                    srcpos1 = i1;
                    srcpos2 = i;
                    int i3 = json.indexOf("url", 1);
                    String thumb = S.getJsonAttribute(json, i3);
                    i3 = json.indexOf("watch_link", 1);
                    String watch = S.getJsonAttribute(json, i3);
                    newrow = true;
                    openDiv(new WebDiv());
                    addImage(thumb,watch);
                    i3 = json.indexOf("title", 1);
                    title = S.getJsonAttribute(json, i3);
                    addText(title,watch);
                    closeDiv(WebDiv.class);
                    i1= i+1;
                }
            }
        }

    }


    class DecodingActions extends Actions {
        class DecodingAction extends Action
        {
            String text="";
            @Override
            String getName(){return text;}
            @Override
            void onClick(float x, float y) { decoding = false; }
        }
        DecodingAction decodingAction;
        DecodingActions(){
            decodingAction=new DecodingAction();
            items.add(decodingAction);
            show(0,0);
        }

        @Override
        boolean closeOnBack() {
            decoding = false;
            return true;
        }
    }
    boolean decoding = false;
    void decode (String html, boolean body) throws Exception
    {
        int tagi = 0; int otagi = 0; int ctagi = 0;
        boolean wbr = false;
        int n = html.length();
        WebForm form = null;
        WebVideo video = null;
        DecodingActions decodingActions = null;
        int i; char c;
        int decoded = n > 500000 ? n / 5 : n;
        String tag = null;
        String otag = null;
        String anchor = null;
        String option = null;
        for (i = 0; i < n && decoding; i++)
        {
            c = html.charAt(i);
            if (c == C.open)
            {
                int index = i;
                while (c==C.open || c==C.space || c==C.newline) {
                    c = html.charAt(++i);
                }
                otagi = tagi;
                otag = tag;
                tagi = i;
                StringBuilder tagBuilder = new StringBuilder();
                while (c!=C.space && c!=C.close && c!=C.open && c!=C.newline) {
                    tagBuilder.append(c);
                    c = html.charAt(++i);
                }
                tag = tagBuilder.toString().toLowerCase();
                if (tag.equals("!--")) {
                    i = html.indexOf("-->", tagi);
                    if (i<0) break;
                    i+=2;
                    if (otagi == 0) continue;
                }
                else if (tag.equals("script") || tag.equals("style")) {
                    StringBuilder t = new StringBuilder();
                    t.append(C.open); t.append(C.slash); t.append(tag);
                    tag = t.toString();
                    int i2 = html.indexOf(tag, tagi);
                    if (i2<0) {
                        i2 = html.indexOf(tag.toUpperCase(), tagi);
                    }
                    if (i2>0){
                        i = i2 + tag.length()-1;
                        if (otagi == 0) continue;
                    }
                }
                if (body && ctagi>0 && ctagi<index)
                {
                    String text = S.getHtmlText(html, ctagi, index).trim();
                    if (text.length() > 0 && !(text.charAt(0) == C.open && text.length() > 1)){
                        srcpos1 = ctagi;
                        srcpos2 = index;
                        ctagi = 0;
                        if (option != null && form!=null){
                            form.addOption(text, S.getAttribute(option, "value"), option.contains("selected"));
                        } else {
                            boolean add = true;
                            if (wbr && lastAddedItem !=null){
                                WebItem item = lastAddedItem;
                                if (item.getClass().equals(WebText.class)){
                                    WebText webText = (WebText)item;
                                    webText.setText(webText.text+text);
                                    add = false;
                                }
                            }
                            wbr = false;
                            if (add) addText(text , anchor);
                        }
                    }
                }
            }
            if (c == C.close)
            {
                if (tagi > 0)
                {
                    if (body == false)
                    {
                        if (tag.equals("body"))
                            body = true;
                        else if (tag.equals("configuration"))
                        {
                            String attributes = S.getAttributes(html, tagi, i);
                            String attr = S.getAttribute(attributes, "download_folder");
                            if (attr !=null) S.download_folder = attr;
                            attr = S.getAttribute(attributes, "output_folder");
                            if (attr !=null) S.output_folder = attr;
                            attr = S.getAttribute(attributes, "default_scale");
                            if (attr !=null) S.default_scale = Float.parseFloat(attr);
                            attr = S.getAttribute(attributes, "scroll_to_zoom");
                            if (attr !=null) S.scroll_to_zoom = Float.parseFloat(attr);
                            attr = S.getAttribute(attributes, "fling_treshold");
                            if (attr !=null) S.fling_treshold = Float.parseFloat(attr);
                            attr = S.getAttribute(attributes, "fling_to_scroll");
                            if (attr !=null) S.fling_to_scroll = Float.parseFloat(attr);
                            attr = S.getAttribute(attributes, "scroll_attenuation");
                            if (attr !=null) S.scroll_attenuation = Float.parseFloat(attr);
                            attr = S.getAttribute(attributes, "text_size");
                            if (attr !=null) S.text_size = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "mark_size");
                            if (attr !=null) S.mark_size = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "selected_map");
                            if (attr !=null) S.selected_map = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "menu_text_size");
                            if (attr !=null) S.action_text_size = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "subtitle_text_size");
                            if (attr !=null) S.subtitle_text_size = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "image_max_size");
                            if (attr !=null) S.image_max_size = Float.parseFloat(attr) * 1048576;
                            attr = S.getAttribute(attributes, "image_hash_size");
                            if (attr !=null) S.image_hash_size = Integer.parseInt(attr) * 1048576;
                            attr = S.getAttribute(attributes, "jpeg_quality");
                            if (attr !=null) S.jpeg_quality = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "color_text");
                            if (attr !=null) S.color_text = Color.parseColor(attr);
                            attr = S.getAttribute(attributes, "color_link");
                            if (attr !=null) S.color_link = Color.parseColor(attr);
                            attr = S.getAttribute(attributes, "color_visited");
                            if (attr !=null) S.color_visited = Color.parseColor(attr);
                            attr = S.getAttribute(attributes, "color_selected");
                            if (attr !=null) S.color_selected = Color.parseColor(attr);
                            attr = S.getAttribute(attributes, "color_background");
                            if (attr !=null) S.color_background = Color.parseColor(attr);
                            attr = S.getAttribute(attributes, "home_location");
                            if (attr !=null) S.home_location = S.getMapLocation(attr);
                            attr = S.getAttribute(attributes, "gps_update_interval");
                            if (attr !=null) S.gps_update_interval = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "gps_update_distance");
                            if (attr !=null) S.gps_update_distance = Integer.parseInt(attr);
                            attr = S.getAttribute(attributes, "portrait_layout");
                            if (attr !=null) S.portrait_layout = Boolean.parseBoolean(attr);
                            attr = S.getAttribute(attributes, "full_screen");
                            if (attr !=null && S.full_screen != Boolean.parseBoolean(attr))
                                Pages.activity.toggleFullScreen();
                            attr = S.getAttribute(attributes, "pointer_dx");
                            if (attr !=null) S.pointer_dx = Float.parseFloat(attr);
                            attr = S.getAttribute(attributes, "pointer_dy");
                            if (attr !=null) S.pointer_dy = Float.parseFloat(attr);
                            attr = S.getAttribute(attributes, "youtube_download_sites");
                            if (attr !=null) S.youtube_download_sites = attr;
                            S.text_size *= S.default_scale;
                            S.action_text_size *= S.default_scale;
                            S.subtitle_text_size *= S.default_scale;
                        }
                    }
                    else {
                        srcpos1 = tagi;
                        srcpos2 = i;
                        if (tag.equals("a")) {
                            anchor = S.getAttributes(html, tagi, i);
                            String hr = S.getAttribute(anchor, "title");
                            if (hr == null || !hr.startsWith(C.http))
                                hr = S.getAttribute(anchor, C.href);
                            anchor = hr;
                        }
                        else if (tag.equals("/a"))
                        {
                            anchor = null;
                        }
                        else if (tag.equals("div"))
                        {
                            String attributes = S.getAttributes(html, tagi, i);
                            String id = S.getAttribute(attributes,"id");
                            if (id != null) {
                                if (id.equals("disqus_thread")) {
                                    int i1 = siteUrl.indexOf(C.dot)+1;
                                    int i2 = siteUrl.lastIndexOf(C.dot);
                                    if (i1>=i2)
                                        i1 = siteUrl.indexOf(C.backslash)+2;
                                    new DisqusThread(C.disqus_comments
                                            + siteUrl.substring(i1,i2) + "&t_u="
                                            + S.encodeUrl(pageUrl, pageEncoding));
                                }
                                else if (id.startsWith("jwplayer"))
                                    addItem(new WebVideo(this, attributes, i));
                            }
                            openDiv(new WebDiv());
                        }
                        else if (tag.equals("/div"))
                        {
                            closeDiv(WebDiv.class);
                        }
                        else if (tag.equals(C.img))
                        {
                            String attributes = S.getAttributes(html, tagi, i);
                            String url = S.getAttribute(attributes, "src");
                            if (url==null || url.startsWith("data:")) {
                                url = S.getAttribute(attributes, "data-original");
                                if (url == null)
                                    url = S.getAttribute(attributes, "data-src");
                            }

                            String hr = anchor;
                            boolean add = true;
                            if (lastAddedItem != null){
                                WebItem item = lastAddedItem;
                                if (hr == null){
                                    if (otagi > 0){
                                        if (item.href != null){
                                            hr = item.href;
                                            if (item instanceof WebText)
                                                ((WebText)item).text = C.empty;
                                        }
                                    }
                                }
                                else if (item.href != null && item instanceof WebImage && item.href.endsWith(hr)){
                                    add = otagi == 0;
                                }
                            }
                            if (add)
                                addImage(url, hr);
                        }
                        else if (tag.equals("br") || tag.equals("p"))
                        {
                            newrow = true;
                        }
                        else if (tag.equals("b"))
                        {
                            font_bold=true;
                        }
                        else if (tag.equals("/b"))
                        {
                            font_bold=false;
                        }
                        else if (tag.equals("/td"))
                        {
                            closeDiv(WebTD.class);
                        }
                        else if (tag.equals("td"))
                        {
                            String attributes = S.getAttributes(html, tagi, i);
                            openTD(new WebTD(), attributes);
                        }
                        else if (tag.equals("th"))
                        {
                            font_bold = true;
                            String attributes = S.getAttributes(html, tagi, i);
                            openTD(new WebTD(), attributes);
                        }
                        else if (tag.equals("/th")) {
                            closeDiv(WebTD.class);
                            font_bold = false;
                        }
                        else if (tag.equals("tr"))
                        {
                            openDiv(new WebTR());
                        }
                        else if (tag.equals("/tr"))
                        {
                            closeDiv(WebTR.class);
                        }
                        else if (tag.equals("strong"))
                        {
                            font_bold=true;
                        }
                        else if (tag.equals("/strong"))
                        {
                            font_bold=false;
                        }
                        else if (tag.equals("sup") || tag.equals("super"))
                        {
                            font_scaling=0.66f;
                        }
                        else if (tag.equals("/sup") || tag.equals("/super"))
                        {
                            font_scaling=1.0f;
                        }
                        else if (tag.equals("table"))
                        {
                            openDiv(new WebTable());
                        }
                        else if (tag.equals("/table"))
                        {
                            closeDiv(WebTable.class);
                        }
                        else if (tag.equals("h1"))
                        {
                            font_scaling=1.5f;
                            newrow = true;
                        }
                        else if (tag.equals("h2"))
                        {
                            font_scaling=1.20f;
                            newrow = true;
                        }
                        else if (tag.equals("h3"))
                        {
                            font_scaling=1.12f;
                            newrow = true;
                        }
                        else if (tag.equals("h4"))
                        {
                            font_scaling=1.06f;
                            newrow = true;
                        }
                        else if (tag.equals("/h1") || tag.equals("/h2"))
                        {
                            font_scaling=1.0f;
                            newrow = true;
                        }
                        else if (tag.equals("/h3") || tag.equals("/h4"))
                        {
                            font_scaling=1.0f;
                            newrow = true;
                        }
                        else if (tag.equals("ul"))
                        {
                            openDiv(new WebDiv());
                        }
                        else if (tag.equals("/ul"))
                        {
                            closeDiv(WebDiv.class);
                        }
                        else if (tag.equals("li"))
                        {
                            openDiv(new WebDiv());
                        }
                        else if (tag.equals("/li"))
                        {
                            closeDiv(WebDiv.class);
                        }
                        else if (tag.equals("section"))
                        {
                            newrow = true;
                            openDiv(new WebDiv());
                        }
                        else if (tag.equals("/section"))
                        {
                            closeDiv(WebDiv.class);
                            newrow = true;
                        }
                        else if (tag.equals("wbr")){
                            wbr = true;
                        }
                        else if (tag.equals("var"))
                        {
                            String url = S.getAttribute(S.getAttributes(html, tagi, i), "title");
                            if (url != null && S.isImage(url)){
                                addImage(url, anchor);
                            }
                        }
                        else if (tag.equals("iframe"))
                        {
                            String url = getAbsUrl(S.getAttribute(S.getAttributes(html, tagi, i), "src"));
                            if (url != null){
                                if (url.contains("youtube.com/embed/")) url = url.replace("embed/","watch?v=");
                                addText(url, url);
                                newrow = true;
                            }
                        }
                        else if (tag.equals("video") || tag.equals("video-js"))
                        {
                            newrow = true;
                            video = new WebVideo(this, S.getAttributes(html, tagi, i), i);
                            addItem(video);
                        }
                        else if (tag.equals("/video") || tag.equals("video-js"))
                        {
                            video = null;
                        }
                        else if (tag.equals("source"))
                        {
                            String url = getAbsUrl(S.getAttribute(S.getAttributes(html, tagi, i), "src"));
                            if (video != null && url != null){
                                video.href = url;
                                video.setText(url);
                            }
                        }
                        else if (tag.equals("form"))
                        {
                            String attributes = S.getAttributes(html, tagi, i);
                            String action = S.getAttribute(attributes, "action");
                            String method = S.getAttribute(attributes, "method");
                            if (action!=null) {
                                action = getAbsUrl(S.decodeUrl(action));
                                if (action == null) action = pageUrl;
                                openDiv(new WebDiv());
                                form = new WebForm(action, method);
                            }
                        }
                        else if (tag.equals("/form"))
                        {
                            if (form!=null) {
                                addItem(form);
                                form = null;
                                closeDiv(WebDiv.class);
                            }
                        }
                        else if (tag.equals(C.input))
                        {
                            if (form != null)  {
                                String attributes = S.getAttributes(html, tagi, i);
                                WebItem input = form.addInput(S.getAttribute(attributes, "type"),
                                        S.getAttribute(attributes, "name"),
                                        S.getAttribute(attributes, "value"),
                                        attributes);
                                if (input != null) addItem(input);
                            }
                        }
                        else if (tag.equals("select"))
                        {
                            if (form != null) {
                                WebSelectInput input = form.addSelect(S.getAttribute(S.getAttributes(html, tagi, i), "name"));
                                if (input != null) addItem(input);
                            }
                        }
                        else if (tag.equals("option"))
                        {
                            option = S.getAttributes(html, tagi, i);
                        }
                        else if (tag.equals("/option"))
                        {
                            option = null;
                        }
                    }
                    ctagi = i+1;
                    tagi = otagi;
                    tag = otag;
                    otagi = 0;
                    otag = null;
                }
                if (i>decoded){
                    decoded += n/5;
                    int p = (i*100)/n;
                    if (decodingActions == null) decodingActions = new DecodingActions();
                    decodingActions.decodingAction.text=String.format("decoding %d%%",p);
                    decodingActions.resize();
                    postInvalidate();
                }
            }
        }

        if (decodingActions!=null && Actions.active!=null)
            Actions.active = null;
    }

    ArrayList<String> localFolders = null;
    ArrayList<String> localFiles = null;

    void loadLocalFiles(ArrayList<String> locals, boolean directory) {
        siteUrl = S.getLocalPath(pageUrl);
        int lastSlashIndex = siteUrl.lastIndexOf(C.slash);
        if (lastSlashIndex < siteUrl.length() - 1)
            siteUrl = siteUrl.substring(0, lastSlashIndex + 1);
        S.loadLocalFilesSorted(locals, siteUrl, directory);
    }

    String getLocalMediaFile(String fileUrl, boolean next){
        String fileName = S.getFileName(fileUrl);
        String path = S.getLocalPath(fileUrl);
        path = path.substring(0,path.lastIndexOf(C.slash)+1);
        ArrayList<String> localFiles = new ArrayList<>();
        if (S.sibling_folders) {
            S.loadLocalFilesSorted(localFiles, path, false);
        }
        else {
            localFiles = Pages.active() == this ? Pages.prev().localFiles : Pages.active().localFiles;
            if (localFiles == null)
                return null;
        }
        for(int i = 0; i < localFiles.size(); i++) {
            if (localFiles.get(i).equals(fileName)) {
                for (i = next?i+1:i-1; next?i<localFiles.size():i>=0; i+=next?1:-1) {
                    if (S.isMedia(localFiles.get(i))){
                        return C.file + path + localFiles.get(i);
                    }
                }
                break;
            }
        }
        if (S.sibling_folders) {
            String folderName = S.getFolderName(path);
            ArrayList<String> localFolders = new ArrayList<>();
            path = path.substring(0,path.lastIndexOf(C.slash, path.length()-2));
            S.loadLocalFilesSorted(localFolders, path, true);
            for(int i = 0; i < localFolders.size(); i++) {
                if (localFolders.get(i).equals(folderName)) {
                    path += C.slash + localFolders.get(next ?
                            (i < localFolders.size()-1 ? ++i : 0):
                            (i > 0 ? --i : localFolders.size()-1));
                    localFiles.clear();
                    S.loadLocalFilesSorted(localFiles, path, false);
                    path += C.slash;
                    for (i=next?0:localFiles.size()-1; next?i<localFiles.size():i>=0; i+=next?1:-1) {
                        if (S.isMedia(localFiles.get(i))){
                            return C.file + path + localFiles.get(i);
                        }
                    }
                    break;
                }
            }
        }
        return null;
    }

    void removeLocalFile(String url){
        String fileName = S.getFileName(url);
        if (localFiles.contains(fileName)) {
            localFiles.remove(fileName);
        }
        float bottom = panY;
        for (int i=0; i<dom.size(); i++) {
            WebItem item = dom.get(i);
            if (item.newrow)
                bottom += item.height;
            if (item instanceof LocalFile){
                LocalFile localFile = (LocalFile)item;
                if (localFile.text.equals(fileName)) {
                    dom.remove(i);
                    if (bottom < 0)
                        panX = panY = 0;
                    invalidLayout = true;
                    if (Pages.active() == this)
                        postInvalidate();
                    break;
                }
            }
        }
    }

    void loadParentFolders(String url)
    {
        String[] folders = url.split(String.valueOf(C.slash));
        String path = url.substring(0, url.indexOf(C.column) + 4);
        addText(String.valueOf(C.slash));
        for (int i = 3; i < folders.length; i++)
        {
            path += folders[i];
            boolean addSlash = i < folders.length -1 || url.charAt(url.length()-1) == C.slash;
            if (addSlash)
                path += C.slash;
            addItem(new LocalFile(folders[i], path));
            if (addSlash)
                addText(String.valueOf(C.slash));
        }
        newrow = true;
        if (url.charAt(url.length()-2) == C.slash) {
            addItem(new LocalFile(".", url));
        } else {
            int index = url.lastIndexOf(C.slash, url.length()-2);
            addItem(new LocalFile("..", url.substring(0, index + 1)));
        }
    }

    private void invalidateFolder()
    {
        float bottom = panY;
        for(WebItem item : dom)
            if (item.newrow)
                bottom += item.height;
        if (bottom < 0)
            panX = panY = 0;
        invalidateLayout();
    }

    void loadLocalFolder(String url) {
        pageUrl = url;
        loadLocalFolder();
    }

    void loadLocalFolder() {
        dom.clear();
        localFolders = new ArrayList<>();
        localFiles = new ArrayList<>();
        loadParentFolders(pageUrl);
        String path = S.getLocalPath(pageUrl);
        if (S.isZip(pageUrl)) {
            try {
                ZipFile zf = new ZipFile(path);
                Enumeration<? extends ZipEntry> entries = zf.entries();
                while ( entries.hasMoreElements() ) {
                    ZipEntry ze = entries.nextElement();
                    if (ze.isDirectory())
                        continue;
                    S.addSorted(localFiles, ze.getName());
                }
                zf.close();
                path = C.zip + pageUrl + C.slash;
            } catch (IOException e) {
                onError(this, null, e.getMessage());
            }
        }
        else if (S.isContainer(pageUrl)) {
            try {
                ContainerInput container = new ContainerInput(path);
                while (container.next())
                    S.addSorted(localFiles, container.fileName);
                container.close();
            } catch (Exception e) {
                onError(this, null, e.getMessage());
            }
            path = ContainerOutput.EXT + pageUrl + C.slash;
        }
        else if (S.isMtpFolder(pageUrl)) {
            loadMtpFolder();
        }
        else {
            loadLocalFiles(localFolders, true);
            loadLocalFiles(localFiles, false);
            path = pageUrl;
        }
        for (int i = 0; i < localFolders.size(); i++) {
            newrow = true;
            addItem(new LocalFile(localFolders.get(i), pageUrl + localFolders.get(i) + C.slash));
        }
        for (int i = 0; i < localFiles.size(); i++) {
            newrow = true;
            addItem(new LocalFile(localFiles.get(i), path + localFiles.get(i)));
        }
        invalidateFolder();
    }


    void loadMtpFolder()
    {
        loadParentFolders(pageUrl);
        addItem(new LocalFile(S.output_folder, C.file + S.output_folder));
        try {
            Mtp.loadMtpFolder(pageUrl, localFolders, localFiles, getContext());
        } catch (Exception e) {
            newrow = true;
            addText("error " + e.getMessage());
        }
    }

    @Override
    public void download(WebPage page) {
        WebImage image = Pages.findImage(pageUrl);
        if (image != null) {
            addImage(image.bitmap, pageUrl);
            invalidateLayout();
        }
        else {
            int i = pageUrl.indexOf(C.newline);
            if (i > 0) {
                String video = pageUrl.substring(0,i);
                String audio = pageUrl.substring(i+1);
                pageUrl = video.substring(0, video.length()-4) + C.mpa;
                downloadUrl(audio, this, referer, form);
                pageUrl = video;
                downloadUrl(video, this, referer, form);
            }
            else
                downloadUrl(pageUrl, this, referer, form);
        }
    }

    @Override
    public void onError(WebPage page, URLConnection connection, String error)
    {
        if (decoding){
            decoding = false;
            divs.clear();
            dom.clear();
        }
        if (pageUrl.equals(C.file + S.home_folder + C.home_page_file)) {
            pageUrl = C.file + S.root_folder;
            loadLocalFolder();
            return;
        }
        addText(pageUrl, pageUrl);
        newrow = true;
        addText("error " + error);
    }

    @Override
    public void onResponse(WebPage page, URLConnection connection, InputStream inputStream) throws Exception
    {
        String contentType = connection != null ? connection.getContentType() : null;
        if (contentType != null)
            contentType = contentType.toLowerCase();
        else
            contentType = C.empty;
        if (pageType != null && pageType.equals(C.download))
            download(connection, inputStream);
        else if (S.isTextType(contentType) || S.isTextType(pageType)) {
            decode(connection, inputStream, contentType);
//					if (items.size()!=1){
//						newrow=true;
//						addText(contentType);
//						newrow = true;
//						addText(header);
//						newrow=true;
//						addText(cookies.getCookies(siteUrl));
//						newrow=true;
//					}
        }
        else if (S.isImageType(contentType) || S.isImage(pageUrl)) {
            Bitmap bitmap = S.decodeImage(inputStream);
            addImage(bitmap, pageUrl);
        }
        else if (S.isVideoType(contentType) || S.isVideo(pageUrl))
            Pages.add(pageUrl, C.video);
        else
            download(connection, inputStream);
    }

    void onResponse(String url, IDownload downloadable, URLConnection connection, InputStream inputStream) throws Exception
    {
        String header = connection != null ? connection.getHeaderFields().toString() : null;
        String sc = S.getAttribute(header, C.setcookie);
        if(siteUrl!=null && sc!=null){
            String[] cs = sc.split(",");
            for(int i=0;i<cs.length;i++){
                String[] c = cs[i].split(";")[0].split("=");
                if (c.length > 1){
                    //log(setcookie);
                    //log(siteUrl);
                    //log(c[0].trim());
                    //log(c[1].trim());
                    Cookies.setCookie(siteUrl,c[0].trim(),c[1].trim());
                }
            }
        }

        int code = 200; //OK
        if (connection != null && connection instanceof HttpURLConnection){
            HttpURLConnection c = (HttpURLConnection)connection;
            code = c.getResponseCode();
        }
        //log(String.format("code %d", code));
        if (code == 200) {
            downloadable.onResponse(this, connection, inputStream);
        }
        else if (Pages.active() == this) {
            if (code == 301 || code == 302 || code ==303 || code ==307) {
                String site = getSite(url);
                String location = connection.getHeaderField("Location");
                location = buildUrl(site, url, location);
                if (downloadable == this) {
                    addText("Redirected to");
                    addText(location, location);
                    newrow = true;
                    referer = url;
                    pageUrl = location;
                    setSiteUrl(pageUrl);
                    form = null;
                    Downloader.download(this);
                } else {
                    downloadUrl(location, downloadable, url, null);
                }
            } else {
                addText(pageUrl);
                newrow=true;
                addText("code ="+code);
            }
        }
    }

    void downloadUrl(String url, IDownload download, String referer, WebForm form) {
        InputStream is = null;
        URLConnection urlConnection = null;
        try {
            if (S.isZipEntry(url) || S.isContainerFile(url)) {
                if (S.isText(url))
                    pageType = C.text;
                FileReader reader = new FileReader(url);
                if (reader.zipInput != null) {
                    if (Pages.active() == this)
                        download.onResponse(this, null, reader.zipInput);
                    reader.close();
                    return;
                }
                byte[] buffer = new byte[(int)reader.size];
                reader.read(buffer);
                reader.close();
                is = new ByteArrayInputStream(buffer);
                if (Pages.active() == this)
                    download.onResponse(this, null, is);
                is.close();
                is = null;
                return;
            }
            else if (S.isMtpFile(url)) {
                if (S.isText(url))
                    pageType = C.text;
                is = Mtp.getMtpStream(url);
                if (is != null) {
                    if (Pages.active() == this)
                        download.onResponse(this, null, is);
                    is.close();
                    is = null;
                }
                return;
            }
            //log(url);
            //url = url.replace("&&", "&");
            if (form != null && form.method.equals(C.GET)){
                url += url.indexOf(C.question) < 0 ? C.question : C.amp;
                url += form.getData(pageEncoding);
                //addText(url);
            }
            URL Url = new URL(url);
            //log("openConnection");
            urlConnection = Url.openConnection();
            urlConnection.setReadTimeout(16000 /* milliseconds */);
            urlConnection.setConnectTimeout(7000 /* milliseconds */);
            if (urlConnection instanceof HttpURLConnection){
                HttpURLConnection httpConnection = ((HttpURLConnection)urlConnection);
                httpConnection.setFollowRedirects(false);
/*
					if (urlConnection instanceof HttpsURLConnection &&
							android.os.Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
						HttpsURLConnection httpsConnection = ((HttpsURLConnection)urlConnection);
						httpsConnection.setSSLSocketFactory(new TLSSocketFactory());
					}
*/
                if (referer != null) {
                    httpConnection.setRequestProperty("Referer", referer);
                    //newrow = true;
                    //addText(referer);
                }
                if (siteUrl!=null){
                    //httpConnection.setRequestProperty("Origin", siteUrl);
                    String cookie = Cookies.getCookies(siteUrl);
                    if (cookie != null) {
                        int i;
                        if (url.contains("dl.php?t=") && (i=cookie.indexOf("bb_dl"))>0)
                            cookie = cookie.substring(0, i+6) + url.substring(url.lastIndexOf(C.equals) + 1);
                        httpConnection.setRequestProperty("Cookie", cookie);
                    }
                }
                //httpConnection.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3205.0 Safari/537.36");
                httpConnection.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 4.4.2; V5 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Safari/537.36");

                if (form != null && form.method.equals(C.POST))
                {
                    //addText(url);
                    //newrow=true;
                    //addText(form.getData());
                    if (form.uploadFile != null) {
                        byte[] buffer = form.getMultipartData();
                        File file = new File(form.uploadFile.text);
                        httpConnection.setRequestProperty("Content-Length", String.valueOf(buffer.length + file.length()));
                        httpConnection.setRequestProperty("Content-Type","multipart/form-data; boundary="+S.boundary);
                        httpConnection.setDoOutput(true);
                        OutputStream output = httpConnection.getOutputStream();
                        FileInputStream input = new FileInputStream(file);
                        int bytesRead;
                        output.write(buffer);
                        while( (bytesRead = input.read(buffer)) > 0){
                            output.write(buffer, 0, bytesRead);
                        }
                        input.close();
                    }
                    else {
                        httpConnection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
                        httpConnection.setDoOutput(true);
                        OutputStreamWriter output = new OutputStreamWriter(httpConnection.getOutputStream());
                        output.write(form.getData(pageEncoding));
                        output.flush();
                    }
                }
            }
            //log("connect");
            urlConnection.connect();
            is = urlConnection.getInputStream();
            if (Pages.active() == this)
                onResponse(url, download, urlConnection, new BufferedInputStream(is));
            //log.setText(String.format("response %d", response));
            //log.setText(String.format("getInputStream %d", response));
            //log.setText(String.format("decoded %s", url));
            //conn.disconnect();
            //log.setText(String.format("decoded %s", url));
        } catch(Exception e) {
            //log("error " + e.getMessage());
            if (Pages.active() == this)
                download.onError(this, urlConnection, e.getMessage());
        } finally {
            if (is != null) {
                try {
                    is.close();
                    //conn.disconnect();
                    //log.setText(String.format("closed %s", url));
                } catch (Exception e) {  }
            }
            invalidateLayout();
        }
    }
}

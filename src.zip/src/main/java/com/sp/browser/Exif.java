package com.sp.browser;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;

class Exif {

    static final byte FF = (byte) 0xFF;
    static final byte SOI = (byte) 0xD8;
    static final byte EOI = (byte) 0xD9;
    static final byte[] EXIF = {0x45, 0x78, 0x69, 0x66, 0x00, 0x00};
    static final byte I = (byte) 0x49;
    //static final int ORIENTATION_UNDEFINED = 0;
    static final int ORIENTATION_NORMAL = 1;
    //static final int ORIENTATION_FLIP_HORIZONTAL = 2;  // left right reversed mirror
    static final int ORIENTATION_ROTATE_180 = 3;
    //static final int ORIENTATION_FLIP_VERTICAL = 4;  // upside down mirror
    //static final int ORIENTATION_TRANSPOSE = 5;  // flipped about top-left <--> bottom-right axis
    static final int ORIENTATION_ROTATE_90 = 6;  // rotate 90 cw to right it
    //static final int ORIENTATION_TRANSVERSE = 7;  // flipped about top-right <--> bottom-left axis
    static final int ORIENTATION_ROTATE_270 = 8;  // rotate 270 to right it

    static final short TAG_WIDTH = 0x0100;
    static final short TAG_HEIGHT = 0x0101;
    static final short TAG_DESCRIPTON = 0x010e;
    static final short TAG_MANIFACTURER = 0x010f;
    static final short TAG_MODEL = 0x0110;
    static final short TAG_ORIENTATION = 0x0112;
    static final short TAG_SOFTWARE = 0x0131;
    static final short TAG_RESX = 0x011a;
    static final short TAG_RESY = 0x011b;
    static final short TAG_RESUNIT = 0x0128;
    static final short TAG_DATE = 0x0132;
    static final short TAG_YCbCrC = 0x0212;
    static final short TAG_YCbCrP = 0x0213;
    static final short TAG_EXIFSUBF  = (short)0x8769;
    static final short TAG_COPYRIGHT  = (short)0x8298;


    static final short[] TAG_ID =  { TAG_WIDTH, TAG_HEIGHT, TAG_DESCRIPTON, TAG_MANIFACTURER, TAG_MODEL,
            TAG_ORIENTATION, TAG_SOFTWARE, TAG_DATE, TAG_RESX, TAG_RESY, TAG_RESUNIT,
            TAG_YCbCrC, TAG_YCbCrP, TAG_COPYRIGHT};

    static final String[] TAG_NAME = {"Width", "Height", "Description", "Manufacturer", "Model",
            "Orientation", "Software", "Date modified", "Resolution x", "Resolution y", "Resolution unit",
            "YCbCr C", "YCbCr P", "Copyright"};

    private byte[] b;
    private boolean isLittleEndian;
    ArrayList<Integer> exifs = new ArrayList<>();
    ArrayList<Integer> idfs = new ArrayList<>();
    ArrayList<Integer> tags = new ArrayList<>();
    int baseOffset;
    int exifIndex;
    int idfIndex;

    Exif(byte[] bytes) {
        b = bytes;
        int i = 0;
        while (i < b.length && b[i++] == FF) {
            byte marker = b[i++];
            if (marker == SOI)
                continue;
            if (marker == EOI)
                break;
            // Size of APP section including the size field itself.
            // This will be big-endian; convert as required.
            int size = getUShort(i);
            if (size <= 0)
                break;
            // Do we have APP1  marker?
            if (marker == (byte)0xE1)
                addExif(i+2);
            // Absolute location of the next APP section)
            i += size;
        }
    }

    void addExif(int i) {
        for(byte e : EXIF)
            if (e != b[i++])
                return;
        exifs.add(i);
    }

    void readIDFs() {
        // We are now at the TIFF header.
        // Save the offset to the start
        // of the TIFF header.
        idfs.clear();
        if (exifIndex < exifs.size()) {
            idfs = new ArrayList<>();
            int i = exifs.get(exifIndex);
            baseOffset = i;
            // Read the IFD byte order
            isLittleEndian = b[i++] == I;
            isLittleEndian &= b[i++] == I;
            // TIFF marker
            // Should always be [0x002A]
            i+=2;
            // Offset to the 0th IFD relative to TIFF header
            int idf = getInt(i);
            if (idf > 0) {
                // Read the IFD
                i = (baseOffset + idf);
                idfs.add(i);
                //idf = getInt(i);
            }
        }
    }

    void readTags() {
        tags.clear();
        if (idfs != null && idfIndex < idfs.size()) {
            tags = new ArrayList<>();
            int i = idfs.get(idfIndex);
            int fieldCount = getShort(i);
            i+=2;
            if (fieldCount > 30)
                fieldCount = 30;
            for(int f  = 0; f < fieldCount; f++) {
                short id = getTagId(i);
                if (id == TAG_EXIFSUBF)
                    idfs.add(baseOffset + getInt(i+8));
                else
                    tags.add(i);
                i+=12;
            }
        }
    }

    short getTagId(int i) {
        return getShort(i);
    }

    String getTagName(int i) {
        short id = getTagId(i);
        for (i=0;i<TAG_ID.length;i++)
            if (TAG_ID[i]==id)
                return TAG_NAME[i];
        return String.format("0x%X",id);
    }

    Object getTag(int i) {
        // Tag ID
        i+=2;
        // Field type
        short type = getShort(i); i+=2;
        // Count or components
        int count = getInt(i); i+=4;
        // Value
        // unsigned byte
        if (type == 1 || type == 7)
            return b[i];
        // ascii strings
        if (type == 2) {
            if (count > 4)
                i = baseOffset + getInt(i);
            StringBuilder sb = new StringBuilder();
            for (int c = 0; c < count; c++)
                sb.append((char)b[i++]);
            return sb.toString();
        }
        // unsigned short
        if (type == 3)
            return getUShort(i);
        // signed short
        if (type == 8)
            return getShort(i);
        // unsigned / signed long
        if (type == 4 || type == 9)
            return getInt(i);
        // unsigned / signed rational
        if (type == 5 || type == 10) {
            i = baseOffset + getInt(i);
            float nominator = getInt(i);
            float denominator = getInt(i+4);
            if (denominator != 0)
                return nominator/denominator;
        }
        // single float
        if (type == 11)
            return getFloat(i);
        // double float
        if (type == 12)
            return getDouble(i);
        return "";
    }

    void setTag(int i, Object v) {
        // Tag ID
        i+=2;
        // Field type
        int type = getShort(i); i+=2;
        // Count or components
        int count = getInt(i); i+=4;
        if (count == 1) {
            // Value
            if (type == 3 || type == 8)
                setShort(i, (int)v);
            else if (type == 4 || type == 9)
                setInt(i, (int)v);
        }
    }

    int orientation;
    int findTag(int id){
        for (exifIndex = 0; exifIndex < exifs.size(); exifIndex++) {
            readIDFs();
            for (idfIndex = 0; idfIndex < idfs.size(); idfIndex++) {
                readTags();
                for (int tag : tags)
                    if (getTagId(tag) == id)
                        return tag;
            }
        }
        exifIndex = idfIndex = 0;
        readIDFs();
        readTags();
        return -1;
    }
    int getRotation() {
        int angle = 0;

        if (orientation == 0)
            orientation = findTag(TAG_ORIENTATION);

        if (orientation > 0) {
            Object tag = getTag(orientation);
            if (tag.equals(ORIENTATION_ROTATE_90))
                angle = 90;
            else if (tag.equals(ORIENTATION_ROTATE_180))
                angle = 180;
            else if (tag.equals(ORIENTATION_ROTATE_270))
                angle = 270;
        }
        return angle;
    }

    void setRotation(int angle) {
        if (orientation > 0) {
            angle += getRotation();
            int value = ORIENTATION_NORMAL;
            if (angle == 90)
                value = ORIENTATION_ROTATE_90;
            else if (angle == 180)
                value = ORIENTATION_ROTATE_180;
            else if (angle == 270 || angle == -90)
                value = ORIENTATION_ROTATE_270;
            setTag(orientation, value);
        }
    }

    DataInputStream in(int i, int count) {
        byte[] bytes = new byte[count];
        if (i < b.length - count) {
            if (isLittleEndian)
                i += count;
            for (int c = 0; c < count; c++)
                bytes[c] = isLittleEndian ? b[--i] : b[i++];
        }
        return new DataInputStream(new ByteArrayInputStream(bytes));
    }

    short getShort(int i) {
        try {
            return in(i, 2).readShort();
        } catch (IOException e) {}
        return 0;
    }

    int getInt(int i) {
        try {
            return in(i, 4).readInt();
        } catch (IOException e) {}
        return 0;
    }

    int getUShort(int i) {
        try {
            return in(i, 2).readUnsignedShort();
        } catch (IOException e) {}
        return 0;
    }

    float getFloat(int i) {
        try {
            return in(i, 4).readFloat();
        } catch (IOException e) {}
        return 0;
    }

    double getDouble(int i) {
        try {
            return in(i, 8).readDouble();
        } catch (IOException e) {}
        return 0;
    }

    void setBytes(int i, byte[] bytes) {
        int count = bytes.length;
        if (i < b.length - count) {
            if (isLittleEndian)
                i += count;
            for (int c = 0; c < count; c++)
                b[isLittleEndian ? --i : i++] = bytes[c];
        }
    }

    void setInt(int i, int v) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(4);
        DataOutputStream dos = new DataOutputStream(bos);
        try {
            dos.writeInt(v);
            byte[] bytes =bos.toByteArray();
            setBytes(i, bytes);
        } catch (IOException e) {}
    }


    void setShort(int i, int v) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(2);
        DataOutputStream dos = new DataOutputStream(bos);
        try {
            dos.writeShort(v);
            byte[] bytes =bos.toByteArray();
            setBytes(i, bytes);
        } catch (IOException e) {}
    }
}

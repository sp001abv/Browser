package com.sp.browser;

import android.text.InputType;

class WebFileInput extends TextInput {
    WebFileInput(String name, String value) {
        super(InputType.TYPE_TEXT_VARIATION_NORMAL, name, value);
    }

    @Override
    String getValue() {
        return S.getFileName(text);
    }

    @Override
    void onDoubleClick(float x, float y) {
        Pages.add(C.file + S.download_folder, false);
    }
}

package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.util.ArrayList;

class WebItem {
    float width = 0;
    float height = 0;
    RectF rect = new RectF();
    String href = null;

    void onDestroy(){}
    boolean wrap(float w, float h) { return false; }
    boolean intersects(float h) { return rect.bottom > 0 && rect.top < h; }
    void onDraw(Canvas canvas) {  }
    void onClick(float x, float y){
        if (href  != null)
            Pages.openUrl(href, x, y);
    }
    void onDoubleClick(float x, float y) {
        if (href != null)
            S.openFileAsActions.show(href, x, y);
    }
    boolean onBack(float x, float y) {	return false;	}
    boolean onScroll(float x, float y, float scroll) {
        return false;
    }
    void onTouch(MotionEvent event) {	}
    boolean onKeyEvent(KeyEvent event) {	return false; }
    void onMouseMove(float x, float y) { }
    boolean scale(float scale) {
        width *= scale;
        height *= scale;
        return true;
    }
    void move(float left, float top, float right, float bottom) {
        rect.set(left, top, right, bottom);
    }
    boolean offset(float x, float y, float dx, float dy) {
        rect.offset(dx, dy);
        return true;
    }
    void select(float x1, float y1, float x2, float y2){ }
    void select(int index, int length){ }
    void copy(CopyBuilder builder) {  }
    void find(String text, ArrayList<Finding> findings, boolean match){ }

    void addMediaHref(ArrayList<String> refs){
        if (S.isMedia(href) && !refs.contains(href))
            refs.add(href);
    }

    boolean remove(WebItem item) { return false; }
    WebItem get(float x, float y) { return rect.contains(x, y) ? this : null; }
}

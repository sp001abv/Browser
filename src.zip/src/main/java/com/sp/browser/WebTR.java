package com.sp.browser;

class WebTR extends WebDiv{
}

package com.sp.browser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

class WebMap extends WebItem implements LocationListener {
    static final int open_cycle_map = 1;
    static final int open_street_map = 2;
    static final int google_map_map  = 3;
    static final int google_sattelite_map  = 4;
    static final int google_hybrid_map  = 5;
    static final int yandex_sattelite_map  = 6;
    static final int bing_sattelite_map = 7;
    static final String map_marks_file = "mapmarks.list";

    class CycleAction extends Action{
        @Override
        String getName() { return  "open cycle map"; }
        @Override
        int getColor(){ return S.selected_map==open_cycle_map ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ S.selected_map=open_cycle_map;}
    }
    class OsmAction extends Action{
        @Override
        String getName() { return  "open street map"; }
        @Override
        int getColor(){ return S.selected_map==open_street_map ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ S.selected_map=open_street_map;}
    }
    class GoogleMapAction extends Action{
        @Override
        String getName() { return  "google map"; }
        @Override
        int getColor(){ return S.selected_map==google_map_map ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ S.selected_map=google_map_map;}
    }
    class GoogleSatteliteAction extends Action{
        @Override
        String getName() { return  "google sattelite"; }
        @Override
        int getColor(){ return S.selected_map==google_sattelite_map ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ S.selected_map=google_sattelite_map;}
    }
    class GoogleHybridAction extends Action{
        @Override
        String getName() { return  "google hybrid"; }
        @Override
        int getColor(){ return S.selected_map==google_hybrid_map ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ S.selected_map=google_hybrid_map;}
    }
    class YandexSatteliteAction extends Action{
        @Override
        String getName() { return  "yandex sattelite"; }
        @Override
        int getColor(){ return S.selected_map==yandex_sattelite_map ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ S.selected_map=yandex_sattelite_map;}
    }
    class BingSatteliteAction extends Action{
        @Override
        String getName() { return  "bing sattelite"; }
        @Override
        int getColor(){ return S.selected_map==bing_sattelite_map ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ S.selected_map=bing_sattelite_map;}
    }
    class LocateAction extends Action{
        @Override
        String getName() { return  "locate"; }
        @Override
        int getColor(){ return S.color_link;}
        @Override
        void onClick(float x, float y){ locateLastKnownLocation();}
    }
    class GpsAction extends Action{
        @Override
        String getName() { return  "gps"; }
        @Override
        int getColor(){ return gps ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ toggleGps();}
    }
    class MarkAction extends Action{
        @Override
        String getName() { return  "mark"; }
        @Override
        int getColor(){ return S.color_link;}
        @Override
        void onClick(float x, float y){ toggleMark(mapActions.rect.centerX(),mapActions.rect.centerY());}
    }
    class DistanceAction extends Action{
        @Override
        String getName() { return  "distance"; }
        @Override
        int getColor(){ return measure_distance ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ toggleMeasureDistance();}
    }
    class PhotosAction extends Action{
        @Override
        String getName() { return  "photos"; }
        @Override
        int getColor(){ return photos != null ? S.color_visited : S.color_link;}
        @Override
        void onClick(float x, float y){ togglePhotos();}
    }
    class CopyAction extends Action{
        @Override
        String getName() { return  "copy"; }
        @Override
        int getColor(){ return S.color_link;}
        @Override
        void onClick(float x, float y){ copy(mapActions.rect.centerX(),mapActions.rect.centerY());}
    }
    class DirectionsAction extends Action{
        @Override
        String getName() { return  "directions"; }
        @Override
        int getColor(){ return S.color_link;}
        @Override
        void onClick(float x, float y){ directions(mapActions.rect.centerX(),mapActions.rect.centerY());}
    }
    class CacheAction extends Action{
        @Override
        String getName() { return  "cache"; }
        @Override
        int getColor(){ return S.write_map_cache ? S.color_visited :S.color_link;}
        @Override
        void onClick(float x, float y){ S.write_map_cache=!S.write_map_cache;}
    }
    class MapActions extends Actions{
        MapActions(){
            items.add(new CycleAction());
            items.add(new OsmAction());
            items.add(new GoogleMapAction());
            items.add(new GoogleSatteliteAction());
            items.add(new GoogleHybridAction());
            items.add(new YandexSatteliteAction());
            items.add(new BingSatteliteAction());
            items.add(new PhotosAction());
            items.add(new LocateAction());
            items.add(new GpsAction());
            items.add(new MarkAction());
            items.add(new DistanceAction());
            items.add(new CopyAction());
            items.add(new DirectionsAction());
            items.add(new CacheAction());
        }
    }

    HashMap<String,Tile> tilesHash = new HashMap<String,Tile>();
    Queue<Tile> tilesQueue = new Queue<Tile>();
    MapActions mapActions = new MapActions();
    ArrayList<WebMapLocation> measure_distance_points = new ArrayList<WebMapLocation>();
    ArrayList<WebMapLocation> marks = new ArrayList<WebMapLocation>();
    WebMapPhotos photos = null;
    boolean measure_distance = false;
    WebMapLocation location = null;
    boolean gps = false;
    int altitude = 0;
    float speed = 0;
    int accuracy = 0;
    int tileSize = 256;
    int tiles_hash_size = S.image_hash_size / tileSize / tileSize / 4;
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    boolean read_map_cache = true;
    WebMap(String url){
        tileSize = (int)(tileSize * S.default_scale);
        width = height = tileSize*8192;
        paint.setTextSize(S.text_size);
        paint.setTypeface(Typeface.SANS_SERIF);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        loadMarks();
        WebMapLocation l = new WebMapLocation(S.getMapLocation(url));
        if (S.home_location != null){
            location = new WebMapLocation(S.home_location);
            measure_distance_points.add(l);
            double dx = l.x-location.x;
            double dy = l.y-location.y;
            double d = Math.sqrt(dx*dx+dy*dy);
            if (d>1e-7)
                width = height = (float)(tileSize/d);
        } else {
            location = l;
        }
    }

    String getQuadCode(int x,int y,int z){
        StringBuilder qc = new StringBuilder();
        for(int i=z;i>0;i--){
            int d = 0;
            int mask = 1<<(i-1);
            if ((x&mask)!=0) d++;
            if ((y&mask)!=0) d+=2;
            qc.append(d);
        }
        return qc.toString();
    }
    String getTileUrl(int x,int y,int z){
        String url = null;
        int n = (1<<z)-1;
        if (x<0 || y<0 || z<1 || x>n || y>n)
            url = C.http;
        else if (S.selected_map==open_cycle_map)
            url = String.format("https://tile.thunderforest.com/cycle/%d/%d/%d.png",z,x,y);
        else if (S.selected_map==open_street_map)
            url = String.format("https://tile.openstreetmap.org/%d/%d/%d.png",z,x,y);
        else if (S.selected_map==google_map_map)
            url = String.format("http://mts0.google.com/vt/lyrs=m&x=%d&y=%d&z=%d",x,y,z);
        else if (S.selected_map==google_hybrid_map)
            url = String.format("http://mts0.google.com/vt/lyrs=s,h&x=%d&y=%d&z=%d",x,y,z);
        else if (S.selected_map==google_sattelite_map)
            url = String.format("http://khm1.googleapis.com/kh?v=781&hl=en-US&x=%d&y=%d&z=%d",x,y,z);
        else if (S.selected_map==yandex_sattelite_map)
            url = String.format("https://sat04.maps.yandex.net/tiles?l=sat&v=3.374.0&x=%d&y=%d&z=%d&lang=en-RU",x,y,z);
        else if (S.selected_map==bing_sattelite_map)
            url = String.format("https://t1.ssl.ak.dynamic.tiles.virtualearth.net/comp/ch/%s?mkt=en-GB&it=A,G,RL&shading=hill&n=z&og=146&c4w=1",getQuadCode(x,y,z));
        return url;
    }

    String getMapsFolder(){
        return S.download_folder+"maps/";
    }
    String getCacheFilePath(int x,int y,int z){
        if (!read_map_cache) return null;
        String cache = getMapsFolder();
        File mf = new File(cache);
        if (!(mf.exists() && mf.isDirectory())){
            read_map_cache=false;
            return null;
        }
        if (S.selected_map==open_cycle_map)
            cache += String.format("thunderforest/cycle/%d/%d/%d.png",z,x,y);
        else if (S.selected_map==open_street_map)
            cache += String.format("openstreetmap/%d/%d/%d.png",z,x,y);
        else if (S.selected_map==google_map_map)
            cache += String.format("google/map/%d/%d/%d.png",z,x,y);
        else if (S.selected_map==google_hybrid_map)
            cache += String.format("google/hybrid/%d/%d/%d.jpg",z,x,y);
        else if (S.selected_map==google_sattelite_map)
            cache += String.format("google/sattelite/%d/%d/%d.jpg",z,x,y);
        else if (S.selected_map==yandex_sattelite_map)
            cache += String.format("yandex/sattelite/%d/%d/%d.jpg",z,x,y);
        else if (S.selected_map==bing_sattelite_map)
            cache += String.format("bing/sattelite/%d/%d/%d.jpg",z,x,y);
        else
            return null;

        return cache;
    }

    Tile getTile(int x,int y,int z){
        String url = getTileUrl(x,y,z);
        if (tilesHash.containsKey(url))
            return tilesHash.get(url);
        while (tilesHash.size() > tiles_hash_size) {
            Tile t = tilesQueue.poll();
            tilesHash.remove(t.src);
            t.onDestroy();
        }
        Tile tile = new Tile(url,getCacheFilePath(x,y,z));
        tilesHash.put(url, tile);
        tilesQueue.add(tile);
        return tile;
    }

    final float[] st = new float[]{0,-0.302222f,-0.328129f,-0.332760f,-0.358028f,-0.364615f,-0.368641f,-0.378609f,-0.392726f,-1};
    final float[] et = new float[]{0,-0.303124f,-0.328975f,-0.333595f,-0.358788f,-0.365352f,-0.369364f,-0.379294f,-0.394349f,-1};
    float getEllipsoidY(float y){
        for(int i=st.length-2;i>=0;i--){
            if(y<st[i]){
                return et[i]+(et[i+1]-et[i])*((y-st[i])/(st[i+1]-st[i]));
            }
        }
        return y;
    }

    @Override
    void onDraw(Canvas canvas) {
        int n = (int)width/tileSize;
        int z = 0;
        int t = 1;
        while(n>1){z++;n/=2;t*=2;}
        double size = width/t;
        int x = (int)(-rect.left/size);
        float top = rect.top;
        if (S.selected_map==yandex_sattelite_map) top=getEllipsoidY(top/height)*height;
        int y = (int)(-top/size);
        int nx = (int)(canvas.getWidth()/size)+2;
        int ny = (int)(canvas.getHeight()/size)+2;
        RectF r = new RectF(0,0,(float)size,(float)size);
        r.offset((float)(rect.left%size),(float)(top%size));
        float left = r.left;
        for(int iy=0;iy<ny;iy++){
            for(int ix=0;ix<nx;ix++){
                Tile tile = getTile(x+ix,y+iy,z);
                if (tile.bitmap != null)
                    canvas.drawBitmap(tile.bitmap, null, r, null);
                else {
                    int xix = x+ix;
                    int yiy = y+iy;
                    int zl = z;
                    for(int l=2;l<8;l*=2){
                        zl--;
                        if (zl<2) break;
                        String url = getTileUrl(xix/l,yiy/l,zl);
                        if (!tilesHash.containsKey(url)) continue;
                        tile = tilesHash.get(url);
                        if (tile.bitmap != null){
                            int ts = tile.bitmap.getWidth()/l;
                            int xe = (xix%l)*ts;
                            int ye = (yiy%l)*ts;
                            Rect rs = new Rect(xe,ye,xe+ts,ye+ts);
                            canvas.drawBitmap(tile.bitmap, rs, r, null);
                            break;
                        }
                    }
                }
                r.offset((float)(size-0.5),0);
            }
            r.offsetTo(left,(float)(r.top+size-0.5));
        }

        for (int i=0;i<marks.size();i++){
            WebMapLocation point = marks.get(i);
            float cx = rect.left+(point.x*width);
            float cy = rect.top+(point.y*height);
            paint.setColor(Color.YELLOW);
            if (cx > 0 && cy > 0 & cy < canvas.getHeight() & cx < canvas.getWidth())
                canvas.drawCircle(cx,cy,S.mark_size,paint);
        }

        float lx = 0;
        float ly = 0;
        if (location != null){
            paint.setColor(0xff00ccff);
            lx = rect.left+location.x*width;
            ly = rect.top+location.y*height;
            canvas.drawCircle(lx,ly,S.mark_size,paint);
        }

        double dist = 0;
        for (int i=0;i<measure_distance_points.size();i++){
            WebMapLocation point = measure_distance_points.get(i);
            float cx = rect.left+(point.x*width);
            float cy = rect.top+(point.y*height);
            paint.setColor(Color.RED);
            canvas.drawCircle(cx,cy,S.mark_size,paint);
            if (measure_distance && (i>0 || measure_distance_points.size()==1)){
                dist+=point.distance(i>0?measure_distance_points.get(i-1):location);
                canvas.drawLine(lx,ly,cx,cy,paint);
                paint.setColor(Color.WHITE);
                String text = dist<10000 ? String.format("%dm",(int)dist) : String.format("%.1fkm",dist*0.001);
                drawText(canvas, text, cx + S.mark_size, cy);

            }
            lx = cx;
            ly = cy;
        }

        if (photos != null)
            photos.onDraw(canvas, rect, width, height);

        if (gps)
            drawText(canvas, String.format("%d  %.1f  %d", altitude, speed, accuracy), 0, paint.getTextSize());
    }

    void drawText(Canvas canvas, String text, float x, float y) {
        paint.setColor(S.color_background);
        float o = paint.getTextSize() * 0.18f;
        canvas.drawRect(x, y + o - paint.getTextSize(), x + paint.measureText(text), y + o, paint);
        paint.setColor(S.color_text);
        canvas.drawText(text, x, y, paint);
    }


    void togglePhotos(){
        if (photos != null) {
            photos.onDestroy();
            photos = null;
        }
        else
            photos = new WebMapPhotos();
    }

    void toggleMeasureDistance(){
        if (measure_distance) measure_distance_points.clear();
        measure_distance=!measure_distance;
    }

    void toggleMeasureDistancePoint(float x, float y){
        x-=rect.left;
        y-=rect.top;
        for(int i=0;i<measure_distance_points.size();i++){
            WebMapLocation l = measure_distance_points.get(i);
            float dx = x-l.x*width;
            float dy = y-l.y*height;
            if ((dx*dx+dy*dy)<S.mark_size*S.mark_size){
                measure_distance_points.remove(i);
                return;
            }
        }
        measure_distance_points.add(new WebMapLocation(x/width,y/height));
    }

    void toggleMark(float x, float y){
        x-=rect.left;
        y-=rect.top;
        for(int i=0;i<marks.size();i++){
            WebMapLocation l = marks.get(i);
            float dx = x-l.x*width;
            float dy = y-l.y*height;
            if ((dx*dx+dy*dy)<S.mark_size*S.mark_size){
                marks.remove(i);
                saveMarks();
                return;
            }
        }
        marks.add(new WebMapLocation(x/width,y/height));
        saveMarks();
    }

    void loadMarks(){
        try
        {
            FileInputStream is = new FileInputStream(getMapsFolder()+map_marks_file);
            int size = is.read();
            for(int i=0;i<size;i++){
                WebMapLocation l = new WebMapLocation();
                l.update(S.readDouble(is),S.readDouble(is));
                marks.add(l);
            }
            is.close();
        }
        catch (Exception e)
        {
        }
    }
    void saveMarks() {
        try
        {
            FileOutputStream os = new FileOutputStream(getMapsFolder()+map_marks_file);
            os.write(marks.size());
            for(int i=0;i<marks.size();i++){
                WebMapLocation l = marks.get(i);
                S.writeDouble(os,l.lat);
                S.writeDouble(os,l.lon);
            }
            os.close();
        }
        catch (Exception e)
        {
        }
    }

    void copy(float x, float y){
        WebMapLocation l = new WebMapLocation((x-rect.left)/width,(y-rect.top)/height);
        Pages.setClipboardText(String.format("%f,%f",l.lat,l.lon));
    }

    void directions(float x, float y){
        WebMapLocation l = new WebMapLocation((x-rect.left)/width,(y-rect.top)/height);
        Pages.openGoogleMap(String.format("https://www.google.com/maps/dir//%f,%f",l.lat,l.lon));
    }

    void updateLocation(android.location.Location l){
        if (l != null){
            location.update(l.getLatitude(),l.getLongitude());
            altitude = (int)l.getAltitude();
            speed = l.getSpeed()*3.6f;
            accuracy = (int)l.getAccuracy();
        }
        center();
    }
    void locateLastKnownLocation(){
        LocationManager locationManager = (LocationManager)Pages.activity.getSystemService(Context.LOCATION_SERVICE);
        updateLocation(locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER));
    }
    void center(){
        WebPage page = Pages.active();
        page.panX = page.getWidth()/2- location.x*width;
        page.panY = page.getHeight()/2- location.y*height;
        page.postInvalidate();
    }
    void toggleGps(){
        if (gps)
            stopGps();
        else
            startGps();
    }
    public void startGps(){
        try{
            LocationManager locationManager = (LocationManager) Pages.activity.getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,S.gps_update_interval,S.gps_update_distance,this);
            gps = true;
        }catch(Exception e){
        }
    }
    public void stopGps(){
        LocationManager locationManager = (LocationManager) Pages.activity.getSystemService(Context.LOCATION_SERVICE);
        locationManager.removeUpdates(this);
        gps = false;
    }
    @Override
    public void onLocationChanged(android.location.Location l) { updateLocation(l); }
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override
    public void onProviderEnabled(String provider) {}
    @Override
    public void onProviderDisabled(String provider)
    {}

    @Override
    void onDestroy()
    {
        if (gps)
            stopGps();
        tilesHash.clear();
        for(Tile tile = tilesQueue.poll(); tile !=null; tile = tilesQueue.poll())
            tile.onDestroy();
        if (photos != null)
            photos.onDestroy();
    }

    @Override
    void onClick(float x, float y)
    {
        if (photos != null && photos.onClick(x, y))
            return;
        if (measure_distance)
            toggleMeasureDistancePoint(x,y);
        else
            mapActions.show(x,y);
    }

    @Override
    void onDoubleClick(float x, float y)
    {
        if (measure_distance)
            mapActions.show(x,y);
        else {
            scale(2);
            WebPage page = Pages.active();
            page.panX+=(page.panX-x);
            page.panY+=(page.panY-y);
        }
    }

    @Override
    boolean wrap(float w, float h) {
        center();
        return false;
    }
}

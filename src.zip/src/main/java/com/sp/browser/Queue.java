package com.sp.browser;

class Queue<E> {
    class Item{
        Item(E e) { element = e; }
        E element;
        Item next;
        Item prev;
    }
    Item first;
    Item last;
    int size;

    E last() {
        E e = null;
        synchronized (this) {
            if (last != null)
                e = last.element;
        }
        return e;
    }

    E prev() {
        E e = null;
        synchronized (this) {
            if (last != null && last.prev != null)
                e = last.prev.element;
        }
        return e;
    }

    void add(E e){
        synchronized (this) {
            if (first == null) {
                first = new Item(e);
                last = first;
            } else {
                Item item = new Item(e);
                item.prev = last;
                last.next = item;
                last = item;
            }
            size++;
        }
    }
    void insert(E e){
        synchronized (this) {
            if (first == null) {
                first = new Item(e);
                last = first;
            } else {
                Item item = new Item(e);
                item.next = first;
                first.prev = item;
                first = item;
            }
            size++;
        }
    }
    E poll() {
        E e = null;
        synchronized (this) {
            if (first != null) {
                e = first.element;
                first.element = null;
                first = first.next;
                if (first == null)
                    last = null;
                else
                    first.prev = null;
                size--;
            }
        }
        return e;
    }
    E cut() {
        E e = null;
        synchronized (this) {
            if (last != null) {
                e = last.element;
                last.element = null;
                last = last.prev;
                if (last == null)
                    first = null;
                else
                    last.next = null;
                size--;
            }
        }
        return e;
    }

    void clear() {
        synchronized (this) {
            while (first != null) {
                first.element = null;
                first = first.next;
                if (first == null)
                    last = null;
                else
                    first.prev = null;
                size--;
            }
        }
    }
}

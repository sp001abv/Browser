package com.sp.browser;

class Cipher {
    byte[] mask = new byte[128];

    Cipher(String key) {
        int m = mask.length;
        for (int i = 0; i < mask.length; i++) {
            m += key.charAt(i % key.length()) + i;
            mask[i] = (byte)(m);
        }
    }

    void cipher(long position, byte[] buffer, int offset, int size) {
        int index = (int)position;
        int n = offset + size;
        for(int i = offset; i < n; i++)
            buffer[i] ^= mask[index & 0x7F] + index++;
    }

    void decipher(long position, byte[] buffer, int offset, int size) {
        cipher(position, buffer, offset, size);
    }
}

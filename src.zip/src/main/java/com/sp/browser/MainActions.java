package com.sp.browser;

class HomeAction extends Action {
    @Override
    String getName() { return "home"; }

    @Override
    void onClick(float x, float y){
        Pages.clear();
        Cookies.load();
        Logger.clear();
        Pages.add(C.file + S.home_folder + C.home_page_file);
    }
}

class LoadBookmarkAction extends Action{
    String url;
    LoadBookmarkAction(String url){
        this.url = url;
    }
    @Override
    String getName() { return url; }

    int getColor(){
        return Pages.active().pageUrl.equals(url) ? S.color_visited : S.color_link;
    }

    @Override
    void onClick(float x, float y){
        Pages.add(url, false);
    }
}
class LoadBookmarksAction extends Action{
    String bookmarks_file;
    LoadBookmarksAction(String url){
        this.bookmarks_file = url;
    }
    @Override
    String getName() { return bookmarks_file; }

    @Override
    void onClick(float x, float y){	S.bookmarks.load(bookmarks_file);	}
}
class BookmarksAction extends Action{
    @Override
    String getName() { return "bookmarks"; }

    @Override
    void onClick(float x, float y){
        S.bookmarks.show(S.mainActions.rect.left, S.mainActions.rect.top);
    }
}
class BookmarkAction extends Action{
    @Override
    String getName() { return "bookmark"; }

    @Override
    int getColor(){
        return S.bookmarks.index(Pages.active().pageUrl) >= 0 ? S.color_visited : S.color_link;
    }

    @Override
    void onClick(float x, float y){
        S.bookmarks.bookmark(Pages.active().pageUrl);
    }
}
class CopyAction extends Action{
    @Override
    String getName() { return  "copy"; }

    @Override
    void onClick(float x, float y){
        String text = Pages.active().copy();
        Pages.setClipboardText(text);
    }
}
class PasteAction extends Action{
    @Override
    String getName() { return  "paste"; }

    @Override
    void onClick(float x, float y){
        String text = Pages.getClipboardText();
        if (text != null){
            Pages.active().paste(text);
        }
    }
}
class GotoAction extends Action{
    @Override
    String getName() { return "goto"; }

    @Override
    void onClick(float x, float y){
        String text = Pages.active().copy();
        if (text == null)
            text = Pages.getClipboardText();
        if (text != null){
            Pages.add(Pages.active().getAbsUrl(text));
        }
    }
}
class SearchAction extends Action{
    @Override
    String getName() { return "search"; }

    @Override
    void onClick(float x, float y){
        String text = Pages.active().copy();
        String clip = Pages.getClipboardText();
        if (text == null)
            text = clip;
        else if (clip != null)
            text = text + C.space + clip;

        if (text != null)
            Pages.add("https://www.google.bg/search?q="+S.encodeUrl(text, C.utf8), false);
    }
}
class FindAction extends Action{
    @Override
    String getName() { return "find"; }
    @Override
    void onClick(float x, float y){
        S.find.show(S.mainActions.rect.left, S.mainActions.rect.top);
    }
}

class MainActions2Action extends Action{
    @Override
    String getName() { return  "......"; }
    @Override
    void onClick(float x, float y){
        S.activeActions = S.mainActions2;
        S.mainActions2.show(x, y);
    }
}

class MainActions extends Actions {
    MainActions(){
        items.add(new HomeAction());
        items.add(new BookmarksAction());
        items.add(new CopyAction());
        items.add(new PasteAction());
        items.add(new GotoAction());
        items.add(new SearchAction());
        items.add(new FindAction());
        items.add(new MainActions2Action());
    }
}

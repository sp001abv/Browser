package com.sp.browser;

class WebTable extends WebDiv{
    int nc,nr;
    float cs[];
    int index[][];

    void init(){
        nr = items.size();
        nc = 0;
        for(int r=0; r<nr; r++) {
            WebTR tr = (WebTR) items.get(r);
            if (nc < tr.items.size()) nc = tr.items.size();
        }
        cs = new float[nc];
        index = new int[nr][nc];
        for(int r=0; r<nr; r++) {
            for (int c=0;c<nc;c++) {
                index[r][c]=-1;
            }
        }
        for(int r=0; r<nr; r++) {
            WebTR tr = (WebTR) items.get(r);
            for (int c=0;c<nc;c++) {
                int i = c;
                if (index[r][c]==-2) continue;
                for(int j=c;j>=0;j--){
                    if (index[r][j]==-2)
                        i--;
                }
                if (i<0 || i>=tr.items.size()) continue;
                WebTD td = (WebTD) tr.items.get(i);
                if (r+td.rowspan>nr) td.rowspan=nr-r;
                int ntd = tr.items.size()-i-1;
                if (c+td.colspan+ntd>nc) td.colspan=nc-c-ntd;
                for(int rs=0;rs<td.rowspan;rs++){
                    for(int cs=0;cs<td.colspan;cs++){
                        index[r+rs][c+cs]=-2;
                    }
                }
                index[r][c+td.colspan-1]=i;
                c+=td.colspan-1;
            }
        }
    }

    WebTD getTD(int r, int c){
        int i = index[r][c];
        if (i < 0) return null;
        WebTR tr = (WebTR)items.get(r);
        return (WebTD)tr.items.get(i);
    }

    @Override
    boolean wrap(float w, float h)
    {
        if (index == null) return true;
        height = 0;
        width = 0;
        for(int i=0;i<items.size();i++){
            items.get(i).wrap(w, h);
        }
        for(int c=0;c<nc;c++){
            float cw=0;
            for(int r=0;r<nr;r++){
                WebTD td = getTD(r,c);
                if (td != null){
                    float csw=0;
                    for(int j=c-1; j>=0 && index[r][j]<0; j--)
                        csw+=cs[j];
                    if (cw<td.width-csw) cw=td.width-csw;
                }
            }
            cs[c]=cw;
            width+=cw;
        }
        if (width > w)
        {
            /*
            if (!S.portrait_layout){
                float acw = (width * 0.75f)/ nc;
                float ucw = 0;
                for (int c = 0; c < nc; c++) {
                    if (cs[c] < acw)
                        ucw += cs[c];
                }
                float k = (w - ucw - 10) / (width - ucw);
                for (int c = 0; c < nc; c++) {
                    if (cs[c] >= acw) {
                        cs[c] *= k;
                        for (int r = 0; r < nr; r++) {
                            WebTD td = getTD(r, c);
                            if (td != null) {
                                float csw=0;
                                for(int j=c-1; j>=0 && index[r][j]<0; j--)
                                    csw+=cs[j];
                                float cw = cs[c] + csw;
                                if (td.width > cw)
                                    td.wrap(cw, h);
                            }
                        }
                    }
                }
            }
            */
            if (S.portrait_layout)
                width = w;
        }
        w = 0;
        for (int c = 0; c < nc; c++) {
            w += cs[c];
            for (int r = 0; r < nr; r++) {
                WebTD td = getTD(r, c);
                if (td != null) {
                    float csw=0;
                    for(int j=c-1; j>=0 && index[r][j]<0; j--)
                        csw+=cs[j];
                    float cw = cs[c] + csw;
                    if (td.width < cw)
                        td.width = cw;
                }
            }
        }
        height = 0;
        for (int r = 0; r < nr; r++) {
            WebTR tr = (WebTR)items.get(r);
            tr.size(width);
            tr.width = width;
            height += tr.height;
        }
        return true;
    }

    @Override
    void move(float left, float top, float right, float bottom)
    {
        float t = top;
        for(int i=0;i<items.size();i++){
            WebItem item = items.get(i);
            item.move(left,t,left+item.width,t+item.height);
            t+=item.height;
        }
        rect.set(left, top, right, bottom);
    }

}

package com.sp.browser;

interface IWebInput {
    String getName();
    String getValue();
}

package com.sp.browser;

import android.os.SystemClock;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;

class UrlDownloader implements IDownload {
    String url;
    String referer;
    String path;
    IProgress progress;

    UrlDownloader(String url, String referer, String path, IProgress progress) {
        this.url = url;
        this.path = path;
        this.progress = progress;
        this.referer = referer;
        Downloader.download(this);
    }

    UrlDownloader(URLConnection connection, InputStream inputStream, String path, IProgress progress) throws Exception {
        this.path = path;
        this.progress = progress;
        onResponse(null, connection, inputStream);
    }

    @Override
    public void download(WebPage page) {
        page.downloadUrl(url, this, referer, null);
    }

    @Override
    public void onResponse(WebPage page, URLConnection connection, InputStream inputStream) throws Exception {
        String contentLength = connection != null ? connection.getHeaderField("Content-Length") : null;
        if (contentLength != null) {
            Double fileLength = S.parseDouble(contentLength);
            if (fileLength != null)
                contentLength = C.slash + S.formatSize(fileLength.floatValue());
        }
        FileOutputStream outputStream = new FileOutputStream(path);
        byte[] buffer = new byte[1024];
        int length;
        float downloaded = 0;
        long time = SystemClock.elapsedRealtime() + buffer.length;
        while ((length = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, length);
            downloaded += length;
            if (SystemClock.elapsedRealtime() > time) {
                time = SystemClock.elapsedRealtime() + buffer.length;
                if (!onProgress(downloaded, contentLength)) {
                    outputStream.close();
                    S.deleteFile(path);
                    break;
                }
            }
        }
        outputStream.close();
        onProgress(downloaded, contentLength);
        if (progress == null) {
            Toaster.postShortToast(C.saved_as + path);
        }
    }

    boolean onProgress(float downloaded, String contentLength) {
        if (progress != null) {
            String p = S.formatSize(downloaded);
            if (contentLength != null)
                p += contentLength;
            return progress.onProgress(p);
        }
        return true;
    }

    @Override
    public void onError(WebPage page, URLConnection connection, final String error) {
        if (progress != null) {
            progress.onProgress(error);
        } else {
            Toaster.postLongToast(error);
        }
    }
}

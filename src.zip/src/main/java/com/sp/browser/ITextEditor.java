package com.sp.browser;

import android.graphics.RectF;

interface ITextEditor {
    boolean onEnter();
    boolean onLeft(boolean shift, boolean home);
    boolean onRight(boolean shift, boolean end);
    boolean onUp(boolean shift, float dy);
    boolean onDown(boolean shift, float dy);
    void del();
    void paste(String text);
    void cut(CopyBuilder builder);
    void copy(CopyBuilder builder);
    RectF getRect();
    void stopEditing();
}

package com.sp.browser;

import android.graphics.RectF;

interface ITextEditor {
    boolean onEnter();
    boolean onLeft();
    boolean onRight();
    void cut();
    void paste(String text);
    RectF getRect();
    void stopEditing();
}

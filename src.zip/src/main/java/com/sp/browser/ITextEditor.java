package com.sp.browser;

import android.graphics.RectF;

interface ITextEditor {
    boolean onEnter();
    boolean onLeft(boolean shift);
    boolean onRight(boolean shift);
    boolean onUp(boolean shift);
    boolean onDown(boolean shift);
    void del();
    void paste(String text);
    void cut(CopyBuilder builder);
    void copy(CopyBuilder builder);
    RectF getRect();
    void stopEditing();
}

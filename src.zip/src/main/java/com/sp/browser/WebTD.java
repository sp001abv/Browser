package com.sp.browser;

class WebTD extends WebDiv{
    int colspan = 1;
    int rowspan = 1;
}

package com.sp.browser;

class CopyBuilder {
    private StringBuilder stringBuilder = new StringBuilder();

    void append(char c) {
        //if (stringBuilder.length() > 0)
        //    stringBuilder.append(C.space);
        stringBuilder.append(c);
    }

    void append(String text) {
       // if (stringBuilder.length() > 0)
       //     stringBuilder.append(C.space);
        stringBuilder.append(text);
    }

    @Override
    public String toString() {
        return stringBuilder.length() > 0 ?  stringBuilder.toString() : null;
    }
}

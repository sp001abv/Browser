package com.sp.browser;

class CopyBuilder {
    private StringBuilder stringBuilder = new StringBuilder();

    void append(String text) {
        append(text, false);
    }

    void append(String text, boolean newline) {
        if (stringBuilder.length() > 0)
            stringBuilder.append(newline ? C.newline : C.space);
        stringBuilder.append(text);
    }

    @Override
    public String toString() {
        return stringBuilder.length() > 0 ?  stringBuilder.toString() : null;
    }
}

package com.sp.browser;

class WebSelectInput extends WebInput {
    String value;
    class Option extends Action{
        String name;
        String value;
        Option(String name, String value){
            this.name = name;
            this.value = value;
        }
        @Override
        String getName() { return name; }
        @Override
        void onClick(float x, float y) { onOptionSelected(this); }
    }
    Actions options = new Actions();
    WebSelectInput(String name){
        href = name;
        setText("---");
    }

    void onOptionSelected(Option option){
        value = option.value;
        setText(option.name);
        Pages.active().invalidateLayout();
    }

    Option addOption(String name, String value){
        Option option = new Option(name,value);
        options.items.add(option);
        return option;
    }

    @Override
    void onClick(float x, float y)
    {
        options.show(x,y);
    }

    @Override
    String getValue() {
        return value;
    }
}

package com.sp.browser;


import java.io.IOException;
import java.io.RandomAccessFile;

class ContainerInput {

    RandomAccessFile container;
    String fileName;
    long fileSize;
    long fileOffset;
    ContainerInput(String path) throws IOException {
        container = new RandomAccessFile(path,  "r");
    }

    boolean next() throws IOException {
        if (container.getFilePointer() != fileOffset + fileSize)
            container.seek(fileOffset + fileSize);
        fileOffset = fileSize = 0;
        int length = (int)(read(ContainerOutput.NAME_SIZE) & 0xFFFF);
        if (length <= 0 || length > 1024)
            return false;
        byte[] buffer = new byte[length];
        if (read(buffer) != length)
            return false;
        fileName = new String(buffer, C.utf8);
        fileSize = read(ContainerOutput.FILE_SIZE);
        fileOffset = container.getFilePointer();
        if (fileOffset + fileSize > container.length())
            return false;
        return true;
    }

    boolean find(String name) throws IOException {
        while (next()) {
            if (fileName.equalsIgnoreCase(name))
                return true;
        }
        return false;
    }

    void seek(long offset) throws IOException {
        if (offset < 0 || offset >= fileSize)
            throw new IOException();
        if (fileOffset + offset != container.getFilePointer())
            container.seek(fileOffset + offset);
    }

    long read(int size) throws IOException
    {
        byte[] buffer = new byte[size];
        size = read(buffer);
        long result = 0;
        for (int i=0; i<size; i++)
            result |= ((long)(buffer[i] & 0xFF)) << i*8;
        return result;
    }

    int read(byte[] buffer) throws IOException {
        return read(buffer, 0, buffer.length);
    }

    int read(byte[] buffer, int offset, int size) throws IOException {
        long pointer = container.getFilePointer();
        if (fileSize > 0 && pointer - fileOffset + size > fileSize) {
            size = (int)(fileSize + fileOffset - pointer);
            if (size <= 0)
                return -1;
        }
        size = container.read(buffer, offset, size);
        if (size <= 0)
            return -1;
        if (S.cipher != null)
            S.cipher.cipher(pointer, buffer, offset, size);
        return size;
    }

    void close() throws IOException {
        container.close();
    }
}


package com.sp.browser;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLConnection;

class WebVideo extends WebText implements IDownload {

    WebVideo(WebPage page, String attributes, int tag) {
        if (page.pageUrl.contains("vbox7.com/play:")){
            text = page.getAbsUrl("/ajax/video/nextvideo.php?vid=");
            int i1 = page.pageUrl.lastIndexOf(C.column)+1;
            int i2 = page.pageUrl.indexOf(C.amp);
            if (i2 > i1) text += page.pageUrl.substring(i1,i2);
            else text += page.pageUrl.substring(i1) + C.amp + "pos=0";
            Downloader.download(this);
        } else {
            String t = "!!!VIDEO!!!";
            String source = page.webSource.text;
            String attr = S.getAttribute(attributes, "onloadstart");
            if (attr != null) {
                int i1 = source.indexOf("sources:", tag);
                if (i1 > tag) {
                    int i2 = source.indexOf("}", i1)-1;
                    for(int i = i2-1; i > i1; i--) {
                        if (source.charAt(i) == C.quote) {
                            t= source.substring(i+1, i2).replace("\\","");
                            href = t;
                            break;
                        }
                    }
                }
            } else {
                attr = S.getAttribute(attributes, "id");
                if (attr != null && attr.equals("myPlayer")) {
                    int i1 = source.indexOf("myPlayer.updateSrc", tag);
                    if (i1 > tag) {
                        int i2 = source.indexOf("}", i1);
                        if (i2 > i1) {
                            String json = source.substring(i1, i2);
                            i1 = json.indexOf("src");
                            t = href = S.getJsonAttribute(json, i1);
                        }
                    }
                }
                else if (attr != null && attr.equals("dmp_Video")) {
                    int i1 = source.indexOf("type\":\"video", tag);
                    if (i1 > tag) {
                        int i2 = source.indexOf("}", i1);
                        if (i2 > i1) {
                            String json = source.substring(i1, i2);
                            i1 = json.indexOf("url");
                            t = href = S.getJsonAttribute(json, i1);
                        }
                    }
                } else {
                    int i2 = source.indexOf(C.mp4);
                    if (i2 < 0) i2 = source.indexOf(".m3u8");
                    if (i2 > 0) {
                        for (int i1 = i2; i1 > 0; i1--) {
                            char c = source.charAt(i1);
                            if (c == C.quote || c == C.apostr) {
                                while (i2 < source.length() && source.charAt(i2) != c)
                                    i2++;
                                t = href = page.getAbsUrl(source.substring(i1 + 1, i2));
                                break;
                            }
                        }
                    }
                }

            }
            setText(t);
        }
    }

    @Override
    public void download(WebPage page) {
        page.downloadUrl(text, this, null, null);
    }

    @Override
    public void onResponse(WebPage page, URLConnection connection, InputStream inputStream) throws Exception {
        ByteArrayOutputStream source = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        int length;
        while ((length = inputStream.read(buff)) != -1)
            source.write(buff, 0, length);
        String json = source.toString();
        int i = json.indexOf("src");
        if (i>0) try {
            i+=6;
            text = json.substring(i, json.indexOf(C.quote, i)).replace("\\","");
            i = json.indexOf("highestRes")+12;
            int res = Integer.parseInt(json.substring(i, json.indexOf(',', i)));
            i  = text.indexOf(".mpd");
            if (i > 0) {
                final String track = "_%d_track%d_dashinit.mp4";
                text = text.substring(0, i);
                href = text + String.format(track, res, 1) +
                        C.newline + text + String.format(track, res, 2);
            }
            else
                href = text;
        } catch(Exception e){href=null;}
        setText(href==null ? json : href);
    }

    @Override
    public void onError(WebPage page, URLConnection connection, String error) {
        setText(error);
    }

    @Override
    void onClick(float x, float y)
    {
        if (href != null) {
            paint.setColor(S.color_visited);
            Pages.add(href, C.video);
        }
    }

    @Override
    void onDoubleClick(float x, float y) {
        if (href != null)
            S.openFileAsActions.show(href, x, y);
    }
}

package com.sp.browser;

import java.util.ArrayList;

class CookieDomain {
    String domain;
    ArrayList<Cookie> cookies = new ArrayList<Cookie>();
    CookieDomain(String d){
        domain=d;
    }
    void setCookie(String name, String value){
        for(int i=0;i < cookies.size();i++){
            Cookie cookie = cookies.get(i);
            if(cookie.name.equals(name)){
                cookie.value=value;
                return;
            }
        }
        cookies.add(new Cookie(name,value));
    }
    String getCookies(){
        StringBuilder sb = new StringBuilder();
        for(int i=0;i < cookies.size();i++){
            Cookie cookie = cookies.get(i);
            if (i>0) sb.append(C.semi_column);
            sb.append(cookie.name);
            sb.append(C.equals);
            sb.append(cookie.value);
        }
        return sb.toString();
    }
}

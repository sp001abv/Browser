package com.sp.browser;

class OpenFileAsActions extends Actions {
    class OpenFileAsTextAction extends Action{
        @Override
        int getColor(){	return S.color_link; }
        @Override
        String getName() { return C.text; }
        @Override
        void onClick(float x, float y){
            openAs(getName());
        }
    }
    class OpenFileAsImageAction extends Action{
        @Override
        int getColor(){	return S.color_link; }
        @Override
        String getName() { return C.image; }
        @Override
        void onClick(float x, float y){
            openAs(getName());
        }
    }
    class OpenFileAsVideoAction extends Action{
        @Override
        int getColor(){	return S.color_link; }
        @Override
        String getName() { return C.video; }
        @Override
        void onClick(float x, float y){
            openAs(getName());
        }
    }
    class OpenFileAsAudioAction extends Action{
        @Override
        int getColor(){	return S.color_link; }
        @Override
        String getName() { return C.audio; }
        @Override
        void onClick(float x, float y) {
            externally = true;
            openAs(getName());
        }
    }
    class OpenFileAsOtherAction extends Action{
        @Override
        String getName() { return "*"; }
        @Override
        void onClick(float x, float y){
            externally = true;
            openAs(getName());
        }
    }
    class DownloadFileAction extends Action{
        @Override
        String getName() { return C.download; }
        @Override
        void onClick(float x, float y){  download();  }
    }
    class StreamFileAction extends Action{
        @Override
        String getName() { return "stream"; }
        @Override
        void onClick(float x, float y){  stream();  }
    }
    private String url = null;
    private boolean externally;
    OpenFileAsActions() {
        items.add(new OpenFileAsTextAction());
        items.add(new OpenFileAsImageAction());
        items.add(new OpenFileAsVideoAction());
        items.add(new OpenFileAsAudioAction());
        items.add(new OpenFileAsOtherAction());
        items.add(new DownloadFileAction());
        items.add(new StreamFileAction());
    }

    void show(String url, boolean externally, float x, float y) {
        this.url = url;
        this.externally = externally;
        show(x, y);
    }

    void show(String url, float x, float y) {
        show(url, true, x, y);
    }

    void openAs(String type){
        if (externally)
            Pages.openUrlExternally(url, type, rect.left, rect.top);
        else
            Pages.add(url , type);
    }

    void download() {
        Pages.add(url, C.download);
    }

    void stream() {
        if (!WebServer.isStarted)
            WebServer.startStop();
        Pages.add(S.buildWebServerUrl(url));
    }
}

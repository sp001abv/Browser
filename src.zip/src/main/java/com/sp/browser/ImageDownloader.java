package com.sp.browser;

import android.graphics.Bitmap;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLConnection;

class ImageDownloader implements IDownload {
    String src;
    Bitmap bitmap;
    byte[] buffer;
    Exif exif;
    Slideshow slideshow;
    ImageDownloader(Slideshow slideshow, String url) {
        this.slideshow = slideshow;
        download(url);
    }
    public void onError(URLConnection connection, String error){
    }

    @Override
    public void onResponse(URLConnection connection, InputStream inputStream) throws Exception {
        if (src != null) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            byte[] buff = new byte[1024];
            int length;
            while ((length = inputStream.read(buff)) != -1)
                stream.write(buff, 0, length);
            buffer = stream.toByteArray();
            Bitmap bmp = bitmap;
            if (bmp == null) {
                bmp = S.decodeImage(new ByteArrayInputStream(buffer));
            }
            exif = new Exif(buffer);
            int rotateAngle = exif.getRotation();
            if (rotateAngle != 0) {
                bmp = S.rotateBitmap(bmp, rotateAngle);
            }
            if (this == slideshow.media) {
                if (slideshow.image == null) {
                    slideshow.image = slideshow.page.addImage(bmp, src);
                    slideshow.setTime();
                }
                else if (slideshow.image.bitmap != bmp){
                    slideshow.image.setBitmap(bmp);
                    slideshow.image.rect.left = slideshow.image.rect.right;
                }
                slideshow.prepareRotate();
            }
            bitmap = bmp;
        }
    }

    @Override
    public void download() {
        slideshow.page.downloadUrl(src, this, slideshow.page.referer, null);
    }

    void set(Bitmap bitmap, String src, byte[] buffer, Exif exif) {
        this.bitmap = bitmap;
        this.src = src;
        this.buffer = buffer;
        this.exif = exif;
    }

    void download(String url) {
        bitmap = null;
        buffer = null;
        exif = null;
        src = url;
        if (S.isImage(src)) {
            S.downloadAsync(this);
        }
    }

    void onDestroy() {
        bitmap = null;
        src = null;
        buffer = null;
        exif = null;
        slideshow = null;
    }
}

package com.sp.browser;

class Cookie {
    String name;
    String value;
    Cookie(String n, String v){
        name=n; value=v;
    }
}

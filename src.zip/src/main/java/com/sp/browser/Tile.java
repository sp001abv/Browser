package com.sp.browser;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;

class Tile implements IDownload
{
    String src;
    String cache;
    Bitmap bitmap = null;
    WebPage page;
    Tile(WebPage page, String src,String cache){
        this.src = src;
        this.cache=cache;
        this.page = page;
        Downloader.download(this);
    }
    @Override
    public void download(){
        if (src == C.http) return;
        if (cache!=null){
            File f = new File(cache);
            if (f.exists()){
                bitmap = BitmapFactory.decodeFile(cache);
                page.postInvalidate();
                return;
            }
        }
        if (src != null)
            page.downloadUrl(src, this, null, null);
    }

    @Override
    public void onResponse(URLConnection connection, InputStream inputStream) throws Exception{
        if (src != null) {
            if (S.write_map_cache && cache!=null){
                int i = cache.lastIndexOf(C.slash);
                File d = new File(cache.substring(0,i));
                if (d.exists() || d.mkdirs()) {
                    try {
                        FileOutputStream outputStream = new FileOutputStream(cache);
                        byte[] buffer = new byte[1024];
                        int length;
                        while ((length = inputStream.read(buffer)) != -1)
                            outputStream.write(buffer, 0, length);
                        outputStream.close();
                        bitmap = BitmapFactory.decodeFile(cache);
                        return;
                    } catch (Exception e){

                    }
                }
            }
            bitmap = BitmapFactory.decodeStream(inputStream);
        }
    }

    @Override
    public void onError(URLConnection connection, String error){
    }

    public void onDestroy() {
        if (bitmap != null) {
            bitmap.recycle();
            bitmap = null;
        }
        src = null;
        cache = null;
        page = null;
    }
}

package com.sp.browser;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.mtp.MtpConstants;
import android.mtp.MtpDevice;
import android.mtp.MtpDeviceInfo;
import android.mtp.MtpObjectInfo;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;

class Mtp extends BroadcastReceiver {

    private static MtpDevice mtpDevice;
    private static Mtp usbBroadcast;

        @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action.equals(C.ACTION_USB_PERMISSION)) {
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                UsbDevice usbDevice = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                openMtpDevice(usbDevice, context);
                Pages.active().loadMtpFolder();
            }
        }
    }

    static boolean copyMtpFolder(int parent, String destination, IProgress action) {
        int[] handles = mtpDevice.getObjectHandles((int)mtpDevice.getStorageId(parent), 0, parent);
        if (handles != null) {
            for (int handle : handles) {
                MtpObjectInfo info = mtpDevice.getObjectInfo(handle);
                String fileName = info.getName();
                if (info.getAssociationType() == MtpConstants.ASSOCIATION_TYPE_GENERIC_FOLDER) {
                    File destinationFolder = new File(destination + fileName);
                    if (!destinationFolder.exists())
                        destinationFolder.mkdir();
                    if (!copyMtpFolder(handle, destination + fileName + C.slash, action))
                        return false;
                }
                else if (!copyMtpFile(handle, destination + fileName, action))
                    return false;
            }
        }
        return true;
    }

    static boolean copyMtpFolder(String source, String destination, IProgress action){
        if (mtpDevice != null) {
            Integer handle = getMtpHandle(source);
            if (handle != null) {
                return copyMtpFolder(handle, destination, action);
            }
            return true;
        }
        return false;
    }

    static boolean copyMtpFile(int handle, String destination, IProgress action){
        MtpObjectInfo info = mtpDevice.getObjectInfo(handle);
        if (!action.onProgress(info.getName() + C.space + S.formatSize(info.getCompressedSize())))
            return false;
        return mtpDevice.importFile(handle, destination);
    }

    static boolean copyMtpFile(String source, String destination, IProgress action){
        if (mtpDevice != null) {
            Integer handle = getMtpHandle(source);
            if (handle != null) {
                return copyMtpFile(handle, destination, action);
            }
        }
        return false;
    }

    static void openMtpDevice(UsbDevice usbDevice, Context context) {
        UsbManager usbManager = (UsbManager)context.getSystemService(Context.USB_SERVICE);
        mtpDevice = new MtpDevice(usbDevice);
        mtpDevice.open(usbManager.openDevice(usbDevice));
    }

    static void requestPermission(UsbDevice usbDevice, Context context) {
        UsbManager usbManager  = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (usbBroadcast == null) {
            usbBroadcast = new Mtp();
            IntentFilter filter = new IntentFilter();
            filter.addAction(C.ACTION_USB_PERMISSION);
            context.registerReceiver(usbBroadcast, filter);
        }
        usbManager.requestPermission(usbDevice, PendingIntent.getBroadcast(context, 0, new Intent(C.ACTION_USB_PERMISSION), 0));
    }

    static Integer getMtpHandle(String[] folders, int index, MtpDevice device, int id, int parent) {
        int[] handles = device.getObjectHandles(id, 0, parent);
        if (handles != null) {
            for (int handle : handles) {
                MtpObjectInfo info = device.getObjectInfo(handle);
                String name = info.getName();
                if (name.equals(folders[index])) {
                    if (index < folders.length -1)
                        return getMtpHandle(folders, index + 1, device, id, handle);
                    return handle;
                }
            }
        }
        return null;
    }

    static Integer getMtpHandle(String url) {
        String[] folders = url.split(String.valueOf(C.slash));
        int[] ids = mtpDevice.getStorageIds();
        if (ids != null) {
            for (int id : ids) {
                String storage = mtpDevice.getStorageInfo(id).getDescription();
                if (storage.equals(folders[4])) {
                    return getMtpHandle(folders, 5, mtpDevice, id, -1);
                }
            }
        }
        return null;
    }

    static InputStream getMtpStream(String url) {
        if (mtpDevice != null) {
            Integer handle = getMtpHandle(url);
            if (handle != null) {
                MtpObjectInfo info = mtpDevice.getObjectInfo(handle);
                int size = info.getCompressedSize();
                if (size < S.image_hash_size) {
                    byte[] buffer = mtpDevice.getObject(handle, size);
                    if (buffer != null)
                        return new ByteArrayInputStream(buffer);
                }
            }
        }
        return null;
    }

    static float getMtpFolderSize(MtpDevice device, int parent) {
        float size = 0;
        int[] handles = device.getObjectHandles((int)device.getStorageId(parent), 0, parent);
        if (handles != null) {
            for (int handle : handles) {
                MtpObjectInfo info = device.getObjectInfo(handle);
                size += info.getAssociationType() == MtpConstants.ASSOCIATION_TYPE_GENERIC_FOLDER ?
                        getMtpFolderSize(mtpDevice, handle) : info.getCompressedSize();
            }
        }
        return size;
    }

    static float getMtpFileSize(String url) {
        float size = 0;
        if (mtpDevice != null) {
            Integer handle = getMtpHandle(url);
            if (handle != null) {
                MtpObjectInfo info = mtpDevice.getObjectInfo(handle);
                size = info.getAssociationType() == MtpConstants.ASSOCIATION_TYPE_GENERIC_FOLDER ?
                        getMtpFolderSize(mtpDevice, handle) : info.getCompressedSize();
            }
        }
        return size;
    }

    static void deleteMtpFile(String url) {
        if (mtpDevice != null) {
            Integer handle = getMtpHandle(url);
            if (handle != null)
                mtpDevice.deleteObject(handle);
        }
    }

    static boolean isMtpDevice(UsbDevice device) {
        int count = device.getInterfaceCount();
        for (int i = 0; i < count; i++) {
            UsbInterface intf = device.getInterface(i);
            if (intf.getInterfaceClass() == UsbConstants.USB_CLASS_STILL_IMAGE &&
                    intf.getInterfaceSubclass() == 1 &&
                    intf.getInterfaceProtocol() == 1) {
                return true;
            }
        }
        return false;
    }

    static void addMtpObjects(String[] folders, int index, MtpDevice device, int id, int parent, ArrayList<String> mtpFolders, ArrayList<String> mtpFiles) {
        int[] handles = device.getObjectHandles(id, 0, parent);
        if (handles != null) {
            for (int handle : handles) {
                MtpObjectInfo info = device.getObjectInfo(handle);
                String name = info.getName();
                if (folders.length <= index) {
                    if (info.getAssociationType() == MtpConstants.ASSOCIATION_TYPE_GENERIC_FOLDER)
                        mtpFolders.add(name);
                    else
                        mtpFiles.add(name);
                } else  if (name.equals(folders[index])) {
                    addMtpObjects(folders, index+1, device, id, handle, mtpFolders, mtpFiles);
                    break;
                }
            }
        }
    }

    static boolean loadMtpFolder(String url, ArrayList<String> mtpFolders, ArrayList<String> mtpFiles, Context context) {

        if (mtpDevice != null && mtpDevice.getDeviceInfo() == null)
            mtpDevice = null;
        if (mtpDevice == null) {
            UsbManager usbManager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
            for (UsbDevice usbDevice : usbManager.getDeviceList().values()) {
                if (isMtpDevice(usbDevice)) {
                    if (!usbManager.hasPermission(usbDevice)) {
                        requestPermission(usbDevice, context);
                    } else {
                        openMtpDevice(usbDevice, context);
                    }
                    break;
                }
            }
        }
        if (mtpDevice == null)
            return false;
        String[] folders = url.split(String.valueOf(C.slash));
        MtpDeviceInfo info = mtpDevice.getDeviceInfo();
        String name = info != null ? info.getModel() : C.mtp.substring(0,3);
        if (folders.length <= 3) {
            mtpFolders.add(name);
        } else if (name.equals(folders[3])) {
            int[] ids = mtpDevice.getStorageIds();
            if (ids != null) {
                for (int id : ids) {
                    String storage = mtpDevice.getStorageInfo(id).getDescription();
                    if (storage == null || storage.isEmpty()) storage = Integer.toString(id);
                    if (folders.length <= 4) {
                        mtpFolders.add(storage);
                    } else if (storage.equals(folders[4])){
                        addMtpObjects(folders, 5, mtpDevice, id, -1, mtpFolders, mtpFiles);
                        break;
                    }
                }
            }
        }
        return true;
    }

}

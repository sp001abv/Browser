package com.sp.browser;

import android.graphics.Canvas;
import android.text.InputType;

class WebTextInput extends WebInput {
    int inputType;

    WebTextInput(int inputType, String name, String value) {
        href = name;
        if (value == null)
            value = C.empty;
        setText(value);
        paint.setColor(S.color_text);
        this.inputType = inputType;
    }

    @Override
    boolean wrap(float w, float h) {
        super.wrap(w, h);
        int min = S.text_size * 10;
        if (width < min)
            width = min;
        return true;
    }

    @Override
    void onDraw(Canvas canvas){
        String t = null;
        if (inputType == InputType.TYPE_TEXT_VARIATION_PASSWORD){
            StringBuilder sb = new StringBuilder();
            for(int i=0;i<text.length();i++)
                sb.append('●');
            t = text;
            text=sb.toString();
        }
        super.onDraw(canvas);
        if (t != null) text = t;
        float dx = height*0.12f;
        float top = rect.bottom-dx;
        float bottom = rect.bottom+dx+dx;
        float left = rect.left-dx;
        float right = rect.right - height/2 + dx;
        canvas.drawLine(left,bottom,right,bottom,paint);
        canvas.drawLine(left,bottom,left,top,paint);
        canvas.drawLine(right,bottom,right,top,paint);
    }

    @Override
    void onClick(float x, float y)
    {
        if (!editing)
            startEditing();
        else
            super.onClick(x, y);
    }

    @Override
    void onDoubleClick(float x, float y) {
        if (text.startsWith(C.http))
            Pages.add(text, false);
    }
}

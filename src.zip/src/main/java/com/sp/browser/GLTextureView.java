package com.sp.browser;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import java.nio.IntBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

class GLTextureView extends GLSurfaceView implements GLSurfaceView.Renderer {


    interface Callback {
        void onDrawFrame();
        void onSurfaceCreated();
        void onError(String error);
    }

    Callback mCallback;
    GLTextureRenderer mTextureRenderer;
    private int mTextureWidth;
    private int mTextureHeight;
    private int[][] mTextureImage;
    private boolean[] mUpdate;
    private boolean mUpdateAvailable;
    private float mAspectRatio;

    GLTextureView(Context context, Callback callback) {
        super(context);
        mCallback = callback;
        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(false);
        setRenderer(this);
        mAspectRatio = 0;
    }

    void release() {
        onPause();
    }

    int[][] getTexture() {
        return mTextureImage;
    }

    boolean[] getUpdate() {
        return mUpdate;
    }

    void onUpdateAvailable() {
        synchronized (this) {
            if (!mUpdateAvailable) {
                mUpdateAvailable = true;
                notifyAll();
            }
        }
        synchronized (this) {
            if (mUpdateAvailable) {
                try {
                    wait(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void onDrawFrame(GL10 glUnused) {
        try {
            if (mUpdate == null) {
                GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
                GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT | GLES20.GL_COLOR_BUFFER_BIT);
                return;
            }
            mTextureRenderer.bind();
            synchronized (this) {
                if (!mUpdateAvailable)
                    wait(250);
                if (mUpdateAvailable) {
                    int n = mUpdate.length;
                    int h = mTextureHeight / n;
                    for (int i = 0; i < n; i++) {
                        if (mUpdate[i]) {
                            GLES20.glTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0,i * h, mTextureWidth, h,
                                    GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, IntBuffer.wrap(mTextureImage[i]));
                            mUpdate[i] = false;
                        }
                    }
                    mUpdateAvailable = false;
                }
            }
            mTextureRenderer.draw();
            mCallback.onDrawFrame();
        } catch (Exception e){
            mCallback.onError(e.getMessage());
        }
    }

    public void onSurfaceChanged(GL10 glUnused, int width, int height) {
        adjustTexture();
    }

    void createTexture(int width, int height) {
        mTextureWidth = width;
        mTextureHeight = height;
        int n = 30;
        mTextureImage = new int[n][width * height / n];
        mUpdate = new boolean[n];
        mTextureRenderer.bind();
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, width, height, 0,GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
        int h = mTextureHeight / n;
        for (int i = 0; i < n; i++)
            GLES20.glTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0,i * h, mTextureWidth, h,
                    GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, IntBuffer.wrap(mTextureImage[i]));
        adjustTexture();
    }

    void setAspectRatio(float aspectRatio) {
        mAspectRatio = aspectRatio;
        adjustTexture();
    }

    private void adjustTexture() {
        if ( mTextureWidth == 0 || mTextureHeight == 0)
            return;
        float textureHeight = mTextureHeight;
        float textureWidth =  mAspectRatio == 1 ? mTextureWidth : textureHeight * mAspectRatio;

        float width = getWidth();
        float height = getHeight();
        if (textureWidth == 0) {
            textureWidth = mTextureWidth;
            textureHeight = mTextureHeight;
        } else {
            float scaleWidth = width / textureWidth;
            float scaleHeight = height / textureHeight;
            float scale = scaleWidth < scaleHeight ? scaleWidth : scaleHeight;
            textureWidth *= scale;
            textureHeight *= scale;
        }
        mTextureRenderer.scale(textureWidth / width, -textureHeight / height);
    }

    public void onSurfaceCreated(GL10 glUnused, EGLConfig config) {
        GLProgram program = new GLProgram(GLBitmapTextureRenderer.VERTEX_SHADER, GLBitmapTextureRenderer.FRAGMENT_SHADER);
        mTextureRenderer = new GLTextureRenderer(GLES20.GL_TEXTURE_2D, program);
        mCallback.onSurfaceCreated();
    }
}


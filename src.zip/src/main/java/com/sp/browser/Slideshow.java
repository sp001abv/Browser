package com.sp.browser;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.SystemClock;

import java.io.File;

class Slideshow implements Runnable {

    ImageActions imageActions = new ImageActions(this);
    ImageDownloader prevMedia;
    ImageDownloader nextMedia;
    ImageDownloader media;
    WebImage image;
    boolean running;
    final float timeIntervalStep = C.scale_step_2;
    float startTime;
    int slideTransition;
    String rotate;
    WebPage page;

    Slideshow(WebPage page, WebImage image) {
        this.page = page;
        this.image = image;
        prepareMedia();
        media.bitmap = image.bitmap;
    }

    void toggleRun() {
        running = !running;
        if (running) {
            new Thread(this).start();
        }
    }

    void setMode(int mode){
        S.slide_mode += mode;
        if (S.slide_mode > C.slide_modes) S.slide_mode = 1;
        if (S.slide_mode < 1) S.slide_mode = C.slide_modes;
    }

    void setInterval(int step)
    {
        if (step  > 0)
            S.slide_interval *= timeIntervalStep;
        else
            S.slide_interval /= timeIntervalStep;
    }

    void prepareMedia() {
        media = new ImageDownloader(this, page.pageUrl);
        prevMedia = new ImageDownloader(this, page.getMediaHref(false));
        nextMedia = new ImageDownloader(this, page.getMediaHref(true));
        prepareRotate();
    }

    void releaseMedia() {
        if (media != null){
            media.onDestroy();
            media = null;
        }
        if (prevMedia != null){
            prevMedia.onDestroy();
            prevMedia = null;
        }
        if (nextMedia != null) {
            nextMedia.onDestroy();
            nextMedia = null;
        }
        image = null;
    }

    void prepareRotate() {
        int angle = media != null && media.exif != null ? media.exif.getRotation() : 0;
        rotate = String.format("rotate ◄ %d° ►", angle);
    }

    void rotate(int angle) {
        image.setBitmap(S.rotateBitmap(image.bitmap, angle));
        image.rect.left = image.rect.right;
        media.exif.setRotation(angle);
        if (imageActions.exifInfo != null)
            imageActions.exifInfo.init();
        prepareRotate();
        page.invalidateLayout();
    }

    String getImageDim() {
        if (image != null && image.bitmap != null) {
            Rect crop = S.getCrop(image.bitmap, page.getWidth(), page.getHeight(), image.rect);
            int width = crop != null ? crop.width() : image.bitmap.getWidth();
            int height = crop != null ? crop.height() : image.bitmap.getHeight();
            return String.valueOf(width) + C.times + String.valueOf(height);
        }
        return C.empty;
    }

    void saveImage(String path, String name)
    {
        if (new File(path + name).exists()) {
            Toaster.postShortToast(path + name + " exists");
            return;
        }

        if (media.bitmap == image.bitmap && S.haveSameStorage(image.src, path)){
            String info = S.moveFile(image.src, path + name);
            if (info.startsWith(C.moved)) {
                Toaster.postShortToast(info);
                Pages.prev().removeLocalFile(image.src);
                image.bitmap = prevMedia.bitmap;
                image.src = prevMedia.src;
                media.set(image.bitmap, image.src, prevMedia.buffer, prevMedia.exif);
            }
            else Toaster.postShortToast(info);
        }
        else if (media.buffer != null)
            Toaster.postShortToast(S.saveBuffer(media.buffer, path, name));
        else
            new UrlDownloader(image.src, page.referer, path + name, null);
    }

    void downscaleImage() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                image.setBitmap(S.downscaleBitmap(image.bitmap));
                image.fitActualSize();
            }
        }).start();
    }

    String buildImagePosition() {
        StringBuilder fileName = new StringBuilder();
        fileName.append(C.at);
        fileName.append((int)image.width);
        fileName.append(C.dot);
        fileName.append((int)image.height);
        fileName.append(C.dot);
        fileName.append((int)page.panX);
        fileName.append(C.dot);
        fileName.append((int)page.panY);
        fileName.append(C.dot);
        fileName.append((int)page.rotateAngle);
        return fileName.toString();
    }

    void saveImage(boolean crop, boolean closeup) {
        String fileName = S.getFileName(image.src);
        String date = S.getDateFromFileName(fileName);
        if (date == null) {
            boolean generateName = fileName.length() < 12;
            Rect cr = crop ? S.getCrop(image.bitmap, page.getWidth(), page.getHeight(), image.rect) : null;
            if (cr != null) {
                fileName = generateName ? S.getFileNameFromTime() : S.removeExt(fileName);
                if (closeup) fileName += "c";
                Toaster.postShortToast(S.saveBitmap(Bitmap.createBitmap(image.bitmap, cr.left, cr.top, cr.width(), cr.height()),
                        S.output_folder, fileName));
                if (closeup) return;
            }
            else if (image.width > page.getWidth() || image.height > page.getHeight() ||page. rotateAngle != 0) {
                int i = fileName.indexOf(C.at);
                fileName =  generateName? S.getFileNameFromTime() :
                        (i > 0 ? fileName.substring(0, i) :S.removeExt(fileName));
                fileName += buildImagePosition();
                fileName += C.dot + S.getExt(image.src);
                saveImage(S.output_folder, fileName);
            }
            else {
                if (generateName)
                    fileName = S.getFileNameFromTime() + C.dot + S.getExt(image.src);
                saveImage(S.output_folder, fileName);
            }
        } else {
            saveImage(S.getArchiveFolder(date), fileName);
        }
        loadNextMedia();
    }

    void deleteImage() {
        if (S.isLocalFile(image.src))
            S.deleteFile(S.getLocalPath(image.src));
        loadNextMedia();
    }

    void loadNextMedia() {
        loadMedia(nextMedia, prevMedia);
    }

    void loadPrevMedia() {
        loadMedia(prevMedia, nextMedia);
    }

    void loadMedia(ImageDownloader next, ImageDownloader prev)
    {
        if (S.isImage(next.src))
            loadImage(next, prev);
        else if (S.isVideo(next.src))
            loadVideo(next.src);
    }

    void loadImage(ImageDownloader nextImage, ImageDownloader prevImage) {
        if (nextImage.bitmap != null) {
            prevImage.set(image.bitmap, image.src , media.buffer, media.exif);
            image.src = page.pageUrl = nextImage.src;
            image.setBitmap(nextImage.bitmap);
            media.set(nextImage.bitmap, nextImage.src, nextImage.buffer, nextImage.exif);
            prepareRotate();
            image.rect.left = image.rect.right;
            nextImage.download(page.getMediaHref(nextImage == nextMedia));
            invalidate();
        }
    }

    void invalidate() {
        setTime();
        page.invalidateLayout();
    }

    void loadImage(String url) {
        page.pageUrl = url;
        page.dom.clear();
        prepareMedia();
        invalidate();
    }

    void loadVideo(String url) {
        page.pageUrl = url;
        page.dom.clear();
        page.images.clear();
        if (image != null) {
            image.onDestroy();
            image = null;
        }
        releaseMedia();
        page.addWebPlayer(url);
        page.invalidateLayout();
    }

    void setImageRect(RectF rect, Bitmap bitmap, float screenWidth, float screenHeight) {
        float x = 0;
        float y = 0;
        float width = bitmap.getWidth();
        float height = bitmap.getHeight();
        float wr = screenWidth/width;
        float hr = screenHeight/height;
        if (hr < wr) {
            width *= hr;
            height = screenHeight;
            x = (screenWidth - width) / 2;
        }
        else {
            width = screenWidth;
            height *= wr;
            y = (screenHeight - height) / 2;
        }
        rect.set(x, y, x + width, y + height);
    }

    void onDraw(Canvas canvas) {

        if (image == null || !running)
            return;

        float screenWidth = canvas.getWidth();
        float screenHeight = canvas.getHeight();
/*
				if (S.slide_mode == 2)
				{
				    Bitmap bitmap = nextMedia.bitmap;
					if (slideTransition > 0 && bitmap != null) {
						Paint paint = new Paint();
						paint.setAlpha(slideTransition);
						canvas.drawRect(image.rect, paint);
						RectF rect = new RectF();
						setImageRect(rect, bitmap, screenWidth, screenHeight);
						canvas.drawBitmap(bitmap, null, rect, paint);
					}
				}
				else */ if (S.slide_mode == 3) {
            if (slideTransition == 1) {
                float w = image.bitmap.getWidth();
                if (screenWidth < w)
                    w = screenWidth;
                if (w>image.width) {
                    image.scale((image.width + 2) / image.width);
                    if (image.width > w) {
                        if (image.width > image.bitmap.getWidth()) {
                            image.width = image.bitmap.getWidth();
                            image.height = image.bitmap.getHeight();
                        }
                        if (image.rect.bottom > screenHeight)
                            slideTransition = 2;
                    }
                    page.panX = (screenWidth - image.width) / 2;
                    invalidate();
                }
                else if (image.rect.bottom > screenHeight) {
                    page.pan(0, 1);
                    setTime();
                }
            }
        }
    }

    void onClick(float x, float y) {
        if (running) {
            slideTransition = 0;
            running = false;
        }

        int width = page.getWidth();
        int height = page.getHeight();
        if (y < S.text_size) {
            image.toggleFit();
            return;
        }

        int hit = imageActions == Actions.active || y > height / 2 ? (int)(2 * x / width) : 2;
        if (hit == 0) {
            loadPrevMedia();
        }
        else if (hit == 1) {
            loadNextMedia();
        } else if (hit == 2) {
            imageActions.show(x, y);
        }
    }

    void loadNext() {
        setTime();
        Handler mainHandler = new Handler(page.getContext().getMainLooper());
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                loadNextMedia();
            }
        };
        mainHandler.post(runnable);
    }

    void onDestroy() {
        running = false;
        releaseMedia();
        imageActions.onDestroy();
        imageActions = null;
        page = null;
    }

    void setTime() {
        startTime = SystemClock.elapsedRealtime();
    }

    float getEllapsedTime() {
        return (SystemClock.elapsedRealtime() - startTime);
    }

    @Override
    public void run() {
        setTime();
        while (running) {
            try {
                if (image != null) {
                    if (S.slide_mode == 1 || S.slide_mode == 2) {
                        if (getEllapsedTime() >= S.slide_interval) {
                            loadNext();
                        }
							/*} else if (S.slide_mode == 2) {
								float dt = getEllapsedTime() - S.slide_interval;
								if (dt >= 0) {
									slideTransition = 0;
									loadNext();
								} else if (dt  > -1000f) {
									slideTransition = (int)(0.255f * (1000f+dt));
									postInvalidate();
								} */
                    } else if (S.slide_mode == 3){
                        if (getEllapsedTime() >= S.slide_interval / 2) {
                            if (slideTransition == 0) {
                                slideTransition = 1;
                                setTime();
                                page.postInvalidate();
                            }
                            else if (slideTransition == 1) {
                                slideTransition = 0;
                                loadNext();
                            }
                            else if (slideTransition == 2) {
                                slideTransition = 1;
                                page.postInvalidate();
                            }
                        }
                    }
                }
                Thread.sleep(40);
            }
            catch (Exception е) {
            }
        }
    }
}

package com.sp.browser;

import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;

class GLSurfaceTextureRenderer extends GLTextureRenderer {
    static final String VERTEX_SHADER =
            "uniform mat4 uMVPMatrix;" +
                    "uniform mat4 uSTMatrix;" +
                    "attribute vec4 aPosition;" +
                    "attribute vec4 aTexture;" +
                    "varying vec2 vTexture;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "  vTexture = (uSTMatrix * aTexture).xy;" +
                    "}";

    static final String FRAGMENT_SHADER  =
            "#extension GL_OES_EGL_image_external : require\n" +
                    "precision mediump float;" +      // highp here doesn't seem to matter
                    "uniform samplerExternalOES sTexture;" +
                    "varying vec2 vTexture;" +
                    "void main() {" +
                    "  gl_FragColor = texture2D(sTexture, vTexture);" +
                    "}";

    SurfaceTexture mSurfaceTexture;
    protected float[] muSTMatrix;
    private int muSTMatrixHandle;

    GLSurfaceTextureRenderer(GLProgram GLProgram){
        super(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLProgram);
        mSurfaceTexture = new SurfaceTexture(mTextureID);
        muSTMatrix = new float[16];
        muSTMatrixHandle = GLES20.glGetUniformLocation(mProgram.id(), "uSTMatrix");
    }

    @Override
    void use() {
        super.use();
        mSurfaceTexture.getTransformMatrix(muSTMatrix);
        GLES20.glUniformMatrix4fv(muSTMatrixHandle, 1, false, muSTMatrix, 0);
    }

}

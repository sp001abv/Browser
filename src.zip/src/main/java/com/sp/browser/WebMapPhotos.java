package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.RectF;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;

class WebMapPhotos implements IDownload {
    ArrayList<WebMapPhoto> photos = new ArrayList<WebMapPhoto>();
    RectF rect;
    float width;
    float height;
    WebPage page;

    WebMapPhotos(WebPage page){
        this.page = page;
        Downloader.download(this);
    }

    void onDraw(Canvas canvas, RectF rect, float width, float height) {
        this.rect = rect;
        this.width= width;
        this.height = height;
        for (int i=0;i<photos.size();i++){
            WebMapPhoto photo = photos.get(i);
            if (photo.bitmap == null) continue;
            WebMapLocation point = photo.location;
            float x = rect.left+(point.x*width);
            float y = rect.top+(point.y*height);
            RectF r = new RectF(x,y,x+photo.bitmap.getWidth()*photo.scale,y+photo.bitmap.getHeight()*photo.scale);
            RectF screen = new RectF(0, 0, canvas.getWidth(), canvas.getHeight());
            if (RectF.intersects(r, screen))
                canvas.drawBitmap(photo.bitmap, null, r, null);
        }
    }

    boolean onClick(float x, float y) {
        for (int i=0;i<photos.size();i++){
            WebMapPhoto photo = photos.get(i);
            if (photo.bitmap == null) continue;
            WebMapLocation point = photo.location;
            float l = rect.left+(point.x*width);
            float t = rect.top+(point.y*height);
            float r = l+photo.bitmap.getWidth()*S.default_scale;
            float b = t+photo.bitmap.getHeight()*S.default_scale;
            if (l<x && x<r && t<y && y<b){
                if (photo.pano){
                    int w= photo.width/8;// (int)(getWidth()/S.default_scale);
                    int h=(int)(page.getHeight()/(0.75f*S.default_scale));
                    int fo = 45;//(360*w)/photo.width;
                    if (fo > 120) fo=120;
                    int pi = 0;
                    float h3 = (b-t)/3;
                    if (y<(t+h3)) h=photo.height;
                    else if (y>(b-h3)) h=photo.height/2;
                    //int ya = (int)((180+((((x-l)/(r-l))*3))*120)) % 360;
                    WebPage page = Pages.add();
                    PanoImage pano = page.addPanoImage(w, h);
                    for(int ya=0; ya<360; ya+=fo){
                        pano.addTile(photo.getUrl(w,h,pi,ya,fo));
                    }

                } else {
                    int w = photo.width;
                    int h = photo.height;
                    if (w>4000/S.default_scale){
                        w/=2;
                        h/=2;
                    }
                    Pages.add(photo.getUrl(w,h), false);
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public void download(){
        WebMapLocation l1 = new WebMapLocation((-rect.left)/width,(page.getHeight()-rect.top)/height);
        WebMapLocation l2 = new WebMapLocation((page.getWidth()-rect.left)/width,(-rect.top)/height);
        String url = String.format(
                "https://www.google.bg/maps/preview/photo?authuser=0&hl=bg&gl=bg&pb=!1e1!2m6!3m2!3d%f!4d%f!4m2!3d%f!4d%f!5m50!2m2!1i203!2i100!3m2!2i22!5b1!7m42!1m3!1e1!2b0!3e3!1m3!1e2!2b1!3e2!1m3!1e2!2b0!3e3!1m3!1e3!2b0!3e3!1m3!1e8!2b0!3e3!1m3!1e3!2b1!3e2!1m3!1e9!2b1!3e2!1m3!1e10!2b0!3e3!1m3!1e10!2b1!3e2!1m3!1e10!2b0!3e4!2b1!4b1!9b0!6m2!7e81!15i9837!8d3.506902541955059"
                , l1.lat, l1.lon, l2.lat, l2.lon);
        page.downloadUrl(url, this, page.pageUrl, null);
    }

    @Override
    public void onResponse(URLConnection connection, InputStream inputStream) throws Exception{
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        byte[] buff = new byte[1024];
        int length;
        while ((length = inputStream.read(buff)) != -1)
            stream.write(buff, 0, length);
        String json = stream.toString();
        int i1 = 0;
        while (true){
            i1 = json.indexOf(C.http, i1);
            if (i1 < 0) break;
            int i2 = json.indexOf(C.quote, i1);
            if (i2 < 0) break;
            String url = S.getHtmlText(json, i1, i2);
            for(int i=0; i<photos.size();i++){
                if (url.equals(photos.get(i).src)){
                    url = null;
                    break;
                }
            }
            if (url == null){
                i1=i2;
                continue;
            }
            i1 = json.indexOf(C.open_square_bracket, i2);
            if (i1 < 0) continue;
            i2 = json.indexOf(C.comma, i1+1);
            if (i2 < 0) continue;
            Integer w = S.parseInteger(json.substring(i1+1,i2));
            if (w==null) continue;
            i1 = json.indexOf(C.close_square_bracket, i2);
            if (i1 < 0) continue;
            Integer h = S.parseInteger(json.substring(i2+1,i1));
            if (h==null) continue;
            i1 = json.indexOf("[[", i1);
            if (i1 < 0) continue;
            i1 = json.indexOf(C.comma, i1);
            if (i1 < 0) continue;
            i2 = json.indexOf(C.close_square_bracket, i1+1);
            if (i2 < 0) continue;
            double[] ll = S.getMapLocation(json.substring(i1+1,i2));
            if (ll == null) continue;
            WebMapLocation l = new WebMapLocation();
            l.update(ll[1],ll[0]);
            for(int i=0; i<photos.size();i++){
                float d = 0.000003f;
                WebMapLocation loc = photos.get(i).location;
                if (Math.abs(l.x-loc.x)<d && Math.abs(l.y-loc.y)<d)
                {l.x+=d; l.y+=d;}
            }
            photos.add(new WebMapPhoto(page, url, l, w, h));
        }
    }

    @Override
    public void onError(URLConnection connection, String error){
        //["https://lh5.googleusercontent.com/p/AF1QipPsQQkToEzF4UtmFQdfAdYae6sVNu3R1ly1RMZ0\u003dw203-h100-k-no-pi-0-ya100.49999-ro-0-fo100","",[7680,3840]
        //,[203,100]
        ///]
        //,null,[[3.0,23.994096115924002,39.99093592070678]
        //,[277.5,90.0]
        //,[7680,3840]
//					//,75.0]
//					String url = "https://lh5.googleusercontent.com/p/AF1QipPsQQkToEzF4UtmFQdfAdYae6sVNu3R1ly1RMZ0=w203-h100-k-no-pi-0-ya100.49999-ro-0-fo100";
//					double[] ll = parseMapLocation("23.994096115924002,39.99093592070678");
//					WebMapLocation l = new WebMapLocation();
//					l.update(ll[1],ll[0]);
//					locations.add(l);
//					tiles.add(new Tile(url, null));
        //log(error);
    }

    public void onDestroy() {
        for(int i = 0; i < photos.size(); i++) {
            photos.get(i).onDestroy();
        }
        page = null;
    }
}

package com.sp.browser;

import java.io.FileOutputStream;
import java.io.IOException;

class FileWriter
{
    ContainerOutput containerOutput;
    FileOutputStream fileOutput;
    FileWriter(String path, String name, long size) throws Exception  {
        if (S.isContainer(path)) {
            containerOutput = new ContainerOutput(path, name, size);
        }
        else
            fileOutput = new FileOutputStream(path + name);
    }
    void write(byte[] buffer, int offset, int size) throws IOException {
        if (containerOutput != null)
            containerOutput.write(buffer, offset, size);
        if (fileOutput != null)
            fileOutput.write(buffer, offset, size);
    }
    void close() throws IOException {
        if (containerOutput != null)
            containerOutput.close();
        if (fileOutput != null)
            fileOutput.close();
    }
}

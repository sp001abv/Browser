package com.sp.browser;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

class FileWriter
{
    ContainerOutput containerOutput;
    static ZipOutputStream zipOutput;
    FileOutputStream fileOutput;

    FileWriter(String path, String name, long size) throws Exception  {
        if (S.isContainer(path)) 
            containerOutput = new ContainerOutput(path, name, size);
        else if (S.isZipEntry(path)) {
            String[] s = S.getFilePathAndEntryName(path, C.zip);
            if (zipOutput == null)
                zipOutput = new ZipOutputStream(new FileOutputStream(s[0]));
            zipOutput.putNextEntry(new ZipEntry(s[1] + name));
        }
        else
            fileOutput = new FileOutputStream(path + name);
    }

    void write(byte[] buffer, int offset, int size) throws IOException {
        if (containerOutput != null)
            containerOutput.write(buffer, offset, size);
        else if (zipOutput != null)
            zipOutput.write(buffer, offset, size);
        else if (fileOutput != null)
            fileOutput.write(buffer, offset, size);    
    }

    void close() throws IOException {
        if (containerOutput != null)
            containerOutput.close();
        else if (zipOutput != null)
            zipOutput.closeEntry();
        else if (fileOutput != null)
            fileOutput.close();
    }

   static void closeOutput() {
        if (zipOutput != null) {
            try {
                zipOutput.close();
            } 
            catch (IOException e) {};
            zipOutput = null;
        }
    }

}

package com.sp.browser;

class Action {
    String getName() { return null; }
    int getColor(){ return S.color_link; }
    void onClick(float x, float y){}
}

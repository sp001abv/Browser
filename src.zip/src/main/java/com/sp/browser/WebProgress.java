package com.sp.browser;

class WebProgress extends WebText implements IProgress {
    boolean progress = true;
    WebPage page;
    WebProgress(WebPage page) {
        text = C.download;
        this.page = page;
        page.addItem(this);
    }
    @Override
    public boolean onProgress(String p) {
        if (p != null) {
            setText(p);
            if (Pages.active() == page)
                page.postInvalidate();
        }
        return progress;
    }
    @Override
    void onDestroy() {
        progress = false;
        page = null;
    }
}

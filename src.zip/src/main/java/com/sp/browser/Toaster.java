package com.sp.browser;

import android.os.Handler;
import android.widget.Toast;

class Toaster implements Runnable {
    String text;
    int duration;
    Toaster(String text, int duration){
        this.text = text;
        this.duration = duration;
        Handler mainHandler = new Handler(Pages.activity.getMainLooper());
        mainHandler.post(this);
    }
    @Override
    public void run() {
        Toast.makeText(Pages.activity.getApplicationContext(), text, duration).show();
    }

    static void postShortToast(String text) {
        new Toaster(text, Toast.LENGTH_SHORT);
    }

    static void postLongToast(String text) {
        new Toaster(text, Toast.LENGTH_LONG);
    }
}

package com.sp.browser;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;

class UrlProxy implements IDownload {
    String url;
    OutputStream outputStream;

    UrlProxy(WebPage page, String url, OutputStream outputStream) {
        this.url = url;
        this.outputStream = outputStream;
        page.downloadUrl(url, this, page.referer, null);
    }

    @Override
    public void download() {

    }

    @Override
    public void onResponse(URLConnection connection, InputStream inputStream) throws Exception {
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, length);
        }
        outputStream.close();
    }

    @Override
    public void onError(URLConnection connection, final String error) {
        //postLongToast(error);
    }
}

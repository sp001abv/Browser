package com.sp.browser;

class WebRadioInput extends WebCheckInput {
    WebRadioInput(String name, String value, boolean checked){
        super(name,value,checked);
        setText("●");
    }
}

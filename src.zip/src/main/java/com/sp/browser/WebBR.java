package com.sp.browser;

import android.graphics.Canvas;

class WebBR extends WebText {
    WebBR() {
        width = 1;
        height = paint.getTextSize();
        text = String.valueOf(C.newline);
    }

    @Override
    void onDraw(Canvas canvas) {

    }

    @Override
    boolean wrap(float w, float h) {
        return true;
    }
}

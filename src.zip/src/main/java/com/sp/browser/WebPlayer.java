package com.sp.browser;

import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaPlayer;
import android.os.Handler;
import android.view.Surface;
import android.view.View;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;

class WebPlayer extends WebItem implements
        IProgress,
        VideoSurfaceView.Callback,
        MediaPlayer.OnPreparedListener, MediaPlayer.OnVideoSizeChangedListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnSeekCompleteListener, MediaPlayer.OnErrorListener
{
    ArrayList<String> commands = new ArrayList<String>();
    final String[] sAspectRatios = {"□", "4:3", "16:9", "■"};
    final float[] fAspectRatios = {1, 4.0f/3.0f, 16.0f/9.0f, 0};
    int aspectRatio;
    int rotateAngle;
    float zoom;

    VideoSurfaceView videoView;
    VideoPlayer videoPlayer;
    int videoWidth;
    int videoHeight;
    String trackInfo;
    int videoDuration;
    int videoPosition;
    int seekToFramePostion;
    int repeatTime1;
    int repeatTime2;
    boolean navigating = false;
    boolean show_info = false;
    boolean seeking = false;
    String info;
    float infoOffset;
    boolean downloading;
    BufferedReader infoReader;
    GLBitmapTextureRenderer navigationRenderer;
    VolumeControlView volume = new VolumeControlView();
    Subtitles subtitles;
    DisqusView disqusView;
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    boolean saveFrame;
    String fileName;
    WebPage page;

    WebPlayer(WebPage page, String url)
    {
        this.page = page;
        href = url;
        Pages.activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        commands.add("s");
        commands.add("i");
        commands.add("|<<");
        commands.add("|<");
        commands.add("<<");
        commands.add("||");
        commands.add(">>");
        commands.add(">|");
        commands.add(">>|");
        aspectRatio = url.equals(S.lastVideoUrl) ? S.lastVideoAspectRatio : 0;
        zoom = 1.0f;
        commands.add(sAspectRatios[aspectRatio]);
        commands.add("c");
        videoView = new VideoSurfaceView(page.getContext(), this);
        videoView.setSystemUiVisibility(videoView.getWindowSystemUiVisibility() | (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY));
        page.addView(videoView);
        videoView.setAspectRatio(fAspectRatios[aspectRatio]);
        videoView.setZoom(zoom);
    }

    boolean play(boolean next){
        String url = page.getMediaHref(next);
        if (url != null) {
            if (S.isVideo(url)) {
                if (S.isLocalFile(url) || S.isContainerFile(url) || page.slideshow != null) {
                    page.pageUrl = href = url;
                    preparePlayer();
                    return true;
                }
            } else if (S.isImage(url)){
                if (page.slideshow != null) {
                    release();
                    page.slideshow.loadImage(url);
                    return true;
                }
                if (S.isLocalFile(url) || S.isContainerFile(url)) {
                    while (true) {
                        url =  page.getMediaUrlHref(url, next);
                        if (url == null)
                            return false;
                        if (S.isVideo(url)) {
                            page.pageUrl = href = url;
                            preparePlayer();
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }


    void releasePlayer() {
        if (videoPlayer != null) {
            videoPlayer.release();
            videoPlayer = null;
        }
    }

    int getNavigationHeight() {
        return S.text_size * 3;
    }


    float centerText(String text, float x, float sx) {
        return x + (sx-paint.measureText(text))/2;
    }

    void drawText(Canvas canvas, String text, float x, float y, float sx) {
        canvas.drawText(text, centerText(text, x, sx), y, paint);
    }

    String getInfo() {
        String text = null;
        if (info != null) {
            text = info;
        }
        else if (show_info) {
            StringBuilder info = new StringBuilder();
            info.append(fileName);
            info.append(C.space);
            info.append(videoWidth);
            info.append(C.times);
            info.append(videoHeight);
            info.append(C.space);
            if (S.fps != null) {
                info.append(S.fps);
                info.append(C.space);
            }
            if (trackInfo == null)
                trackInfo = getTrackInfo();
            if (trackInfo != C.empty) {
                info.append(trackInfo);
                info.append(C.space);
            }
            if (repeatTime1 > 0) {
                info.append(S.formatTimeStamp(repeatTime1));
                info.append(C.dash);
            }
            if (repeatTime2 > 0) {
                info.append(S.formatTimeStamp(repeatTime2));
                info.append(C.space);
            }
            if (subtitles != null && subtitles.subtitlesFile != null) {
                info.append(subtitles.subtitlesFile);
                info.append(C.space);
                if (subtitles.subtitlesTimeOffset != 0) {
                    info.append(subtitles.subtitlesTimeOffset);
                    info.append(C.space);
                }

            }
            if (seekToFramePostion > 0) {
                info.append(S.formatTimeStamp(seekToFramePostion));
                info.append(C.space);
            }
            text = info.toString();
        }
        return text;
    }

    void drawNavigation(Canvas canvas) {
        float y = 0;
        paint.setColor(Color.BLACK);
        RectF rect = new RectF(0, y, width,y + getNavigationHeight());
        canvas.drawRect(rect,paint);
        paint.setColor(S.color_text);
        paint.setTextSize(S.text_size);
        y += paint.getTextSize();

        String info = getInfo();
        if (info != null) {
            drawText(canvas, info, infoOffset, y, width);
            y += paint.getTextSize() * 0.25f;
        }
        else {
            y -= paint.getTextSize() * 0.5f;
        }

        rect.top = y;
        float bottom = y + paint.getTextSize() * 0.5f;
        rect.bottom = bottom;
        paint.setColor(0xFF202020);
        canvas.drawRect(rect,paint);
        rect.top += paint.getTextSize() * 0.1f;
        rect.bottom -= paint.getTextSize() * 0.1f;
        if (videoDuration > 0) {
            rect.right = (width * videoPosition) / videoDuration;
            paint.setColor(0xFF008000);
            canvas.drawRect(rect,paint);
            if (repeatTime2 > repeatTime1  || repeatTime1 > 0){
                rect.top = rect.bottom;
                rect.bottom = bottom;
                rect.left = (width * repeatTime1) / videoDuration;
                rect.right = repeatTime2 > repeatTime1 ? (width * repeatTime2) / videoDuration : width;
                canvas.drawRect(rect,paint);
            }
        }

        paint.setColor(S.color_text);
        y = getNavigationHeight() - (getNavigationHeight() - bottom - paint.getTextSize()) * 0.6f;
        float x = 0;
        float sx = width / (commands.size() + 2);
        drawText(canvas, (show_info && repeatTime1 > 0) || (seekToFramePostion > 0) ? S.formatTimeStamp(videoPosition) : S.formatTime(videoPosition), x, y, sx);
        x+=sx;
        for(int i=0; i < commands.size(); i++)
        {
            drawText(canvas, commands.get(i), x, y, sx);
            x+=sx;
        }
        drawText(canvas, S.formatTime(videoDuration), x, y, sx);
    }

    @Override
    void onDraw(Canvas canvas) {
        width = canvas.getWidth();
        height = canvas.getHeight();
    }

    boolean hitOnInfo(float y) {
        return (info != null || (navigating && show_info)) && (y > height - getNavigationHeight() && y < height - getNavigationHeight() + S.text_size);
    }

    @Override
    boolean onScroll(float x, float y,float scroll) {
        offset(x, y, 0, scroll * (-2.5f));
        return true;
    }

    @Override
    boolean offset(float x, float y, float dx, float dy) {
        if (x > width * 0.75f && y > getNavigationHeight() && y < height - getNavigationHeight())
            volume.onOffset(dy);
        else if (hitOnInfo(y))
            infoOffset += dx;
        else if (subtitles != null && y > subtitles.positionY)
            subtitles.onOffset(dx, dy);
        else if (Math.abs(dx) > Math.abs(dy))
            seekTo(videoPosition + (int)Math.signum(dx)*10000);
        else if (disqusView != null && x< disqusView.width && y< disqusView.height)
            disqusView.onOffset(dy);
        else
            setZoom(dy);
        return false;
    }

    @Override
    boolean wrap(float w, float h) {
        width = w;
        height = h;
        return true;
    }

    void preparePlayer(){
        repeatTime1 = repeatTime2 = videoPosition = videoDuration = videoHeight = videoWidth = 0;
        trackInfo = info = null;
        infoOffset = 0;
        infoReader = null;
        fileName = S.getFileName(href);
        if (S.isGoogleVideo(href)) {
            int i = href.lastIndexOf(C.equals);
            if (i > 0 && href.length()-i<80)
                fileName = href.substring(i+1);
            fileName += C.mp4;
        }
        if (videoPlayer == null){
            videoPlayer = new VideoPlayer();
            videoPlayer.setOnPreparedListener(this);
            videoPlayer.setOnVideoSizeChangedListener(this);
            videoPlayer.setOnCompletionListener(this);
            videoPlayer.setOnSeekCompleteListener(this);
            videoPlayer.setOnErrorListener(this);
            videoPlayer.setSurface(new Surface(videoView.getSurfaceTexture()));
        } else {
            videoView.render = false;
            videoPlayer.reset();
        }
        try {
            String video;
            String audio = null;
            if (S.isLocalFile(href)) {
                video = S.getLocalPath(href);
                if (S.codec_player) {
                    audio = video.substring(0, video.lastIndexOf(C.dot)) + C.mpa;
                    if (!new File(audio).exists())
                        audio = null;
                }
            }
            else if (S.isContainerFile(href)) {
                video = S.buildWebServerUrl(href);
                if (!WebServer.isStarted)
                    WebServer.startStop();
            }
            else {
                int i = href.indexOf(C.newline);
                if (i > 0) {
                    audio = href.substring(i+1);
                    video = href.substring(0,i);
                }
                else {
                    video = href;
                }
            }
            videoPlayer.setDataSource(video, audio, S.codec_player);
            videoPlayer.prepareAsync();
        } catch (Exception e) {
            info = e.getMessage();
            releasePlayer();
            navigating = true;
        }
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        if (S.lastVideoPosition > 0 && href.equals(S.lastVideoUrl))
            videoPlayer.seekTo(S.lastVideoPosition);
        S.lastVideoUrl = href;
        videoPlayer.start();
        videoView.render = true;
        videoDuration = videoPlayer.getDuration();
        if (videoDuration > 1200000)
            toggleSubtitles();
    }

    void selectTrack(float x) {
        Object[] trackInfo = videoPlayer.getTrackInfo();
        if (trackInfo != null) {
            String info = getInfo();
            x -= centerText(info, infoOffset, width);
            for (int index = 0 ; index < trackInfo.length ; index++) {
                String s = getTrackInfo(trackInfo[index]);
                if (s != null) {
                    int i = info.indexOf(s);
                    if (i > 0)
                    {
                        float x1 = paint.measureText(info.substring(0, i));
                        float x2 = x1 + paint.measureText(s);
                        if (x1 < x && x < x2) {
                            videoPlayer.selectTrack(index);
                            break;
                        }
                    }
                }
            }
        }
    }

    String getTrackInfo(Object trackInfo) {
        String s = trackInfo == null ? C.empty : trackInfo.toString();
        int i = s.indexOf(C.equals);
        return i > 0 ? s.substring(i+1, s.length()-2) : s;
    }

    String getTrackInfo() {
        try {
            Object[] trackInfo = videoPlayer.getTrackInfo();
            if (trackInfo != null) {
                StringBuilder sb = new StringBuilder();
                for(int index = 0; index < trackInfo.length; index++) {
                    String s = getTrackInfo(trackInfo[index]);
                    if (s != null) {
                        sb.append(s);
                        sb.append(C.space);
                    }
                }
                if (sb.length() > 0)
                    return sb.toString();
            }
        } catch (Exception e) {

        }
        return C.empty;
    }

    @Override
    public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
        videoWidth = width;
        videoHeight = height;
        seeking = false;
        videoView.setVideoSize(videoWidth, videoHeight);
        if (videoWidth == 720 && videoHeight == 576)
            setAspectRatio(1);
    }

    void setAspectRatio(int index)
    {
        aspectRatio = index;
        if (aspectRatio == sAspectRatios.length) aspectRatio = 0;
        commands.set(9, sAspectRatios[aspectRatio]);
        videoView.setAspectRatio(fAspectRatios[aspectRatio]);
    }

    void setZoom(float dz)
    {
        if (dz < 0)
            zoom *= C.scale_step_16;
        else {
            zoom /= C.scale_step_16;
            if (zoom < 1.0f)
                zoom = 1.0f;
        }
        videoView.setZoom(zoom);
    }

    void onCompletion() {
        if (repeatTime1 > 0) {
            seekTo(repeatTime1);
            if (!videoPlayer.isPlaying())
                videoPlayer.start();
            return;
        }

        if (downloading)
            return;

        if (play(true))
            return;

        S.lastVideoUrl = null;

        Pages.activity.onBack();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        new Handler(page.getContext().getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                onCompletion();
            }
        });
    }

    @Override
    public void onSeekComplete(MediaPlayer mp) {
        seeking = false;
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        if (!(what == -38 && extra == 0)) {
            info = String.format("error %d, 0x%X", what, extra);
            navigating = true;
        }
        return true;
    }

    void release() {
        Pages.activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        releasePlayer();
        videoView.release();
        page.removeView(videoView);
    }

    @Override
    void onDestroy() {
        S.lastVideoPosition = videoDuration > 0 ?  videoPosition : 0;
        S.lastVideoAspectRatio = aspectRatio;
        downloading = false;
        release();
        page = null;
    }

    void seekTo(int seekTime) {
        if (seeking) return;
        seeking = true;
        if (seekTime == 0 && videoPosition < 3000 && play(false)){
            return;
        }
        videoPlayer.seekTo(seekTime);
    }

    void playPause() {
        if (videoPlayer.isPlaying())
            videoPlayer.pause();
        else
            videoPlayer.start();
        seekToFramePostion = 0;
    }

    private void toggleSubtitles() {
        if (S.isLocalFile(page.pageUrl)) {
            try {
                if (subtitles == null)
                    subtitles = new Subtitles(height * 0.75f);
                subtitles.toggle(page);
            } catch (Exception e) {
                info = e.getMessage();
            }
        }
        else {
            if (disqusView != null)
                disqusView.toggle();
            else {
                String url = Pages.getClipboardText();
                if (url != null && url.startsWith(C.disqus_comments))
                    disqusView = new DisqusView(page, url, (int)(videoView.getWidth()*0.25f),(int)(videoView.getHeight()*0.82f));
            }
        }
    }

    @Override
    void onClick(float x, float y) {
        if (y<height/2) {
            if (y < S.text_size) {
                if (x < width / 2 ) {
                    rotateAngle -= 90;
                    videoView.setRotateAngle(rotateAngle);
                } else {
                    rotateAngle += 90;
                    videoView.setRotateAngle(rotateAngle);
                }
            } else
                playPause();
        }
        else if (y<height-getNavigationHeight()) {
            navigating = !navigating;
        }
        else if (hitOnInfo(y)) {
            selectTrack(x);
        }
        else if (!navigating || y < height - getNavigationHeight()*(info != null || show_info ? 0.4f : 0.6f)) {
            float dx = S.text_size/2;
            if (repeatTime1 == 0 && x > width-dx)
                play(true);
            else if (videoPlayer.isPlaying())
                seekTo(x <dx ? 0: (int)((videoDuration * x) /width));
            else if (x > width / 2) {
                seekToFramePostion = videoPosition;
                videoPlayer.start();
            }
            else {
                seekToFramePostion -= 100;
                videoPlayer.seekTo(seekToFramePostion-1000);
                videoPlayer.start();
            }
        }
        else {
            int command = (int)(x * (commands.size()+2) / width);
            switch (command) {
                case 1:
                    toggleSubtitles();
                    break;
                case 2:
                    show_info = !show_info;
                    info = null;
                    infoOffset = 0;
                    break;
                case 3:
                    seekTo(repeatTime1);
                    break;
                case 4:
                    info = null;
                    infoOffset = 0;
                    repeatTime1 = videoPosition;
                    break;
                case 5:
                    if (!videoPlayer.isPlaying()) {
                        if (seekToFramePostion == 0)
                            seekToFramePostion = videoPosition;
                        seekToFramePostion -= 100;
                        videoPlayer.seekTo(seekToFramePostion-1000);
                        videoPlayer.start();
                    }
                    else if (repeatTime1 > 0)
                        seekTo(repeatTime1 - 2000);
                    else
                        seekTo(videoPosition - 10000);
                    break;
                case 6:
                    playPause();
                    break;
                case 7:
                    if (!videoPlayer.isPlaying()) {
                        seekToFramePostion = videoPosition;
                        videoPlayer.start();
                    }
                    else if (repeatTime2 > 0)
                    {
                        repeatTime2 = 0;
                    }
                    else
                        seekTo(videoPosition + 10000);
                    break;
                case 8:
                    repeatTime2 = videoPosition;
                    break;
                case 9:
                    if (repeatTime2 > 0)
                    {
                        int seekToTime =  repeatTime2 - 4000;
                        if (seekToTime < repeatTime1)
                            seekToTime = repeatTime1;
                        seekTo(seekToTime);
                    }
                    else
                        play(true);
                    break;
                case 10:
                    setAspectRatio(++aspectRatio);
                    break;
                case 11:
                    if ((repeatTime2 > repeatTime1) || (repeatTime1 > 0 && repeatTime2 == 0))
                        cutVideo();
                    else if (videoPlayer.isPlaying() || downloading) {
                        if (downloading)
                            downloading = false;
                        else
                            downloadVideo();
                    }
                    else
                        saveFrame = true;
                    break;
            }
        }
    }

    @Override
    public boolean onProgress(String progress) {
        if (progress != null) {
            info = progress;
        }
        else {
            downloading = false;
        }
        return downloading;
    }


    private void downloadVideo() {
        String date = S.getDateFromFileName(fileName);
        String path = date != null ? S.getArchiveFolder(date) : S.output_folder;

        if (new File(path + fileName).exists()) {
            info = path + fileName + " exists";
            return;
        }

        if (S.haveSameStorage(href, path)) {
            path += fileName;
            info = S.moveFile(href, path);
            if (info.startsWith(C.moved)) {
                String prev = page.getMediaHref(false);
                if (prev != null)
                    page.pageUrl = prev;
                Pages.prev().removeLocalFile(href);
            }
            return;
        }
        new UrlDownloader(page, href, null, path + fileName, this );
        downloading = true;
    }

    private void cutVideo() {
        if (videoPlayer.isPlaying())
            playPause();
        try {
            String in = S.isLocalFile(href) ? S.getLocalPath(href) : href;
            ArrayList<String> arg = new ArrayList<String>(16);
            arg.add("ffmpeg");
            arg.add("-y");
            if (repeatTime1 > 0) {
                arg.add("-ss");
                arg.add(S.formatTimeStamp(repeatTime1 + 100));
            }
            arg.add("-i");
            arg.add(in);
            if (repeatTime2 > 0) {
                arg.add("-t");
                arg.add(S.formatTimeStamp(repeatTime2 - repeatTime1));
            }
            arg.add("-c");
            arg.add("copy");
            String date = S.getDateFromFileName(fileName);
            String path = date != null ? S.getArchiveFolder(date) : S.output_folder;
            info =	path + S.removeExt(fileName) + C.space +
                    (videoDuration > 6000000  ?
                            S.formatMinutes("%03d.%02d", repeatTime1) :
                            S.formatMinutes("%02d.%02d", repeatTime1)) + C.dash +
                    S.formatMinutes("%d.%02d",
                            (repeatTime2 > 0 ? repeatTime2 : videoDuration) - repeatTime1) +
                    fileName.substring(fileName.lastIndexOf(C.dot));
            arg.add(info);
            String[] args = new String[arg.size()];
            arg.toArray(args);
            infoReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(args).getErrorStream()));
        } catch (Exception e){
            info = e.getMessage();
        }
    }

    void prepareNavigationRenderer(){
        if (navigationRenderer == null)
            navigationRenderer = videoView.createBitmapRenderer(videoView.getWidth(), getNavigationHeight(), false);
    }

    @Override
    public void onDrawFrame() {
        if (saveFrame) {
            info = S.saveBitmap(videoView.copyFrame(), S.output_folder, S.getFileNameFromTime());
            saveFrame = false;
            return;
        }

        if (videoPlayer != null)
            videoPosition = videoPlayer.getCurrentPosition();

        if (seekToFramePostion > 0 && videoPosition >= seekToFramePostion)
            videoPlayer.pause();

        if (repeatTime1 > 0 && videoPosition < repeatTime1 && (videoPosition > 0 || repeatTime2 > repeatTime1))
            repeatTime1 = videoPosition;

        if (repeatTime2 > repeatTime1 && videoPosition >= repeatTime2) {
            seekTo(repeatTime1);
        }

        if (subtitles != null)
            subtitles.onDrawFrame(videoView, videoPosition);

        if (disqusView != null)
            disqusView.onDrawFrame(videoView);

        if (infoReader != null){
            try {
                String line;
                while ((line = infoReader.readLine()) != null){
                    info = line;
                    if (line.startsWith("frame")){
                        int i = line.indexOf("time=");
                        if (i > 0){
                            Integer time = S.parseTime(line.substring(i+5,line.indexOf(C.space,i+7)));
                            if (time != null) {
                                videoPosition = repeatTime1 + time;
                            }
                            break;
                        }
                    }
                }
                if (line == null) {
                    infoReader = null;
                    if (repeatTime2 > 0) {
                        int seekTime = repeatTime2;
                        repeatTime2 = 0;
                        seekTo(seekTime);
                        playPause();
                    }
                }
            }
            catch (Exception e){
                info = e.getMessage();
                infoReader = null;
            }
        }

        if (navigating) {
            if (S.fpsUpdated() || info != null || show_info)
                drawNavigation(navigationRenderer.getCanvas(0, height - getNavigationHeight(), width, height));
            navigationRenderer.render();
        }

        volume.onDrawFrame(videoView);
    }

    @Override
    public void onSurfaceCreated() {
        preparePlayer();
        prepareNavigationRenderer();
    }

    @Override
    public void onError(String error) {
        info = error;
    }

}

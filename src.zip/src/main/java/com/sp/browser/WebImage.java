package com.sp.browser;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

import java.io.InputStream;
import java.net.URLConnection;

class WebImage extends WebItem implements IDownload {
    @Override
    public void onError(URLConnection connection, String error){
        visited = true;
    }

    @Override
    public void onResponse(URLConnection connection, InputStream inputStream){
        if (src != null)
            Pages.setImageBitmap(src, S.decodeImage(inputStream));
    }

    @Override
    public void download() {
        if (src != null) {
            page.downloadUrl(src, this, page.pageUrl, null);
        }
    }

    Bitmap bitmap = null;
    String src;
    boolean visited = false;
    boolean download = false;
    WebPage page;
    public WebImage(WebPage page, Bitmap bitmap, String href) {
        this.page = page;
        src = href;
        setBitmap(bitmap);
    }

    public WebImage(WebPage page, String url, String href) {
        this.page = page;
        src = url;
        this.href = href;
        WebImage image = Pages.findImage(src);
        if (image != null) {
            setBitmap(image.bitmap);
        } else {
            download = true;
            width = height = S.text_size;
        }
    }

    @Override
    void onDraw(Canvas canvas) {
        if (bitmap != null) {
            if (bitmap.getWidth() > canvas.getMaximumBitmapWidth() ||
                    bitmap.getHeight() > canvas.getMaximumBitmapHeight()) {
                Rect crop = S.getCrop(bitmap, canvas.getWidth(), canvas.getHeight(), rect);
                if (crop != null && (crop.width() <= canvas.getWidth() || crop.height() <= canvas.getHeight())) {
                    Bitmap cropped = Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height());
                    canvas.drawBitmap(cropped, null,
                            new RectF(
                                    rect.left < 0 ? 0 : rect.left,
                                    rect.top < 0 ? 0 : rect.top,
                                    rect.right > canvas.getWidth() ? canvas.getWidth() : rect.right,
                                    rect.bottom > canvas.getHeight() ? canvas.getHeight() : rect.bottom
                            ), null);
                    return;
                }
                float scale = rect.width() / bitmap.getWidth();
                int width = (int)(bitmap.getWidth()*scale);
                int height = (int)(bitmap.getHeight()*scale);
                if (width > canvas.getMaximumBitmapWidth() || height > canvas.getMaximumBitmapHeight()) {
                    scale = (float)canvas.getMaximumBitmapHeight() / (float)bitmap.getHeight();
                    if (scale > (float)canvas.getMaximumBitmapWidth() / (float)bitmap.getWidth())
                        scale = (float)canvas.getMaximumBitmapWidth() / (float)bitmap.getWidth();
                    width = (int)(bitmap.getWidth()*scale);
                    height = (int)(bitmap.getHeight()*scale);
                }
                if (scale < 1.0f) {
                    Bitmap scaled = Bitmap.createScaledBitmap(bitmap, width, height,true);
                    canvas.drawBitmap(scaled, null, rect, null);
                    return;
                }

            } else canvas.drawBitmap(bitmap, null, rect, null);
        }
        else {
            Paint paint = new Paint();
            paint.setColor(visited ? S.color_visited : S.color_link);
            paint.setTextSize(height);
            canvas.drawText("¤", rect.left, rect.bottom, paint);
            if (download) {
                download = false;
                S.downloadAsync(this);
            }
        }
    }
    @Override
    void select(float x1, float y1, float x2, float y2)
    {
        if (rect.contains(x1, y1))
            Pages.add(src);
    }

    @Override
    void onClick(float x, float y)
    {
        if (bitmap == null){
            visited = true;
            Pages.add(src);
            return;
        }
        else if (S.block_images) {
            S.blockedImages.add(src);
            page.removeItem(this);
            page.invalidateLayout();
            return;
        }
        super.onClick(x, y);
    }

    @Override
    void onDoubleClick(float x, float y) {
        if (bitmap == null) {
            super.onClick(x, y);
            return;
        }
        toggleFit();
    }

    void fitActualSize() {
        width = bitmap.getWidth();
        height = bitmap.getHeight();
        if (page.centered() && page.rotateAngle == 0) {
            page.panX = (page.getWidth() - width) / 2;
            page.panY = (page.getHeight() - height) / 2;
        }
        page.invalidateLayout();
    }

    void fitView() {
        float sx = page.getHeight() / height;
        float sy = page.getWidth() / width;
        scale(sx > sy ? sy : sx);
        rect.left = rect.right;
        page.invalidateLayout();
    }

    void toggleFit() {
        if (Math.abs(rect.width()-bitmap.getWidth())<2 && Math.abs(rect.height()-bitmap.getHeight())<2)
            fitView();
        else
            fitActualSize();
    }

    void setBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            this.bitmap = bitmap;
            width = bitmap.getWidth()*S.default_scale;
            height = bitmap.getHeight()*S.default_scale;
        }
    }

    @Override
    void onDestroy() {
        bitmap = null;
        src = null;
        page = null;
    }

    @Override
    boolean wrap(float w, float h) {
        if (width > w) {
            height *= w / width;
            width = w;
        }
        if (height > h) {
            width *= h / height;
            height = h;
        }
        return true;
    }

}

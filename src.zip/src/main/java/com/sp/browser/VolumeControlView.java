package com.sp.browser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.os.SystemClock;

class VolumeControlView {
    long settingVolumeTime = 0;
    float newVolume;
    int currentVolume;
    int maxVolume;
    boolean update = true;
    GLBitmapTextureRenderer renderer;
    int width;
    int height;

    void onOffset(float offset) {
        AudioManager audioManager = (AudioManager)Pages.activity.getSystemService(Context.AUDIO_SERVICE);
        if (currentVolume != audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)){
            newVolume = currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            update = true;
        }
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        newVolume -= offset * 0.1f;
        if (newVolume < 0) newVolume = 0;
        if (newVolume > maxVolume) newVolume = maxVolume;
        if ((int)newVolume != currentVolume) {
            currentVolume = (int)newVolume;
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume, 0);
            settingVolumeTime = SystemClock.elapsedRealtime();
            update = true;
        }
    }

    void onDrawFrame(VideoSurfaceView videoView) {
        if (settingVolumeTime > 0) {
            if (maxVolume == 0)
                onOffset(0);
            if (renderer == null) {
                width = S.text_size;
                height = S.text_size * maxVolume / 2;
                renderer = videoView.createBitmapRenderer(width, height, false);
            }

            if (update) {
                int w = videoView.getWidth();
                int h = videoView.getHeight();
                Canvas canvas = renderer.getCanvas(w*0.85f, (h - height)*0.5f, w, h);
                RectF rect = new RectF(0, 0, width, height);
                Paint paint = new Paint();
                paint.setColor(S.color_text);
                canvas.drawRect(rect,paint);
                final float border = 1;
                rect.top += border;
                rect.left += border;
                rect.right -= border;
                rect.bottom -= border;
                paint.setColor(S.color_background);
                canvas.drawRect(rect,paint);
                rect.top = rect.bottom - (rect.height()*currentVolume)/maxVolume;
                paint.setColor(S.color_link);
                canvas.drawRect(rect,paint);
                update = false;
            }

            renderer.render();
            if ((SystemClock.elapsedRealtime() - settingVolumeTime) > 1000)
                settingVolumeTime = 0;
        }
    }
}

package com.sp.browser;

import android.graphics.RectF;

interface ITextEditor {
    boolean startEditing(float x, float y);
    boolean onEnter();
    boolean onTab(boolean shift);
    boolean onLeft(boolean shift, boolean home);
    boolean onRight(boolean shift, boolean end);
    boolean onUp(boolean shift, float dy);
    boolean onDown(boolean shift, float dy);
    void del();
    boolean paste(String text);
    void save();
    void copy(StringBuilder builder);
    boolean undo();
    RectF rect();
    RectF cursor();
    void stopEditing();
}

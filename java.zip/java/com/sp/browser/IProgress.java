package com.sp.browser;

interface IProgress {
    boolean onProgress(String progress);
}

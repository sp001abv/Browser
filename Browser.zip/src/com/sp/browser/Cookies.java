package com.sp.browser;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

class Cookies {
    static ArrayList<CookieDomain> domains = new ArrayList<CookieDomain>();

    static void setCookie(String domain, String name, String value){
        for(int i=0;i<domains.size();i++){
            CookieDomain d = domains.get(i);
            if(domain.equals(d.domain)){
                d.setCookie(name,value);
                return;
            }
        }
        CookieDomain d = new CookieDomain(domain);
        d.setCookie(name, value);
        domains.add(d);
    }
    static String getCookies(String domain){
        for(int i=0;i<domains.size();i++){
            CookieDomain d = domains.get(i);
            if(domain.equals(d.domain)){
                return d.getCookies();
            }
        }
        return null;
    }
    static void load(){
        domains.clear();
        try
        {
            FileInputStream is = new FileInputStream(S.home_folder + C.cookies_file);
            int domainssize = is.read();
            for(int i=0;i<domainssize;i++){
                String domain = S.readString(is);
                int cookiessize = is.read();
                for(int j=0;j<cookiessize;j++)
                    setCookie(domain, S.readString(is), S.readString(is));
            }
            is.close();
        }
        catch (Exception e)
        {
        }
    }
    static void save() {
        try
        {
            FileOutputStream os = new FileOutputStream(S.home_folder + C.cookies_file);
            os.write(domains.size());
            for(int i=0;i<domains.size();i++){
                CookieDomain cd = domains.get(i);
                S.writeString(os, cd.domain);
                os.write(cd.cookies.size());
                for(int j=0;j<cd.cookies.size();j++){
                    Cookie c = cd.cookies.get(j);
                    S.writeString(os,c.name);
                    S.writeString(os,c.value);
                }
            }
            os.close();
        }
        catch (Exception e)
        {
        }
    }
}

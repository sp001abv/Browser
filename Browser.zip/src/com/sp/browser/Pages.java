package com.sp.browser;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.MimeTypeMap;

import java.util.ArrayList;

class Pages {
    private static Queue<WebPage> pages = new Queue<WebPage>();
    static MainActivity activity;

    static void clear() {
        WebPage page = pages.poll();
        while(page != null) {
            page.onDestroy();
            page = pages.poll();
        }
    }

    static void add(String url, Boolean refer, WebForm form, String type) {
        Downloader.clear();
        if (pages.size > 15)
            pages.poll().onDestroy();
        pages.add(new WebPage(activity, url, refer ? referer() : null , form, type));
    }

    static void add(String url, Boolean refer, WebForm form) {
        add(url, refer, form, null);
    }

    static void add(String url, Boolean refer) {
        add(url, refer, null);
    }

    static void add(String url, String type) {
        add(url, true, null, type);
    }

    static void add(String url) {
        add(url, true, null);
    }

    static WebPage add() {
        add(null);
        return pages.last();
    }

    static WebPage cut() {
        return pages.cut();
    }

    static WebPage active() {
        return pages.last();
    }

    static WebPage prev() {
        return pages.prev();
    }

    static String referer() {
        WebPage page = pages.last();
        return page != null ? page.pageUrl : null;
    }

    static WebImage findImage(String src) {
        synchronized (pages) {
            for(Queue<WebPage>.Item page = pages.first; page != null; page = page.next) {
                ArrayList<WebImage> images = page.element.images;
                for (int i = 0; i < images.size(); i++) {
                    WebImage image = images.get(i);
                    if (image.src.equals(src))
                        return image;
                }
            }
        }
        return null;
    }

    static void setImageBitmap(String src, Bitmap bitmap) {
        int count = 0;
        int size = S.image_hash_size / 2;
        WebImage free = null;
        synchronized (pages){
            for(Queue<WebPage>.Item page = pages.first; page != null; page = page.next) {
                ArrayList<WebImage> images = page.element.images;
                for (int i = 0; i < images.size(); i++) {
                    WebImage image = images.get(i);
                    Bitmap b = image.bitmap;
                    if (b != null) {
                        count += b.getByteCount();
                        if (free == null && count > size)
                            free = image;
                    } else {
                        String s = image.src;
                        if (s != null && s.equals(src)) {
                            image.setBitmap(bitmap);
                        }
                    }
                }
            }
            if (count > S.image_hash_size){
                for (Queue<WebPage>.Item page = pages.first; page != null; page = page.next) {
                    ArrayList<WebImage> images = page.element.images;
                    for (int i = 0; i < images.size(); i++) {
                        WebImage image = images.get(i);
                        if (image.bitmap != null && (page.next != null || image.rect.bottom + 2000 < 0 || image.rect.top - 2000 > 0)) {
                            image.bitmap = null;
                            image.download = true;
                        }
                        if (image == free)
                            return;
                    }
                }
            }
        }
    }

    static String getClipboardText() {
        ClipboardManager clipboard = (ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount()>0) {
            ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
            if (item.getText().length() > 0)
                return String.valueOf(item.getText());
        }
        return null;
    }

    static void setClipboardText(String text) {
        ClipboardManager clipboard = (ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText(C.empty, text != null ? text : C.empty));
    }

    static void openUrlExternally(String url, String type, float x, float y) {
        try
        {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            if (type == null) {
                if (url.startsWith(C.http))
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                String extension = S.getExt(url);
                if (extension != null)
                    type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
            } else
                type = S.getMimeType(type);
            intent.setDataAndType(Uri.parse(url), type);
            activity.startActivity(intent);
        }
        catch (Exception e)
        {
            S.openFileAsActions.show(url, false, x, y);
        }
    }

    static boolean isExternalUrl(String url) {
        return url.startsWith(C.magnet) || url.startsWith(C.acestream);        
    }

    static void openUrl(String url, float x, float y){
        if (S.isLocalFolder(url))
            add(url);
        else if (S.isLocalFile(url)) {
            if (S.isText(url))
                add(url, C.text);
            else if (S.isVideo(url))
                add(url, C.video);
            else if (S.isImage(url))
                add(url, C.image);
            else
                openUrlExternally(url, null, x, y);
        }
        else if (isExternalUrl(url))
            openUrlExternally(url, null, x, y);
        else
            add(url);
    }

    static void openGoogleMap(String url){
        try{
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage("com.google.android.apps.maps");
            intent.setData(Uri.parse(url));
            activity.startActivity(intent);
        } catch (Exception e)
        {
            Toaster.postLongToast(e.getMessage());
        }
    }
}
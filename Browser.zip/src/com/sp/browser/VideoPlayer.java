package com.sp.browser;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.os.SystemClock;
import android.view.Surface;

import java.nio.ByteBuffer;


class VideoPlayer
{
    MediaPlayer.OnPreparedListener onPreparedListener;
    MediaPlayer.OnVideoSizeChangedListener onVideoSizeChangedListener;
    MediaPlayer.OnCompletionListener onCompletionListener;
    MediaPlayer.OnSeekCompleteListener onSeekCompleteListener;
    MediaPlayer.OnErrorListener onErrorListener;
    Surface surface;
    MediaPlayer mediaPlayer;
    CodecPlayer codecPlayer;

    class CodecPlayer {
        MediaExtractor videoExtractor;
        MediaExtractor audioExtractor;
        MediaFormat videoFormat;
        MediaFormat audioFormat;
        MediaCodec videoCodec;
        MediaCodec audioCodec;
        String[] trackInfo;
        boolean isPlaying;
        boolean isRunning;
        long seekTimeUs;
        boolean seekVideo;
        boolean seekAudio;
        int videoTrackIndex;
        int audioTrackIndex;
        long videoTimeUs;
        int duration;
        AudioTrack audioTrack;
        final long timeoutUs = 8000;
        final long syncRangeUs = 125000;

        void setDataSource(String video, String audio) throws Exception {
            videoExtractor = new MediaExtractor();
            videoExtractor.setDataSource(video);
            trackInfo = new String[2];
            prepareExtractor(videoExtractor);
            if (videoFormat == null) {
                StringBuilder sb = new StringBuilder();
                sb.append("no video track");
                for(int i = 0; i < videoExtractor.getTrackCount(); i++) {
                    sb.append(" " );
                    sb.append(videoExtractor.getTrackFormat(i));
                }
                videoExtractor.release();
                throw new Exception(sb.toString());
            }
            if (audio != null) {
                audioExtractor = new MediaExtractor();
                audioExtractor.setDataSource(audio);
                prepareExtractor(audioExtractor);
            }
            prepareCodecs();
        }

        void prepareExtractor(MediaExtractor extractor) {
            int count = extractor.getTrackCount();
            for(int i = 0; i < count; i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = getMimeType(format);
                if (mime.startsWith("video")) {
                    trackInfo[0] = mime;
                    videoTrackIndex = i;
                    videoFormat = format;
                    extractor.selectTrack(i);
                }
                if (mime.startsWith("audio")) {
                    trackInfo[1] = String.format("%s,%d,%d", mime,
                            format.getInteger(MediaFormat.KEY_SAMPLE_RATE),
                            format.getInteger(MediaFormat.KEY_CHANNEL_COUNT));
                    audioTrackIndex = i;
                    audioFormat = format;
                    extractor.selectTrack(i);
                }
            }
        }

        void prepareCodecs() throws Exception {
            videoCodec = createCodec(videoFormat);
            videoCodec.configure(videoFormat, surface, null, 0);
            videoCodec.start();
            if (audioFormat != null) {
                try {
                    audioCodec = createCodec(audioFormat);
                } catch (Exception e) {
                    audioCodec = null;
                }
                if (audioCodec != null) {
                    audioCodec.configure(audioFormat, null, null, 0);
                    audioCodec.start();
                    createAudioTrack();
                }
            }
        }

        void createAudioTrack()
        {
            int sampleRate = audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int channelCount = audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            int channels = AudioFormat.CHANNEL_OUT_STEREO;
            if (channelCount == 6) channels = AudioFormat.CHANNEL_OUT_5POINT1;
            else if (channelCount == 8) channels = AudioFormat.CHANNEL_OUT_7POINT1_SURROUND;
            else if (channelCount == 1) channels = AudioFormat.CHANNEL_OUT_MONO;
            int encoding = AudioFormat.ENCODING_PCM_16BIT;
            int minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channels, encoding);
            audioTrack = new AudioTrack(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                            .build(),
                    new AudioFormat.Builder()
                            .setEncoding(encoding)
                            .setSampleRate(sampleRate)
                            .setChannelMask(channels)
                            .build(),
                    minBufferSize, AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE);
        }

        void release() {
            while (seekVideo || seekAudio)
                sleep();
            isRunning = false;
        }

        void prepareAsync() {
            duration = (int)(videoFormat.getLong(MediaFormat.KEY_DURATION)/1000);
            if (onVideoSizeChangedListener != null){
                int width = videoFormat.getInteger(MediaFormat.KEY_WIDTH);
                int height = videoFormat.getInteger(MediaFormat.KEY_HEIGHT);
                onVideoSizeChangedListener.onVideoSizeChanged(null, width, height);
            }
            if (onPreparedListener != null)
                onPreparedListener.onPrepared(null);
            run();
        }

        void seekTo(long seekTime) {
            seekTimeUs = seekTime * 1000;
            seekVideo = true;
            if (audioCodec != null)
                seekAudio = true;
        }

        void start() {
            isPlaying = true;
            if (audioTrack != null)
                audioTrack.play();
        }

        void pause() {
            isPlaying = false;
            if (audioTrack != null)
                audioTrack.pause();
        }

        void reset() {
            release();
        }

        int getCurrentPosition() {
            return (int)(videoTimeUs /1000);
        }

        String[] getTrackInfo() {
            return trackInfo;
        }

        private String getMimeType(MediaFormat format) {
            return format.getString(MediaFormat.KEY_MIME);
        }

        private MediaCodec createCodec(MediaFormat format) throws Exception {
            return MediaCodec.createDecoderByType(getMimeType(format));
        }

        private boolean readSampleData(MediaExtractor extractor, MediaCodec codec) {
            boolean eos = false;
            if (codec == null)
            {
                try {
                    int index = extractor.getSampleTrackIndex();
                    do {
                        if (!extractor.advance()) {
                            eos = true;
                            break;
                        }
                    } while (index == extractor.getSampleTrackIndex());
                }
                catch (Exception e) {
                    eos = true;
                }
                return eos;
            }
            int index = codec.dequeueInputBuffer(timeoutUs);
            if (index >= 0) {
                ByteBuffer buffer = codec.getInputBuffer(index);
                int size = 0;
                long sampleTime = 0;
                try {
                    sampleTime = extractor.getSampleTime();
                    size = extractor.readSampleData(buffer, 0);
                    if (size > 0) {
                        if (!extractor.advance()) {
                            eos = true;
                        }
                    }
                    else {
                        size = 0;
                        eos = true;
                    }
                } catch (Exception e) {
                    eos = true;
                }
                codec.queueInputBuffer(index, 0, size, sampleTime,
                        eos ? MediaCodec.BUFFER_FLAG_END_OF_STREAM : 0);
            }
            return eos;
        }

        private void sleep() {
            SystemClock.sleep(8);
        }

        private void sleep(long us) {
            try {
                long millis = us/1000;
                int nanos =(int)(us % 1000)*1000;
                Thread.sleep(millis, nanos);
            } catch (Exception e){

            }
        }

        private void processVideo()
        {
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            videoTimeUs = videoExtractor.getSampleTime();
            long realTime= 0;
            long presentationTimeUs = realTime;
            boolean eos = false;
            while (isRunning) {
                if (seekVideo) {
                    videoCodec.flush();
                    videoExtractor.seekTo(seekTimeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                    videoTimeUs = videoExtractor.getSampleTime();
                    if (audioExtractor == null && onSeekCompleteListener != null)
                        onSeekCompleteListener.onSeekComplete(null);
                    seekVideo = false;
                }
                else if (isPlaying && !seekAudio) {
                    if (!eos) {
                        eos = readSampleData(videoExtractor, audioExtractor != null ||
                                videoExtractor.getSampleTrackIndex() == videoTrackIndex ?
                                    videoCodec : audioCodec);
                        if (audioCodec == null && eos) {
                            isPlaying = false;
                            if (onCompletionListener != null)
                                onCompletionListener.onCompletion(null);
                        }
                    }
                    int index = videoCodec.dequeueOutputBuffer(info, timeoutUs);
                    if (index >= 0) {
                        if (realTime == 0) {
                            realTime = SystemClock.elapsedRealtime();
                            presentationTimeUs = info.presentationTimeUs;
                        }
                        long dt = info.presentationTimeUs - presentationTimeUs -
                                (SystemClock.elapsedRealtime() - realTime) * 1000;
                        if (dt > syncRangeUs || dt < (-syncRangeUs))
                            realTime = 0;
                        else if (dt > 18500)
                            sleep(dt);
                        videoTimeUs = info.presentationTimeUs;
                        videoCodec.releaseOutputBuffer(index, true);
                        if((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0){
                            isPlaying = false;
                            if (onCompletionListener != null)
                                onCompletionListener.onCompletion(null);
                        }
                    }
                }
                else
                    sleep();
            }
            if (videoCodec != null) {
                videoCodec.stop();
                videoCodec.release();
                videoCodec = null;
            }
            if (videoExtractor != null) {
                videoExtractor.release();
                videoExtractor = null;
            }
        }

        private void processAudio()
        {
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean eos = audioExtractor == null;
            while (isRunning) {
                if (seekAudio) {
                    audioCodec.flush();
                    if (audioExtractor != null) {
                        audioExtractor.seekTo(seekTimeUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                        while (seekVideo)
                            sleep();
                        long audioTimeUs = audioExtractor.getSampleTime();
                        while (isRunning && !eos && audioTimeUs < videoTimeUs - syncRangeUs) {
                            eos = readSampleData(audioExtractor, audioCodec);
                            int index = audioCodec.dequeueOutputBuffer(info, timeoutUs);
                            if (index >= 0) {
                                audioTimeUs = info.presentationTimeUs;
                                audioCodec.releaseOutputBuffer(index, false);
                            }
                        }
                        if (onSeekCompleteListener != null)
                            onSeekCompleteListener.onSeekComplete(null);
                    }
                    seekAudio = false;
                }
                else if (isPlaying && !seekVideo) {
                    if (!eos) {
                        if (audioExtractor != null)
                            eos = readSampleData(audioExtractor, audioCodec);
                    }
                    int index = audioCodec.dequeueOutputBuffer(info, timeoutUs);
                    if (index >= 0) {
                        ByteBuffer buffer = audioCodec.getOutputBuffer(index);
                        audioTrack.write(buffer, info.size, AudioTrack.WRITE_BLOCKING);
                        audioCodec.releaseOutputBuffer(index, false);
                        if(audioExtractor == null && (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0){
                            isPlaying = false;
                            if (onCompletionListener != null)
                                onCompletionListener.onCompletion(null);
                        }
                    }
                }
                else
                    sleep();
            }
            if (audioCodec != null) {
                audioCodec.stop();
                audioCodec.release();
                audioCodec = null;
            }
            if (audioTrack != null) {
                audioTrack.pause();
                audioTrack.release();
                audioTrack = null;
            }
            if (audioExtractor != null) {
                audioExtractor.release();
                audioExtractor = null;
            }
        }

        private void run() {
            isRunning = true;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    processVideo();
                }
            }).start();
            if (audioTrack != null) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        processAudio();
                    }
                }).start();
            }
        }
    }

    void setOnPreparedListener(MediaPlayer.OnPreparedListener listener) {
        onPreparedListener = listener;
    }
    void setOnVideoSizeChangedListener(MediaPlayer.OnVideoSizeChangedListener listener) {
        onVideoSizeChangedListener = listener;
    }

    void setOnCompletionListener(MediaPlayer.OnCompletionListener listener) {
        onCompletionListener = listener;
    }

    void setOnSeekCompleteListener(MediaPlayer.OnSeekCompleteListener listener) {
        onSeekCompleteListener = listener;
    }

    void setOnErrorListener(MediaPlayer.OnErrorListener listener) {
        onErrorListener = listener;
    }

    void setSurface(Surface surface) {
        this.surface = surface;
    }

    void reset() {
        if (mediaPlayer != null)
            mediaPlayer.reset();
        else
            codecPlayer.reset();
    }

    void setDataSource(String video, String audio, boolean codec_player) throws Exception {
        if ((audio != null || codec_player ) && !video.endsWith("wmv") ) {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }
            codecPlayer = new CodecPlayer();
            codecPlayer.setDataSource(video, audio);
        }
        else {
            if (mediaPlayer == null) {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setOnPreparedListener(onPreparedListener);
                mediaPlayer.setOnVideoSizeChangedListener(onVideoSizeChangedListener);
                mediaPlayer.setOnCompletionListener(onCompletionListener);
                mediaPlayer.setOnSeekCompleteListener(onSeekCompleteListener);
                mediaPlayer.setOnErrorListener(onErrorListener);
                mediaPlayer.setSurface(surface);
            }
            mediaPlayer.setDataSource(video);
        }
    }

    void prepareAsync() {
        if (mediaPlayer != null)
            mediaPlayer.prepareAsync();
        else
            codecPlayer.prepareAsync();
    }

    void release() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (codecPlayer != null) {
            codecPlayer.release();
            codecPlayer = null;
        }
    }

    void selectTrack(int index) {
        if (mediaPlayer != null)
            mediaPlayer.selectTrack(index);
    }

    void seekTo(int seekTime) {
        if (mediaPlayer != null)
            mediaPlayer.seekTo(seekTime);
        else
            codecPlayer.seekTo(seekTime);
    }

    void pause() {
        if (mediaPlayer != null)
            mediaPlayer.pause();
        else
            codecPlayer.pause();
    }

    void start() {
        if (mediaPlayer != null)
            mediaPlayer.start();
        else
            codecPlayer.start();
    }

    Object[] getTrackInfo() {
        return mediaPlayer != null ? mediaPlayer.getTrackInfo() : codecPlayer.getTrackInfo();
    }

    boolean isPlaying() {
        return mediaPlayer != null ? mediaPlayer.isPlaying() : codecPlayer.isPlaying;
    }

    int getCurrentPosition() {
        return mediaPlayer != null ? mediaPlayer.getCurrentPosition() : codecPlayer.getCurrentPosition();
    }

    int getDuration() {
        return mediaPlayer != null ? mediaPlayer.getDuration(): codecPlayer.duration;
    }
}

package com.sp.browser;

import android.graphics.Canvas;

class WebBR extends WebText {

    WebBR(float size) {
        height = size;
        text = String.valueOf(C.newline);
    }

    @Override
    void select(float x1, float y1, float x2, float y2){
        if (y1 < rect.bottom && rect.bottom < y2) {
            sel1 = 0;
            sel2 = text.length();
        }
        else
            sel2 = sel1 = -1;
     }

    @Override
    void onDraw(Canvas canvas) {
    }

    @Override
    boolean wrap(float w, float h) {
        return true;
    }
}

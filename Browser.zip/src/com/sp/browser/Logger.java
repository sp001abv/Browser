package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.ArrayList;

class Logger {
    private static ArrayList<String> log = null;

    static void draw(Canvas canvas) {
        if (log != null && log.size() > 0) {
            Paint paint = new Paint();
            paint.setTextSize(S.text_size);
            paint.setColor(S.color_text);
            synchronized(log) {
                for(int i = 0; i < log.size(); i++) {
                    String t = log.get(i);
                    if (t.length()==0) continue;
                    canvas.drawText(t, 0, (int)((i+1)*paint.getTextSize()*1.1f), paint);
                }
            }
        }
    }

    static void clear() {
        if (log != null)
            log.clear();
    }

    static void log(String text, int index, boolean refresh) {
        if (log == null)
            log = new ArrayList<String>();
        synchronized(log) {
            if (index<0) {
                if (log.size() > 30) log.remove(0);
                log.add(text);
            } else {
                while(log.size()<=index) log.add(C.empty);
                log.set(index, text);
            }
        }
        if (refresh) {
            WebPage page = Pages.active();
            if (page != null)
                page.postInvalidate();
        }
    }

    static void log(String text) {
        log(text, -1, true);
    }
}

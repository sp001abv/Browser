package com.sp.browser;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.ArrayList;

class ExifInfo {
    Exif exif;
    RectF r = new RectF();
    float namesWidth;
    float valuesWidth;
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    ArrayList<String> names = new ArrayList<String>();
    ArrayList<String> values = new ArrayList<String>();
    ExifInfo(ImageDownloader media){
        paint.setTextSize(S.text_size);
        exif = media.exif;
        init();
    }
    void init(){
        if (exif == null || exif.tags == null)
            return;
        r.left = r.top = 0;
        names.clear();
        values.clear();
        namesWidth = valuesWidth = 0;
        for(int t : exif.tags) {
            String name = exif.getTagName(t);
            String value = exif.getTag(t).toString();
            float nameWidth = paint.measureText(name);
            float valueWidth = paint.measureText(value);
            if (namesWidth < nameWidth)
                namesWidth = nameWidth;
            if (valuesWidth < valueWidth)
                valuesWidth = valueWidth;
            names.add(name);
            values.add(value);
        }
        namesWidth += S.text_size / 2;
        valuesWidth += S.text_size / 2;
        r.right = namesWidth + valuesWidth;
        r.bottom = names.size() * S.text_size + S.text_size/2;
    }

    void onDraw(Canvas canvas, ImageDownloader media, RectF rect) {
        if (media == null)
            return;
        if (exif != media.exif) {
            exif = media.exif;
            init();
        }
        if (exif == null || exif.tags == null)
            return;
        r.offsetTo(rect.left, rect.bottom);
        paint.setColor(S.color_background);
        canvas.drawRect(r, paint);
        float y = r.top + S.text_size;
        float x = r.left + 2;
        paint.setColor(S.color_text);
        for(int i = 0; i< names.size(); i++) {
            canvas.drawText(names.get(i), x, y, paint);
            canvas.drawText(values.get(i), x+namesWidth, y, paint);
            y += S.text_size;
        }
    }

    void next() {
        exif.idfIndex++;
        if (exif.idfIndex >= exif.idfs.size()){
            exif.idfIndex = 0;
            exif.exifIndex++;
            if (exif.exifIndex >= exif.exifs.size())
                exif.exifIndex = 0;
            exif.readIDFs();
        }
        exif.readTags();
        init();
    }

    public String getIndexes() {
        return String.format(" ► %d/%d %d/%d",
                exif.exifIndex+1, exif.exifs.size(),
                exif.idfIndex+1, exif.idfs.size());
    }
}

package com.sp.browser;

import android.os.SystemClock;

class DisqusView {
    DisqusThread disqusThread;
    GLBitmapTextureRenderer renderer;
    boolean update;
    long updateInterval;
    long updateTime;
    int updateCount;
    boolean updating;
    int width;
    int height;
    float top;
    DisqusView(String url, int w, int h) {
        width = w;
        height = h;
        updateCount++;
        updating = true;
        disqusThread = new DisqusThread(url);
        disqusThread.maxWidth = w;
        updateTime = SystemClock.elapsedRealtime();
        toggle();
    }
    void toggle(){
        updateInterval = updateInterval == 0 ? 10000 : 0;
        top = 0;
        if (updateInterval > 0)
            update = true;
    }

    void onDrawFrame(VideoSurfaceView videoView) {
        if (updateInterval > 0) {
            if (renderer == null) {
                renderer = videoView.createBitmapRenderer(width, height, true);
            }
            long elapsedTime = SystemClock.elapsedRealtime();
            if (!updating && elapsedTime-updateTime>updateInterval) {
                updateTime = elapsedTime;
                updateCount++;
                updating = true;
                disqusThread.update();
            }
            if (update && !updating) {
                disqusThread.move(0, top, width, height);
                disqusThread.onDraw(renderer.getCanvas(0, 0, videoView.getWidth(), videoView.getHeight()));
                update = false;
            }
            if (updating && updateCount == disqusThread.updateCount) {
                updating = false;
                update = true;
            }
            renderer.render();
        }
    }

    void onOffset(float dy) {
        top += dy;
        if (top > 0) top = 0;
        update = true;
    }
}

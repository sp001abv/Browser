package com.sp.browser;

class Finding {
    Finding(WebItem item, int index, float position) {
        this.item = item;
        this.index = index;
        this.position = position;
    }
    WebItem item;
    int index;
    float position;
}

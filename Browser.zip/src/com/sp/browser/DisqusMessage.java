package com.sp.browser;

class DisqusMessage extends WebDiv
{
    int depth = 0;
    @Override
    boolean wrap(float w, float h) {
        super.wrap(w-depth, h);
        height += S.text_size/2;
        return true;
    }

    @Override
    void move(float left, float top, float right, float bottom) {
        super.move(left+depth, top, right+depth, bottom);
    }
}

package com.sp.coder;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

class ActionEdit extends Action implements ITextEditor {
    TextEdit edit = new TextEdit();

    @Override
    public boolean startEditing(float x, float y) {
       return edit.startEditing(x, y);
    }

    @Override
    public boolean onEnter() {
        return edit.onEnter();
    }

    @Override
    public boolean onTab(boolean shift) { return false; }

    @Override
    public boolean onLeft(boolean shift, boolean home) {
        return edit.onLeft(shift, home);
    }

    @Override
    public boolean onRight(boolean shift, boolean end) {
        return edit.onRight(shift, end);
    }

    @Override
    public boolean onUp(boolean shift, boolean page) {
        return edit.onUp(shift, page);
    }

    @Override
    public boolean onDown(boolean shift, boolean page) {
        return edit.onDown(shift, page);
    }

    @Override
    public boolean del() {
        return edit.del();
    }

    @Override
    public boolean paste(String text) {
        return edit.paste(text);
    }

    @Override
    public void save() {
        edit.save();
    }

    @Override
    public void copy(StringBuilder builder) {
        edit.copy(builder);
    }

    @Override
    public boolean undo() { return edit.undo(); }

    @Override
    public void stopEditing() {
        edit.stopEditing();
    }

    @Override
    int getColor() {
        return edit.editing ? S.color_visited : S.color_link;
    }

    @Override
    void onDraw(Canvas canvas, float left, float bottom, float right, Paint paint) {
        edit.move(left, bottom - paint.getTextSize(), right, bottom);
        super.onDraw(canvas, left, bottom, right, paint);
        if (edit.editing) {
            edit.onDraw(canvas);
        }
    }

    @Override
    void onClick(float x, float y){
        //edit.onClick(x, y);
    }

}

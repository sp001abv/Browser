package com.sp.coder;

import android.graphics.Canvas;
import android.graphics.Paint;

class Action {
    String getName() { return null; }
    int getColor(){ return S.color_link; }
    void onClick(float x, float y){}
    void onDraw(Canvas canvas, float left, float bottom, float right, Paint paint) {
        paint.setColor(getColor());
        canvas.drawText(getName(), left, bottom, paint);
    }
}

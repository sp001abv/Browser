package com.sp.coder;

import android.graphics.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;

class S {
    static int color_link = Color.rgb(0, 170, 215);
    static int color_text = Color.rgb(170, 170, 170);
    static int color_visited = Color.rgb(0, 100, 200);
    static int color_selected = Color.rgb(100, 0, 100);
    static int color_background = Color.BLACK;
    static int text_size = 18;

    static boolean full_screen = false;
    static float default_scale = 3.0f;
    static float fling_threshold = 1000;
    static float fling_to_scroll = 400;
    static float scroll_attenuation = 0.5f;
    static int gps_update_interval = 1000;
    static int gps_update_distance = 10;
    static float pointer_dx = 0.0f;
    static float pointer_dy = 0.0f;

    static Logger logger = new Logger();
    static Explorer explorer = new Explorer();
    static FindActions find = new FindActions();
    static Sources sources = new Sources();

    static String readString(FileInputStream is) throws IOException {
        int n = is.read();
        byte[] b = new byte[n]; is.read(b);
        return new String(b);
    }

    static void writeString(FileOutputStream os, String s) throws IOException {
        os.write(s.length());
        os.write(s.getBytes());
    }

    static void writeDouble(FileOutputStream os,double value) throws IOException {
        byte[] bytes = new byte[8];
        ByteBuffer.wrap(bytes).putDouble(value);
        os.write(bytes);
    }

    static double readDouble(FileInputStream is) throws IOException {
        byte[] bytes = new byte[8];
        is.read(bytes);
        return ByteBuffer.wrap(bytes).getDouble();
    }

    static boolean isExt(String url, String ext) {  return url.startsWith(ext);  }

    static String getExt(String url) {
        int i;
        i =	url.lastIndexOf(C.dot)+1;
        return i > 0 ? url.substring(i) : null;
    }

    static String removeExt(String url) {
        int i = url.lastIndexOf(C.dot);
        return i > 0 ? url.substring(0, i) : url;
    }

    static boolean isDigit(char c){
        return Character.isDigit(c) || c==C.dot || c == '-';
    }

    static float getFileSize(File f) {
        float size = f.length();
        if (f.isDirectory()) {
            File files[] = f.listFiles();
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    size += getFileSize(files[i]);
                }
            }
        }
        return size;
    }

    static String getFolderName(String url) {
        return url.substring(url.lastIndexOf(C.slash, url.length()-2)+1, url.length()-1);
    }

    static String getFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash)+1);
    }

    static String getParentFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash, url.length()-2)+1);
    }

    static void loadLocalFilesSorted(ArrayList<String> locals, String path, boolean directory) {
        File folder = new File(path);
        File files[] = folder.listFiles();
        if (files != null) {
            for (File f : files) {
                if ((directory && f.isDirectory()) ||
                        (!directory && f.isFile())) {
                    String fileName = f.getName();
                    addSorted(locals, fileName);
                }
            }
        }
    }

    static void addSorted(ArrayList<String> sorted, String s) {
        for (int i = 0; i < sorted.size(); i++) {
            String s1 = sorted.get(i);
            if (s.compareToIgnoreCase(s1) < 0) {
                sorted.set(i, s);
                s = s1;
                i--;
            }
        }
        sorted.add(s);
    }

    static String getFileName(String url) {
        int i;
        i = url.lastIndexOf(C.slash);
        if (i > 0)
            url = url.substring(i+1);
        return url;
    }


}

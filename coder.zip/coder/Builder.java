package com.sp.coder;

import android.graphics.Canvas;

class Builder extends Text {

    void log(String text, int index) {
        if (index<0) {
            lines.add(text);
        } else {
            while(lines.size()<=index)
                lines.add(C.empty);
            lines.set(index, text);
        }
    }

    void log(String text) {
        log(text, -1);
    }

    void log(Exception e) {
        log(e.getMessage());
        StackTraceElement[] stack = e.getStackTrace();
        for(int i = 0; i < 5 && i < stack.length; i++)
            log(stack[i].toString());
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float x = rect.left - paint.getTextSize() / 4;
        canvas.drawLine(x, rect.top, rect.right, rect.top, paint);
    }

    @Override
    public void onClick(float x, float y) {

    }
}

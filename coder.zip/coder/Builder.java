package com.sp.coder;

import android.graphics.Canvas;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class Builder extends Text {

    void log(String text, int index) {
        synchronized (lines) {
            if (index<0) {
                lines.add(text);
            } else {
                while(lines.size()<=index)
                    lines.add(C.empty);
                lines.set(index, text);
            }
        }
    }

    void log(String text) {
        log(text, -1);
    }

    void log(Exception e) {
        log(e.getMessage());
        StackTraceElement[] stack = e.getStackTrace();
        for(int i = 0; i < 5 && i < stack.length; i++)
            log(stack[i].toString());
    }

    void build(MainLayout main) {
        String path = S.explorer.path;
        int i = path.lastIndexOf("/src/");
        if (i > 0) path = path.substring(0, i);
        synchronized (lines) {
            clear();
        }
        //if (!execute(S.build_resources, path))
        //    return;
        log("compiling ...");
        main.postInvalidate();
        if (execute(S.compile_java_classes, path)) {
            main.postInvalidate();
            return;
        }
        main.postInvalidate();
        log("dexing ...");
        main.postInvalidate();
        if (!execute(S.dex_java_classes, path)) {
            main.postInvalidate();
            return;
        }
        main.postInvalidate();
        log("packing ...");
        main.postInvalidate();
        if (!execute(S.pack_apk, path))
            return;
        main.postInvalidate();
        S.builder.log("signing ...");
        if (!S.builder.execute(S.sign_apk, path)) {
            main.postInvalidate();
            return;
        }
        S.builder.log("done!");
        main.postInvalidate();
    }

    boolean execute(String command, String path) {
        try {
            String[] args = new String[2];
            args[0] = S.sdk + command;
            args[1] = path;
            BufferedReader reader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(args).getErrorStream()));
            String line;
            while ((line = reader.readLine()) != null)
                log(line);
            reader.close();
        }
        catch (Exception e) {
            log(e);
            return  false;
        }
        return true;
    }

    @Override
    public void onDraw(Canvas canvas) {
        synchronized (lines) {
            super.onDraw(canvas);
        }
        float x = rect.left - paint.getTextSize() / 4;
        canvas.drawLine(x, rect.top, rect.right, rect.top, paint);
    }

    @Override
    public void onClick(float x, float y) {

    }
}

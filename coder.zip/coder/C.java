package com.sp.coder;

final class C {
    static final char open_square_bracket = '[';
    static final char close_square_bracket = ']';
    static final char open_brace = '{';
    static final char close_brace = '}';
    static final char open = '<';
    static final char close = '>';
    static final char space = ' ';
    static final char slash = '/';
    static final char backslash = '\\';
    static final char comma = ',';
    static final char dot = '.';
    static final char equals = '=';
    static final char dash = '-';
    static final char column = ':';
    static final char semi_column = ';';
    static final char quote = '"';
    static final char times = '×';
    static final char newline = '\n';
    static final char tab = '\t';
    static final String empty = "";
    static final String utf8 = "utf-8";
    static final float scale_step_2 = (float)(Math.sqrt(2));
    static final float scale_step_4 = (float)(Math.sqrt(Math.sqrt(2)));
    static final float scale_step_8 = (float)(Math.sqrt(Math.sqrt(Math.sqrt(2))));
    static final float scale_step_16 = (float)(Math.sqrt(Math.sqrt(Math.sqrt(Math.sqrt(2)))));
    static final float scale_step_32 = (float)(Math.sqrt(Math.sqrt(Math.sqrt(Math.sqrt(Math.sqrt(2))))));
    static final String saved_as = "saved as ";

}

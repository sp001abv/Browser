package com.sp.coder;

import android.graphics.Canvas;

class TextEdit extends Text implements ITextEditor {
    boolean editing;

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (editing)
            drawCursor(canvas);
    }

    @Override
    public boolean startEditing(float x, float y) {
        if (editing)
            return false;
        editing = true;
        if (sel1 < 0 || sel1 == sel2) {
            sel1 = sel2 = getCursor(x, y);
        }
        if (sel1 < 0) {
            int line = lines.size()-1;
            int index = lines.get(line).length();
            sel1 = sel2 = getCursor(line, index);
        }
        return true;
    }

    @Override
    public void stopEditing() {
        editing = false;
    }

    @Override
    public boolean onEnter() {
        return lines.size() == 1;
    }

    @Override
    public boolean onTab(boolean shift) {
        /*
        if (sel1 != sel2) return false;
        int i = text.lastIndexOf(C.newline, sel1) + 1;
        if (i > 0) {
            sel2 = i;
            int len = text.length();
            while (sel2 < len && text.charAt(sel2) == C.space)
                sel2++;
            if (shift) {
                if (sel2 > i) {
                    int index = sel1;
                    sel1 = i;
                    if (sel2 > i + 4)
                        sel2 = i + 4;
                    del();
                    index -= 4;
                    if (index < i)
                        index = i;
                    sel1 = sel2 = index;
                    return true;
                }
                sel2 = sel1;
            }
            else {
                int index = sel1;
                sel1 = sel2;
                paste("    ");
                sel1 = sel2 = index + 4;
                return true;
            }
        }
        */
        return false;
    }

    int prev(int cursor) {
        int line = getLine(cursor);
        int index = getIndex(cursor);
        if (index > 0) {
            cursor = getCursor(line, --index);
        } else if (line > 0){
            line--;
            index = lines.get(line).length();
            cursor = getCursor(line, index);
        }
        return cursor;
    }

    int next(int cursor) {
        int line = getLine(cursor);
        int index = getIndex(cursor);
        if (index < lines.get(line).length())
            cursor = getCursor(line, ++index);
        else if (line < lines.size()-1)
            cursor = getCursor(++line, 0);
        return cursor;
    }

    @Override
    public boolean onLeft(boolean shift, boolean home) {
        if (sel1 > 0) {
            if (home)
                sel1 = getCursor(getLine(sel1), 0 );
            else
                sel1 = prev(sel1);

            if (!shift)
                sel2 = sel1;
            return true;
        }
        return false;
    }

    @Override
    public boolean onRight(boolean shift, boolean end) {
        int line = getLine(sel1);
        int index = getIndex(sel1);
        if (line < lines.size()-1 || index < lines.get(line).length()) {
            if (end)
                sel1 = getCursor(line, lines.get(line).length());
            else
                sel1 = next(sel1);

            if (!shift)
                sel2 = sel1;
            return true;
        }
        return false;
    }

    @Override
    public boolean onUp(boolean shift, boolean page) {
        if (sel1 > 0) {
            int line = getLine(sel1);
            if (line > 0) {
                int index = getIndex(sel1);
                float x = index > 0 ? getTextWidth(lines.get(line), index) : 0;
                if (page) {

                    line-= rect.height() / paint.getTextSize() / 2;
                    if (line<0) line = 0;
                } else line--;
                sel1 = getCursor(line, getIndex(lines.get(line), x));
                if (!shift)
                    sel2 = sel1;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean onDown(boolean shift, boolean page) {
        if (sel1 >= 0) {
            int line = getLine(sel1);
            if (line >= 0 && line < lines.size()-1) {
                int index = getIndex(sel1);
                float x = index > 0 ? getTextWidth(lines.get(line), index) : 0;
                if (page) {
                    line+= rect.height() /paint.getTextSize() / 2;
                    if (line >= lines.size()) line = lines.size()-1;
                } else line++;
                sel1 = getCursor(line, getIndex(lines.get(line), x));
                if (!shift)
                    sel2 = sel1;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean del(){
        if (sel1 >=0 && sel2 > 0) {
            int s1 = sel2 > sel1 ? sel1 : sel2;
            int s2 = sel2 > sel1 ? sel2 : sel1;
            int l1 = getLine(s1);
            int l2 = getLine(s2);
            int i1 = getIndex(s1);
            int i2 = getIndex(s2);
            if (l1 == l2) {
                String line = lines.get(l1);
                if (line.length() == 0) {
                    if (l1 > 0) {
                        sel2 = sel1 = prev(sel1);
                        lines.remove(l1);
                    }
                    else
                        return false;
                }
                else if (i1 == 0 && i2 == line.length()) {
                    lines.set(l1, C.empty);
                    sel2 = sel1 = s1;
                }
                else if (i2 == line.length()) {
                    if (i1 != i2) {
                        line = line.substring(0, i1);
                        lines.set(l1, line);
                        sel2 = sel1 = s1;
                    }
                    else {
                        line = line.substring(0, --i1);
                        lines.set(l1, line);
                        sel2 = sel1 = getCursor(l1, i1);
                    }
                }
                else if (i1 == 0) {
                    if (i2 != i1) {
                        line = line.substring(i2);
                        lines.set(l1, line);
                        sel2 = sel1 = s1;
                    }
                    else {
                        if (l1 > 0) {
                            lines.remove(l1--);
                            sel2 = sel1 = getCursor(l1, lines.get(l1).length());
                            lines.set(l1, lines.get(l1) + line);
                        }
                        else
                            return false;
                    }
                }
                else if (i1 != i2) {
                    line = line.substring(0, i1) + line.substring(i2);
                    lines.set(l1, line);
                    sel2 = sel1 = s1;
                }
                else {
                    line = line.substring(0, --i1) + line.substring(i2);
                    lines.set(l1, line);
                    sel2 = sel1 = getCursor(l1, i1);
                }
            }
            else {
                for(int i = l1 + 1; i < l2; l2--)
                    lines.remove(i);
                String line1 = lines.get(l1);
                String line2 = lines.get(l2);
                if (i1 == 0 && i2 == line2.length())
                    lines.set(l1, C.empty);
                else if (i2 == line2.length())
                    lines.set(l1, line1.substring(0,i1));
                else if (i2 == 0)
                    lines.set(l1, line2);
                else
                    lines.set(l1, line1.substring(0, i1) + line2.substring(i2));
                lines.remove(l2);
                sel2 = sel1 = s1;
            }
            return true;
        }
        return false;
    }

    @Override
    public void save() {}

    @Override
    public void copy(StringBuilder builder) {
        super.copy(builder);
    }

    @Override
    public boolean undo() {
        return false;
    }

    int addLine(int line, String s) {
        if (++line < lines.size())
            lines.add(line, s);
        else
            lines.add(s);
        return getCursor(line, 0);
    }

    void paste(char c) {
        if (c == C.newline) {
            int line = getLine(sel1);
            int index = getIndex(sel1);
            String text = lines.get(line);
            if (index < text.length()) {
                lines.set(line, text.substring(0, index));
                text = text.substring(index);
            }
            else text = C.empty;
            sel2 = sel1 = addLine(line, text);
        }
        else {
            int line = getLine(sel1);
            int index = getIndex(sel1);
            String l = lines.get(line);
            if (index == 0)
                l = c + l;
            else  if (index == l.length())
                l += c;
            else
                l = l.substring(0, index) + c + l.substring(index);
            lines.set(line, l);
            sel2 = sel1 = getCursor(line, ++index);
        }
    }

    @Override
    public boolean paste(String chars) {
        if (sel1 != sel2)
            del();
        for (int i = 0; i < chars.length(); i++)
            paste(chars.charAt(i));
        return true;
    }

    void drawCursor(Canvas canvas){
        int line = getLine(sel1);
        int index = getIndex(sel1);
        float x = rect.left + getTextWidth(lines.get(line), index);
        float y = rect.top + scroll + paint.getTextSize() * 0.15f;
        if (line > 0) y += line * paint.getTextSize();
        if (y < rect.bottom) {
            int color = paint.getColor();
            paint.setColor(S.color_cursor);
            canvas.drawLine(x, y, x, y + paint.getTextSize(), paint);
            paint.setColor(color);
        }
    }
}

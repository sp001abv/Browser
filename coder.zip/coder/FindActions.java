package com.sp.coder;

class FindActions extends Actions {
    class FindAction extends ActionEdit {
        @Override
        String getName() {
            return String.format("%s %d/%d\t%s", edit.toString(), count > 0 ? index+1 : 0, count, match ? "Aa" : "A");
        }

        @Override
        void onClick(float x, float y){
            String name = getName(); 
           if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.tab)))) {
                match = ! match;
                find(0);
                return;
            }
            else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.slash)))) {
                find(1);
                return;
            }
            else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.space)))) {
                find(-1);
                return;
            }
            if (x < rect.left + paint.getTextSize()) {
                edit.clear();
                resize();
            }
            super.onClick(x, y);
        }

        @Override
        public boolean onUp(boolean shift, boolean page) {
            find(-1);
            return true;
        }

        @Override
        public boolean onDown(boolean shift, boolean page) {
            find(1);
            return true;
         }

        @Override
        public boolean del() {
            if (super.del()) {
                find(0);
                resize();
                return true;
            }
            return false;
        }

        @Override
        public boolean paste(String t) {
            if (super.paste(t)) {
                find(0);
                resize();
            }
            return false;
        }

        @Override
        public boolean startEditing(float x, float y) {
            String text =edit.toString();
            if (text.length() > 0 && x > rect.left + paint.measureText(text))
                return false;
            return super.startEditing(x, y);
        }

        @Override
        public void stopEditing() {
            super.stopEditing();
            find(0);
        }

    }

    class ReplaceAction extends ActionEdit {
        @Override
        String getName() {
            return String.format("%s R/A", edit.toString(), count > 0 ? index+1 : 0, count);
        }

        @Override
        void onClick(float x, float y){
            String name = getName();
            if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.slash)))) {
                replace(true);
                return;
            }
            else if (x > rect.left + paint.measureText(name.substring(0, name.lastIndexOf(C.space)))) {
                replace(false);
                return;
            }
            if (x < rect.left + paint.getTextSize()) {
                edit.clear();
                resize();
            }
            super.onClick(x, y);
        }

        @Override
        public boolean onUp(boolean shift, boolean page) {
            if (shift)
                replace(true);
            else
                find(-1);
            return true;
        }

        @Override
        public boolean onDown(boolean shift, boolean page) {
            if (shift)
                replace(false);
            else
                find(1);
            return true;
         }

        @Override
        public boolean del() {
            if (super.del()) {
                resize();
                return true;
            }
            return false;
        }

        @Override
        public boolean paste(String t) {
            super.paste(t);
            resize();
            return false;
        }

        @Override
        public boolean startEditing(float x, float y) {
            String text = edit.toString();
            if (text.length() > 0 && x > rect.left + paint.measureText(text))
                return false;
            return super.startEditing(x, y);
        }

        @Override
        public void stopEditing() {
            super.stopEditing();
        }

    }

    class FindCloseAction extends Action{
        @Override
        String getName() { return "close"; }

        @Override
        void onClick(float x, float y){
            close();
        }
    }

    FindAction findAction;
    ReplaceAction replaceAction;
    int index = 0;
    int count = 0;
    boolean match = false;

    FindActions() {
        findAction = new FindAction();
        replaceAction = new ReplaceAction();
        items.add(findAction);
        items.add(replaceAction);
        items.add(new FindCloseAction());
    }

    void close() {
        if (!findAction.edit.editing)
            super.onBack();
    }

    void find(int next){
        String text = findAction.edit.toString();
        if (text.length() > 0) {
            if (next == 0) {
                index = 0;
                count = S.sources.find(findAction.edit.toString(), match);
            }
            if (count > 0) {
                index += next;
                if (index >= count) index = 0;
                if (index < 0) index = count - 1;
                S.sources.select(index, true);
            }
            else index = 0;
        }
        resize();
    }

    void replace(boolean all) {
        String text = replaceAction.edit.toString();
        if (text.length() > 0) {
            while (count > 0 && index < count) {
                if (S.sources.replace(index, text)) {
                    String find = findAction.edit.toString();
                    count = S.sources.find(find, match);
                    if (text.contains(find)) index++;
                }    
                else index++;
                if (index < count)
                    S.sources.select(index, !all);
                if (!all) break;
            }
        }
                
        resize();
    }

    @Override
    void show(float x, float y){
        if (replaceAction.edit.toString().length() == 0) {
            replaceAction.edit.setText(findAction.edit.toString());
        }
        if (paint == null) init();
        find(0);
        super.show(x, y);
    }

    @Override
    boolean closeOnClick(){
        return false;
    }
    @Override
    boolean onBack(){
        return false;
    }
}

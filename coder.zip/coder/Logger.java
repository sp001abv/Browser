package com.sp.coder;

class Logger extends Text {

    void log(String text, int index) {
        synchronized(lines) {
            if (index<0) {
                lines.add(text);
            } else {
                while(lines.size()<=index) lines.add(C.empty);
                lines.set(index, text);
            }
        }
    }

    void log(String text) {
        log(text, -1);
    }

    @Override
    public void onClick(float x, float y) {

    }
}

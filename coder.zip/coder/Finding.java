package com.sp.coder;

class Finding {
    Finding(Text item, int cursor1, int cursor2) {
        this.item = item;
        this.cursor1 = cursor1;
        this.cursor2 = cursor2;
    }
    Text item;
    int cursor1;
    int cursor2;
}

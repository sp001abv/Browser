package com.sp.coder;

import android.graphics.Canvas;
import android.graphics.RectF;

import java.util.ArrayList;

class Sources implements IView, ITextSelection, ITextEditor {
    private ArrayList<Finding> findings = new ArrayList<Finding>();
    private ArrayList<TextEdit> sources = new ArrayList<TextEdit>();
    private TextEdit active = null;
    private RectF rect = new RectF();

    Sources() {
        active = new TextEdit();
        active.setText("this is some text\nline2");
    }

    public int find(String text, boolean match)
    {
        findings.clear();
        find(text, findings, match);
        return findings.size();
    }

    public void select(int index, boolean show)
    {
        Finding finding = findings.get(index);
        select(finding, show);
    }

    public boolean replace(int index, String replacement)
    {
        Finding finding = findings.get(index);
        if (finding.item instanceof ITextEditor && ((ITextEditor)finding.item).paste(replacement)) {
            return  true;
        }
        return false;
    }

    @Override
    public boolean startEditing(float x, float y) {
        return active.startEditing(x, y);
    }

    @Override
    public boolean onEnter() {
        return false;
    }

    @Override
    public boolean onTab(boolean shift) {
        return active.onTab(shift);
    }

    @Override
    public boolean onLeft(boolean shift, boolean home) {
        return active.onLeft(shift, home);
    }

    @Override
    public boolean onRight(boolean shift, boolean end) {
        return active.onRight(shift, end);
    }

    @Override
    public boolean onUp(boolean shift, boolean page) {
        return active.onUp(shift, page);
    }

    @Override
    public boolean onDown(boolean shift, boolean page) {
        return active.onDown(shift, page);
    }

    @Override
    public boolean del() {
        return active.del();
    }

    @Override
    public boolean paste(String text) {
        return active.paste(text);
    }

    @Override
    public void save() {
        active.save();
    }

    @Override
    public boolean undo() {
        return active.undo();
    }


    @Override
    public void stopEditing() {
        active.stopEditing();
    }

    @Override
    public void find(String s, ArrayList<Finding> findings, boolean match) {
        if (!match)
            s = s.toLowerCase();
        for(int i=0; i<sources.size(); i++)
            sources.get(i).find(s, findings, match);
    }

    @Override
    public void select(float x1, float y1, float x2, float y2) {
        active.select(x1, y1, x2, y2);
    }

    @Override
    public void select(Finding finding, boolean show) {
        if (active != finding.item)
            active = (TextEdit)finding.item;
        finding.item.select(finding, show);
    }

    @Override
    public void deselect() {
        for(int i=0; i<sources.size(); i++)
            sources.get(i).deselect();
    }

    @Override
    public void copy(StringBuilder builder) {
        for(int i=0; i<sources.size(); i++)
            sources.get(i).copy(builder);
    }

    @Override
    public void onClick(float x, float y) {
        active.onClick(x, y);
    }

    @Override
    public void onDraw(Canvas canvas) {
        active.onDraw(canvas);
    }

    @Override
    public boolean onScroll(float x, float y, float factor) {
        return active.onScroll(x, y, factor);
    }

    @Override
    public void move(float left, float top, float right, float bottom) {
        rect.set(left, top, right, bottom);
        active.move(left, top, right, bottom);
    }

    @Override
    public boolean contains(float x, float y) {
        return rect.contains(x, y);
    }
}

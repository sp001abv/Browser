package com.sp.coder;

import java.io.FileReader;
import java.io.FileWriter;

class Source extends TextEdit {
    boolean edited;
    String path;

    Source(String path) {
        this.path = path;
        load();
    }

    @Override
    public boolean del() {
        edited = true;
        return super.del();
    }

    @Override
    public boolean onEnter() {
        return false;
    }

    @Override
    public boolean paste(String chars) {
        edited = true;
        return super.paste(chars);
    }

    @Override
    public boolean undo() {
        if (edited) {
            return load();
        }
        return false;
    }

    @Override
    public void save() {
        try {
            FileWriter output = new FileWriter(path);
            output.write(toString());
            output.close();
            edited = false;
            S.logger.log(C.saved_as + path);
        }
        catch (Exception e) {
            S.logger.log(e.getMessage());
        }
    }

    boolean load() {
        try {
            FileReader reader = new FileReader(path);
            char[] buffer = new char[4096];
            int begin = 0;
            String s = C.empty;
            int len, count;
            while ((len = reader.read(buffer))>0){
                for (int i = 0; i < len ; i++) {
                    char c = buffer[i];
                    if (c == C.newline) {
                        int j = i-1;
                        while (j >= begin) {
                            c = buffer[j];
                            if (!(c == 0 || c == C.cr || c == C.space))
                                break;
                            j--;
                        }
                        j++;
                        count = j - begin;
                        if (count > 0)
                            s += new String(buffer, begin, count);
                        lines.add(s);
                        begin = i + 1;
                        s = C.empty;
                    }
                }
                count = len - begin;
                if (count > 0)
                    s = new String(buffer, begin, count);
                begin = 0;
            }
            if (s.length() > 0)
                lines.add(s);
            reader.close();
            edited = false;
            return true;
        }
        catch (Exception e) {
            S.logger.log(e.getMessage());
        }
        return false;
    }
}

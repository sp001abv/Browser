package com.sp.coder;

import java.util.ArrayList;

interface ITextSelection {
    void find(String s, ArrayList<Finding> findings, boolean match);
    void select(float x1, float y1, float x2, float y2);
    void select(Finding finding, boolean show);
    void deselect();
    void copy(StringBuilder builder);
}

package com.sp.coder;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.GestureDetector;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;

class MainLayout extends LinearLayout
{
    GestureDetector gestureDetector;
    GestureDetector gestureDetector2;
    ITextEditor focusedItem;
    float pan_dX = 0;
    float pan_dY = 0;
    float scroll_velx = 0;
    float scroll_vely = 0;
    boolean double_tap = false;
    boolean scaling = false;
    float pointer_x;
    float pointer_y;
    boolean pan_select = false;
    boolean pan_scroll = false;
    float ev_x1 = 0;
    float ev_y1 = 0;

    MainLayout(Context context) {
        super(context);
        setBackgroundColor(S.color_background);

        GestureDetector.OnGestureListener gestureListener = new GestureDetector.OnGestureListener(){
            @Override
            public boolean onDown(MotionEvent p1){
                scroll_velx = scroll_vely = 0;
                scaling = double_tap = false;
                return false;
            }

            @Override
            public void onShowPress(MotionEvent p1){
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e){
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                Actions aa = Actions.active;
                float x1 = e1.getX() + S.pointer_dx;
                float y1 = e1.getY() + S.pointer_dy;
                float x2 = e2.getX() + S.pointer_dx;
                float y2 = e2.getY() + S.pointer_dy;
                if (aa != null && aa.onScroll(x1, y1, x2, y2, distanceX, distanceY))
                    postInvalidate();
                else {
                    if (!double_tap && !scaling) {
                        pan(x1, y1, x2, y2, distanceX, distanceY);
                    }
                }
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e){
                if (Actions.active == null){
                    S.find.show(e.getX(), e.getY());
                    postInvalidate();
                }
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velX, float velY){
                if ((Math.abs(velY) > S.fling_threshold || Math.abs(velX) > S.fling_threshold)){
                    ev_x1 = e1.getX();
                    ev_y1 = e1.getY();
                    scroll_velx = velX/S.fling_to_scroll;
                    scroll_vely = velY/S.fling_to_scroll;
                    postInvalidate();
                    return true;
                }
                return false;
            }
        };
        GestureDetector.SimpleOnGestureListener gestureListener2 = new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                onClick(e.getX()+ S.pointer_dx, e.getY()+ S.pointer_dy);
                return true;
            }
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                double_tap = true;
                return true;
            }
        };
        gestureDetector = new GestureDetector(getContext(), gestureListener);
        gestureDetector2 = new GestureDetector(getContext(), gestureListener2);
    }

    String getClipboardText() {
        ClipboardManager clipboard = (ClipboardManager)getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount()>0) {
            ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
            if (item.getText().length() > 0)
                return String.valueOf(item.getText());
        }
        return null;
    }

    void setClipboardText(String text) {
        ClipboardManager clipboard = (ClipboardManager)getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText(C.empty, text != null ? text : C.empty));
    }


    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        try {
            return onKeyEvent(event);
        }
        catch (Exception e) {
            S.builder.log(e);
        }
        return false;
    }

    boolean onKeyEvent(KeyEvent event) {
        if (focusedItem != null)
        {
            int keyCode = event.getKeyCode();
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                switch (keyCode) {
                    case KeyEvent.KEYCODE_DEL:
                        focusedItem.del();
                        postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_DPAD_LEFT:
                        if (focusedItem.onLeft(event.isShiftPressed(), false))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_DPAD_RIGHT:
                        if (focusedItem.onRight(event.isShiftPressed(), false))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_DPAD_UP:
                        if  (focusedItem.onUp(event.isShiftPressed(), false))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_DPAD_DOWN:
                        if (focusedItem.onDown(event.isShiftPressed(), false))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_MOVE_HOME:
                        if (focusedItem.onLeft(event.isShiftPressed(), true))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_MOVE_END:
                        if (focusedItem.onRight(event.isShiftPressed(), true))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_PAGE_UP:
                        if (focusedItem.onUp(event.isShiftPressed(), true))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_PAGE_DOWN:
                        if (focusedItem.onDown(event.isShiftPressed(), true))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_BACK:
                        hideSoftInput();
                        return true;
                    case KeyEvent.KEYCODE_TAB:
                        if (focusedItem.onTab(event.isShiftPressed()))
                            postInvalidate();
                        return true;
                    case KeyEvent.KEYCODE_ENTER:
                        if (focusedItem.onEnter()) {
                            if ((focusedItem == S.find.findAction || focusedItem == S.find.replaceAction)) {
                                startEditing(S.sources,  0, 0);
                                S.find.close();
                            }
                            else
                                hideSoftInput();
                            postInvalidate();
                            return true;
                        }
                    case KeyEvent.KEYCODE_X:
                    case KeyEvent.KEYCODE_V:
                    case KeyEvent.KEYCODE_C:
                    case KeyEvent.KEYCODE_S:
                    case KeyEvent.KEYCODE_F:
                    case KeyEvent.KEYCODE_H:
                    case KeyEvent.KEYCODE_Z:
                        if (event.isCtrlPressed()) {
                            if (keyCode == KeyEvent.KEYCODE_X) {
                                StringBuilder builder = new StringBuilder();
                                focusedItem.copy(builder);
                                String text = builder.toString();
                                setClipboardText(text);
                                if (text != null) {
                                    focusedItem.del();
                                    postInvalidate();
                                }

                            }
                            else if (keyCode == KeyEvent.KEYCODE_C) {
                                StringBuilder builder = new StringBuilder();
                                focusedItem.copy(builder);
                                String text = builder.toString();
                                setClipboardText(text);
                            }
                            else if (keyCode == KeyEvent.KEYCODE_V) {
                                String text = getClipboardText();
                                if (text != null) {
                                    if (focusedItem.paste(text))
                                        postInvalidate();
                                }
                            }
                            else if (keyCode == KeyEvent.KEYCODE_S) {
                                focusedItem.save();
                            }
                            else if (keyCode == KeyEvent.KEYCODE_Z) {
                                if (focusedItem.undo())
                                    postInvalidate();
                            }
                            else if (keyCode == KeyEvent.KEYCODE_F) {
                                S.find.show(S.text_size, S.text_size);
                                ActionEdit action = S.find.findAction;
                                startEditing(action,  S.find.rect.left + S.find.paint.measureText(action.edit.toString()), S.text_size);
                                postInvalidate();
                            }
                            else if (keyCode == KeyEvent.KEYCODE_H) {
                                ActionEdit action = S.find.replaceAction;
                                String text = copy();
                                if (text != null) {
                                     S.find.findAction.edit.setText(text);
                                     action.edit.setText(text);
                                }
                                S.find.show(S.text_size, S.text_size);                                
                                startEditing(action,  S.find.rect.left + S.find.paint.measureText(action.edit.toString()), S.text_size);
                                postInvalidate();
                            }
                            return true;
                        }
                    default: {
                        char c = (char) event.getUnicodeChar();
                        if (c > 0) {
                            if (focusedItem.paste(String.valueOf(c)))
                                postInvalidate();
                            return true;
                        }
                    }
                }
            } else if (event.getAction() == KeyEvent.ACTION_MULTIPLE) {
                if (keyCode == KeyEvent.KEYCODE_UNKNOWN) {
                    if (focusedItem.paste(event.getCharacters()))
                        postInvalidate();
                    return true;
                } else {
                    char c = (char)event.getUnicodeChar();
                    if (c > 0) {
                        int count = event.getRepeatCount();
                        for(int i = 0; i < count; i++) 
                            focusedItem.paste(String.valueOf(c));
                        postInvalidate();
                        return true;
                    }
                }
            }
            return false;
        }
        return super.dispatchKeyEvent(event);
    }

    boolean softInputVisible() {
        Rect r = new Rect();
        getWindowVisibleDisplayFrame(r);
        int height = getHeight();
        return height - r.height() > height / 10;
    }

    private void hideSoftInput() {
        if (softInputVisible()) {
            InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(0, 0);
        }
        if (isFocusable())
            setFocusable(false);
        if (isFocusableInTouchMode())
            setFocusableInTouchMode(false);
        focusedItem.stopEditing();
        focusedItem = null;
        postInvalidate();
    }

    private boolean startEditing(ITextEditor item, float x, float y) {
        if (!item.startEditing(x, y)) {
            if (focusedItem != null && focusedItem != item)
                hideSoftInput();
            return false;
        }
        if (focusedItem != null && focusedItem != item)
            focusedItem.stopEditing();
        focusedItem = item;
        return true;
    }

    private boolean showSoftInput(ITextEditor item, float x, float y) {
        if (!startEditing(item, x, y))
            return false;
        if (!isFocusableInTouchMode())
            setFocusableInTouchMode(true);
        if (!isFocusable())
            setFocusable(true);
        if (!softInputVisible()) {
            InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(this, 0);
            postInvalidate();
        }
        return true;
    }


    @Override
    public boolean onTouchEvent(MotionEvent e)
    {
        gestureDetector.onTouchEvent(e);
        gestureDetector2.onTouchEvent(e);
        return true;
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (0 != (e.getSource() & InputDevice.SOURCE_CLASS_POINTER)) {
            if (e.getAction() == MotionEvent.ACTION_SCROLL) {
                scroll(e.getX(), e.getY(), e.getAxisValue(MotionEvent.AXIS_VSCROLL));
                return true;
            }
            else if (e.getAction() == MotionEvent.ACTION_HOVER_MOVE) {
                pointer_x = e.getX() + S.pointer_dx;
                pointer_y = e.getY() + S.pointer_dy;
            }
        }
        return super.onGenericMotionEvent(e);
    }

    String copy(){
        if (focusedItem != null) {
            StringBuilder builder = new StringBuilder();
            focusedItem.copy(builder);
            return builder.toString();
        }
        return null;
    }

    void paste(String text){
        if (focusedItem != null) {
            if (focusedItem.paste(text));
                postInvalidate();
        }
    }

    void scroll(float x, float y, float scroll) {
        IView view = getView(x, y);
        if (view != null && view.onScroll(x, y, -scroll * S.text_size))
            postInvalidate();
    }

    void pan(float x1, float y1, float x2, float y2, float dx, float dy) {
        if (ev_x1!=x1 && ev_y1!=y1){
            ev_x1 = x1;
            ev_y1 = y1;
            pan_scroll = Math.abs(dx)<Math.abs(dy);
            pan_select = dx<0 && !(pan_scroll);
        }
        IView view = getView(x1, y1);
        if (pan_select){
            if (view != null && view instanceof ITextSelection) {
                ((ITextSelection)view).select(x1, y1, x2, y2);
                postInvalidate();
            }
        }
        else {
            if (pan_scroll) {
                if (view.onScroll(x1, y1, dy))
                    postInvalidate();
            }
        }
    }

    void onClick(float x, float y) {
        try {
            Actions aa = Actions.active;
            if (aa != null && aa.rect.contains(x,y)) {
                Action action = aa.onClick(x, y);
                if (action!= null && action instanceof ITextEditor)
                    showSoftInput((ITextEditor)action, x, y);
                postInvalidate();
                return;
            } else if (aa == null && x == S.pointer_dx && y < getHeight()*0.75f){
                S.find.show(x, y);
                postInvalidate();
                return;
            }

            IView view = getView(x, y);
            if (view != null) {
                if (view instanceof ITextEditor) {
                if (!showSoftInput((ITextEditor) view, x, y))
                    view.onClick(x, y);
                }
                else {
                    if (focusedItem != null)
                        hideSoftInput();
                    view.onClick(x, y);
                }
                postInvalidate();
            }
            else if (focusedItem != null)
                hideSoftInput();
        }
        catch (Exception e)  {
            S.builder.log(e);
        }
    }

    IView getView(float x, float y){
        if (S.explorer.contains(x, y))
            return S.explorer;
        if (S.sources.contains(x, y))
            return S.sources;
        if (S.builder.contains(x, y))
            return S.builder;
        return null;
    }

    void layout(){
        if (scroll_velx != 0 || scroll_vely != 0){
            scroll_velx -= scroll_velx*S.scroll_attenuation;
            scroll_vely -= scroll_vely*S.scroll_attenuation;
            if (Math.abs(scroll_velx)<0.01f) scroll_velx = 0;
            if (Math.abs(scroll_vely)<0.01f) scroll_vely = 0;
            if (scroll_velx != 0 || scroll_vely != 0){
                scroll(ev_x1,ev_y1,scroll_vely);
            } else {
                postInvalidate();
            }
        }
        float dx = pan_dX;
        float dy = pan_dY;
        if (dx != 0 || dy != 0) {
            pan_dX = pan_dY = 0;
            scroll(ev_x1,ev_y1, dy);
        }
        else if (S.invalidLayout){
            S.invalidLayout = false;
            float width = getWidth();
            float height = getHeight();
            float x = S.explorer.rect.width();
            float y = height - S.text_size * 8;
            S.explorer.move(0, 0, x, height);
            x += S.text_size / 2;
            S.sources.move(x, 0, width, y);
            S.builder.move(x, y + S.text_size , width, height);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            drawAll(canvas);
        }
        catch (Exception e) {
            S.builder.log(e);
        }
    }

    void drawAll(Canvas canvas){
        layout();
        S.explorer.onDraw(canvas);
        S.sources.onDraw(canvas);
        S.builder.onDraw(canvas);
        Actions aa = Actions.active;
        if (aa!=null)
            aa.onDraw(canvas);
    }
}

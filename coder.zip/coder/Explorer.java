package com.sp.coder;

import android.graphics.Canvas;

import java.util.ArrayList;

class Explorer extends Text {
    ArrayList<String> forders = new ArrayList<String>();
    ArrayList<String> files = new ArrayList<String>();
    String path;
    Explorer() {
        path = "/sdcard/";
        load();
        paint.setColor(S.color_link);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawLine(rect.right, rect.top, rect.right, rect.bottom, paint);
    }

    @Override
    public void onClick(float x, float y) {
        int i = getLine(getCursor(x, y));
        if (i >=  0) {
            if (i < forders.size()) {
                path = i == 0 ? S.getParentFolder(path) : path + forders.get(i) + C.slash;
                load();
            }
            else
                S.sources.open(path + files.get(i-forders.size()));
        }
    }

    void load() {
        forders.clear();
        forders.add("..");
        S.loadLocalFilesSorted(forders, path, true);
        files.clear();
        S.loadLocalFilesSorted(files, path, false);
        lines.clear();
        float max = 0;
        float width;
        for (String folder : forders) {
            lines.add(folder);
            if ((width = paint.measureText(folder)) > max)
                max = width;
        }
        for (String file : files) {
            lines.add(file);
            if ((width = paint.measureText(file)) > max)
                max = width;
        }
        max += S.text_size / 2;
        if (max != rect.width()) {
            rect.right = rect.left + max;
            S.invalidLayout = true;
        }
    }

}

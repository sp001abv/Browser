package com.sp.coder;

import android.content.Intent;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import android.graphics.Canvas;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class Builder extends Text {

    void log(String text, int index) {
        synchronized (lines) {
            if (index<0) {
                lines.add(text);
            }
            else {
                while(lines.size()<=index)
                    lines.add(C.empty);
                lines.set(index, text);
            }
        }
    }

    void log(String text) {
        log(text, -1);
    }

    void log(Exception e) {
        log(e.getMessage());
        StackTraceElement[] stack = e.getStackTrace();
        for(int i = 0; i < 5 && i < stack.length; i++)
            log(stack[i].toString());
    }

    void build(MainLayout main, boolean resources) {
        final String done = "done!";
        String path = S.explorer.path;
        int i = path.lastIndexOf("/src/");
        if (i > 0) path = path.substring(0, i+1);
        scroll = 0;
        synchronized (lines) {
            lines.clear();
        }

        if (resources) {
            log("building resources ...");
            main.postInvalidate();
            if (execute(S.build_resources, path))
                S.builder.log(done);
            main.postInvalidate();
            return;
        }

        log("compiling ...");
        main.postInvalidate();
        if (!execute(S.compile_java_classes, path)) {
            main.postInvalidate();
            return;
        }
        main.postInvalidate();
        log("dexing ...");
        main.postInvalidate();
        if (!execute(S.dex_java_classes, path)) {
            main.postInvalidate();
            return;
        }
        main.postInvalidate();
        log("packing ...");
        main.postInvalidate();
        if (!execute(S.pack_apk, path))
            return;
        main.postInvalidate();
        S.builder.log("signing ...");
        if (!S.builder.execute(S.sign_apk, path)) {
            main.postInvalidate();
            return;
        }
        S.builder.log(done);
        main.postInvalidate();

        install(main, path);
    }

    boolean execute(String command, String path) {
        boolean error = false;
        try {
            String[] args = new String[2];
            args[0] = S.sdk_folder + command;
            args[1] = path;
            Process process = Runtime.getRuntime().exec(args);
            error = process.waitFor() != 0;
            if (error || !command.equals(S.pack_apk)) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                String line;
                while ((line = reader.readLine()) != null)
                        log(line);
                reader.close();
            }
        }
        catch (Exception e) {
            log(e);
            error = true;
        }
        return !error;
    }

    void install(MainLayout main, String path) {
        try
        {
            String url = "file://" + path + "bin/app-release.apk";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            String extension = S.getExt(url);
            String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
            intent.setDataAndType(Uri.parse(url), type);
            main.getContext().startActivity(intent);
        }
        catch (Exception e){
           log(e);
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        synchronized (lines) {
            super.onDraw(canvas);
        }
        canvas.drawLine(rect.left, rect.top, rect.right, rect.top, paint);
    }

    @Override
    public void onClick(float x, float y) {
        int cursor = getCursor(x, y);
        if (cursor >= 0) {
            int line =  getLine(cursor);
            String text = lines.get(line);
            int i = text.indexOf(C.slash);
            if (i > 0) {
                int j = text.indexOf(C.space, i);
                if (j > 0) {
                    String path = text.substring(i, j);
                    i = text.indexOf(C.close_bracket, j);
                    if (i > 0) {
                        j = text.lastIndexOf(C.space, i);
                        if (j > 0) {
                            Source source = S.sources.open(path);
                            line = Integer.parseInt(text.substring(j+1, i))-1;
                            cursor = getCursor(line, 0);
                            S.sources.select(new Finding(source, cursor, cursor), true);
                        }
                    }
                }
            }
        }
    }
}
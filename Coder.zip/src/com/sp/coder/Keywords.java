package com.sp.coder;

import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

class Keywords {
    ArrayList<ArrayList<String>> keywords  = new ArrayList<ArrayList<String>>();
    Keywords() {
        ArrayList<String> list = new ArrayList<String>();
        keywords.add(list);
        int len = 0;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(C.home_folder + "keywords.txt"));
            String line;
            while((line=reader.readLine()) != null){
                list.add(line);
                if (len < line.length()) len = line.length();
            }
            reader.close();
        }
        catch(Exception e) {
        }
        for (int i = 1; i <= len; i++) {
            keywords.add(new ArrayList<String>());
            for (int j = 0; j < list.size(); j++) {
                if (list.get(j).length() == i)
                    keywords.get(i).add(list.get(j));
            }
        }
    }

    boolean isKeyword(String text, int i1, int len) {
        if (len < keywords.size()) {
            ArrayList<String> list = keywords.get(len);
            for(int k = 0; k < list.size(); k++) {
                String keyword = list.get(k);
                int i;
                for (i = 0; i < len; i++) {
                    if (text.charAt(i1 + i) != keyword.charAt(i))
                        break;
                }
                if (i == len)
                    return true;
            }
        }
        return false;
    }

}
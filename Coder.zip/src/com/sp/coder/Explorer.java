package com.sp.coder;

import android.graphics.Canvas;

import java.util.ArrayList;

class Explorer extends Text {
    ArrayList<String> folders = new ArrayList<String>();
    ArrayList<String> files = new ArrayList<String>();
    String path;
    boolean layout = true;
    
    Explorer() {
        path = S.home_folder;
        load();
    }

    @Override
    void drawLine(Canvas canvas, float x, float y, int line, String text) {
        boolean folder = line < folders.size();
        paint.setFakeBoldText(folder);
        paint.setColor(folder ? S.color_accent : S.color_link);
        canvas.drawText(text, x, y, paint);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        paint.setColor(S.color_text);
        canvas.drawLine(rect.right, rect.top, rect.right, rect.bottom, paint);
    }

    @Override
    public void onClick(float x, float y) {
        int i = getLine(getCursor(x, y));
        if (i >=  0) {
            if (i < folders.size()) {
                path = i == 0 ? S.getParentFolder(path) : path + folders.get(i) + C.slash;
                load();
            }
            else
                S.sources.open(path + files.get(i-folders.size()));
        }
    }

    void toggleHomeFolders() {
        path = path.equals(S.home_folder) ? C.home_folder : S. home_folder;
        load();
    }

    void load() {
        folders.clear();
        S.loadLocalFilesSorted(folders, path, true);
        folders.add(0, C.dot+S.getFolderName(path)+C.slash+C.dot+C.dot);
        files.clear();
        S.loadLocalFilesSorted(files, path, false);
        lines.clear();
        float max = 0;
        float width;
        for (String folder : folders) {
            lines.add(folder);
            if ((width = paint.measureText(folder)) > max)
                max = width;
        }
        for (String file : files) {
            lines.add(file);
            if ((width = paint.measureText(file)) > max)
                max = width;
        }
        max += S.text_size / 4;
        float min = paint.getTextSize()* 10;
        if (max  <  min)  max = min;
        rect.right = rect.left + max;
        layout = true;
    }

}
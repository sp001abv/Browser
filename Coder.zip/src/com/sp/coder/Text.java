package com.sp.coder;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.ArrayList;

class Text implements IView, ITextSelection {
    protected ArrayList<String> lines = new ArrayList<String>();
    protected Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    protected RectF rect = new RectF();
    protected int sel1;
    protected int sel2;
    protected float scroll;

    Text() {
        lines.add(C.empty);
        sel1 = sel2 = -1;
        paint.setTypeface(Typeface.SANS_SERIF);
        paint.setTextSize(S.text_size);
        paint.setColor(S.color_text);
    }

    void init(boolean bold, float size) {
    }

    void clear() {
        lines.clear();
        lines.add(C.empty);
    }

    void setText(String text) {
        lines.clear();
        if (text.indexOf(C.newline)>=0) {
            String[] strings = text.split(String.valueOf(C.newline));
            for (String s : strings)
                lines.add(s);
        }
        else
            lines.add(text);
    }

    @Override
    public String toString() {
        if (lines.size() == 0 )
            return C.empty;
        if (lines.size() == 1)
            return lines.get(0);
        StringBuilder builder = new StringBuilder();
        builder.append(lines.get(0));
        for(int i = 1; i < lines.size(); i++) {
            builder.append(C.newline);
            builder.append(lines.get(i));
        }
        return builder.toString();
    }

    @Override
    public void onClick(float x, float y) {
        sel2 = sel1 = getCursor(x, y);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if (rect.height() > paint.getTextSize()) {
            canvas.save();
            canvas.clipRect(rect);
        }
        float top = rect.top;
        float bottom = rect.bottom;
        float size = paint.getTextSize();
        float x = rect.left;
        float y = top + size - scroll;
        int end = lines.size();
        for (int i = 0; i < end; i++) {
            String line = lines.get(i);
            if ((y > top)) {
                paint.setColor(S.color_selected);
                drawSelection(canvas, x, y, i);
                paint.setColor(S.color_text);
                drawLine(canvas, x, y, i, line);
            }
            if (y > bottom)
                break;
            y += size;
        }
        if (rect.height() > paint.getTextSize())
            canvas.restore();
    }

    @Override
    public boolean onScroll(float x, float y, float factor) {
        return scroll(factor);
    }

    @Override
    public void move(float left, float top, float right, float bottom) {
        rect.set(left, top, right, bottom);
    }

    boolean scroll(float factor) {
        float s = scroll += factor;
        if (s < 0 ) {
            if (scroll == 0)
                return false;
            scroll = 0;
        }
        else {
            float max = lines.size() * paint.getTextSize() - rect.height() / 2;
            if (s > max) {
                if (scroll == max)
                    return false;
                scroll = max;
            }
            else
                scroll = s;
        }
        return true;
    }

    int getCursor(float x, float y){
        if (rect.contains(x,y)){
            int line = (int)((y+scroll-rect.top)/paint.getTextSize());
            if (line >= 0 && line < lines.size())
                return getCursor(line, getIndex(lines.get(line), x-rect.left));
        }
        return -1;
    }

    @Override
    public boolean contains(float x, float y) {
        return rect.contains(x, y);
    }

    static int getLine(int cursor) {
        return  cursor >> 12;
    }

    static int getIndex(int cursor) {
        return  cursor & 0x0FFF;
    }

    static int getCursor(int line, int index) {
        return (line << 12) | index;
    }
    
    void drawLine(Canvas canvas, float x, float y, int line, String text) {
        canvas.drawText(text, x, y, paint);
    }

    void drawSelection(Canvas canvas, float x, float y, int line){
        if (sel1 >= 0 && sel2 >= 0 && sel1 != sel2) {
            int p1 = sel1 > sel2 ? sel2 : sel1;
            int p2 = sel1 > sel2 ? sel1 : sel2;
            int line1 = getLine(p1);
            int line2 = getLine(p2);
            if (line1 <= line && line <= line2) {
                float x1 = line1 == line ? getTextWidth(lines.get(line1), getIndex(p1)) : 0;
                float x2 = line2 == line ? getTextWidth(lines.get(line2), getIndex(p2)) : paint.measureText(lines.get(line));
                float size = paint.getTextSize();
                float dy = size * 0.25f;                
                canvas.drawRect(x + x1, y - size + dy, x + x2, y + dy, paint);
            }
        }
    }

    float getTextWidth(String line, int index){
        return index > 0 ? paint.measureText(line,0, index) :  0;
    }

    float getTextHeight(int line){
        return line > 0 ? line * paint.getTextSize() : 0;
    }

    int getIndex(String line, float width) {
        int index = 0;
        while (index < line.length()) {
            if (width < paint.measureText(line, 0, index)) {
                index--;
                break;
            }
            index++;
        }
        return index;
    }

    @Override
    public void select(float x1, float y1, float x2, float y2) {
        sel1 = getCursor(x1,y1);
        sel2 = getCursor(x2, y2);
    }

    @Override
    public void copy(StringBuilder builder){
        if (sel1 >= 0 && sel2 >= 0 && sel1 != sel2) {
            int p1 = sel2 > sel1 ? sel1 : sel2;
            int p2 = sel2 > sel1 ? sel2 : sel1;
            int line1 = getLine(p1);
            int line2 = getLine(p2);
            for(int l = line1; l <= line2; l++) {
                String line = lines.get(l);
                if (line.length() > 0) {
                    int i1 = l == line1 ? getIndex(p1) : 0;
                    int i2 = l == line2 ? getIndex(p2) : line.length();
                    builder.append(line, i1 , i2);
                }
                if (l < line2)
                    builder.append(C.newline);
            }
        }
    }

    @Override
    public void find(String s, ArrayList<Finding> findings, boolean match){
        for(int line = 0; line < lines.size(); line++) {
            String text = lines.get(line);
            String t = match ? text : text.toLowerCase();
            int i1 = t.indexOf(s);
            while (i1 >= 0) {
                int i2 = i1+s.length();
                findings.add(new Finding(this, getCursor(line, i1), getCursor(line, i2)));
                i1 = t.indexOf(s, i2);
            }

        }
    }

    @Override
    public void select(Finding finding, boolean show)
    {
        if (finding.item == this) {
            int line = getLine(finding.cursor1);
            if (line >= 0 && line < lines.size()-1) {
                String text = lines.get(line);
                int len = text.length();
                int i1 = getIndex(finding.cursor1);
                int i2 = getIndex(finding.cursor2);
                if (i1 < len && i2 < len && i1 != i2) {
                    sel1 = finding.cursor1;
                    sel2 = finding.cursor2;
                }
                else {
                    i1 = text.lastIndexOf(S.tab);
                    if (i1 >= 0)
                        i1 += S.tab.length();
                    else
                        i1 = 0;
                    sel1 = getCursor(line, i1);
                    sel2 = getCursor(line, len);
                }
                if (show)
                    scroll(line * paint.getTextSize() - rect.height() / 2 - scroll);
            }
        }
    }

    @Override
    public void deselect() {
        sel1 = sel2 = -1;
    }
}
package com.sp.coder;

import java.io.FileReader;
import java.io.FileWriter;
import android.graphics.Canvas;

class Source extends TextEdit {
    boolean edited;
    String path;

    Source(String path) {
        this.path = path;
        load();
    }

    @Override
    public boolean del() {
        edited = true;
        return super.del();
    }

    @Override
    public boolean onEnter() {
        return false;
    }

    static boolean isSmallLetter(char c) {
        return c >='a' && c <='z';
    }

    static boolean isCapitalLetter(char c) {
        return c >='A' && c <='Z';
    }

    static boolean isDigit(char c) {
        return c >='0' && c <='9';
    }

    static boolean isLetterOrDigit(char c) {
        return isSmallLetter(c) || isCapitalLetter(c) || isDigit(c) || c == '_';
    }

    static boolean isQuote(char c) {
        return c == C.quote || c == C.ap;
    }

    static boolean isMember(String text, int i1, char next) {
        return (i1 > 0 && text.charAt(i1-1) == C.dot) && next != C.open_bracket;
    }

    static int getColor(String text, int i1, int i2, char next) {
        int color = S.color_text;
        char first = text.charAt(i1);
        if (!isDigit(first)) {
            if (isSmallLetter(first)) {
                if (S.keywords.isKeyword(text, i1, i2-i1))
                    color = S.color_keyword;
                else if (isMember(text, i1, next))
                    color = S.color_member;
            }
            else if (isCapitalLetter(first))
                color = S.color_type;
        }
        return color;
    }

    @Override
    void drawLine(Canvas canvas, float x, float y, int line, String text) {
        if (text.length() > 0) {
            if (S.hilight_keywords) {
                char c = text.charAt(0);
                boolean word = isLetterOrDigit(c);
                boolean quote = isQuote(c);
                int index = 0;
                int i;
                float dx = 0;
                for (i = 1; i < text.length(); i++) {
                    c = text.charAt(i);
                    if (quote || isQuote(c)) {
                        if (quote && isQuote(c)) {
                            i++;
                            paint.setColor(S.color_string);
                            canvas.drawText(text, index, i, x + dx, y, paint);
                            dx = paint.measureText(text, 0, i);
                            index = i;
                            quote = word = false;
                            continue;
                        }
                        else if (quote)
                            continue;
                        else
                            quote = word = true;
                    }
                    if (isLetterOrDigit(c) ^ word) {
                        paint.setColor(getColor(text, index, i, c));
                        canvas.drawText(text, index, i, x + dx, y, paint);
                        dx = paint.measureText(text, 0, i);
                        index = i;
                        word = !word;
                    }
                }
                if (i <= text.length()) {
                    paint.setColor(getColor(text, index, i, (char)0));
                    canvas.drawText(text, index, i, x + dx, y, paint);
                }
            }
            else
                canvas.drawText(text, x, y, paint);
        }
    }

    char getLastChar(String text) {
        return text.length() > 0 ? text.charAt(text.length()-1) : 0;
    }

    @Override
    void paste(char c) {
        super.paste(c);
        if (c == C.open_brace) {
            int cursor = sel1;
            super.paste(C.close_brace);
            sel2 = sel1 = cursor;
        }
    }

    @Override
    int addLine(int line, String s) {
        s = trimRight(s);
        String t = lines.get(line);
        String text = trimRight(t);
        if (text.length() != t.length())
            lines.set(line, text);
        if (text.length() > 0) {
            if (text.trim().length() > 0){
                s = s.trim();
                char lc = getLastChar(text);
                t = C.empty;
                int i = text.lastIndexOf(S.tab);
                if (i >= 0) t = text.substring(0, i+S.tab.length());
                char fc = s.length() > 0 ? s.charAt(0) : 0;
                if (lc != C.close_brace) {
                    if (lc == C.semi_column) {
                        String prev = line > 1 ? lines.get(line-1) : C.empty;
                        char pc = getLastChar(prev);
                        if (fc == C.close_brace || (pc != C.semi_column && pc != C.open_brace && pc != C.close_brace && pc != 0))
                            t = i > 0 ? text.substring(0, i) :  C.empty;
                    }
                    else if (fc == C.close_brace) {
                        if (lc == C.open_brace) {
                            lines.add(line+1, t + s);
                            s = C.empty;
                            t += S.tab;
                        }
                    }
                    else t += S.tab;
                }
                else if (fc == C.close_brace) {
                     t = i > 0 ? text.substring(0, i) :  C.empty;
                }
                super.addLine(line, t + s);
                return getCursor(++line, t.length());
            }
            else lines.set(line, C.empty);
        }
        return super.addLine(line, s);
    }

    @Override
    public boolean paste(String chars) {
        edited = true;
        return super.paste(chars);
    }

    @Override
    public boolean undo() {
        if (edited) {
            return load();
        }
        return false;
    }

    @Override
    public void save() {
        if (!edited)
            return;
        try {
            FileWriter output = new FileWriter(path);
            output.write(toString());
            output.close();
            edited = false;
            S.builder.log(C.saved_as + path);
        }
        catch (Exception e) {
            S.builder.log(e);
        }
    }

    String trimRight(String s) {
        int i = s.length()-1;
        while (i >= 0) {
            char c = s.charAt(i);
            if (c != 0 && c != C.cr && c != C.space && c != C.newline)
                break;
            i--;
        }
        s = ++i > 0 ? s.substring(0, i) : C.empty;
        return s;
    }

    boolean load() {
        try {
            FileReader reader = new FileReader(path);
            char[] buffer = new char[4096];
            int begin = 0;
            String s = C.empty;
            int len, count;
            lines.clear();
            while ((len = reader.read(buffer))>0){
                for (int i = 0; i < len ; i++) {
                    char c = buffer[i];
                    if (c == C.newline) {
                        count = i - begin;
                        if (count > 0)
                            s += trimRight(new String(buffer, begin, count));
                        lines.add(s);
                        begin = i + 1;
                        s = C.empty;
                    }
                }
                count = len - begin;
                if (count > 0)
                    s += new String(buffer, begin, count);
                begin = 0;
            }
            if (s.length() > 0)
                lines.add(s);
            reader.close();
            edited = false;
            return true;
        }
        catch (Exception e) {
            S.builder.log(e);
        }
        return false;
    }
}
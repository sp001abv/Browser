package com.sp.coder;

import java.io.FileReader;
import java.io.FileWriter;

class Source extends TextEdit {
    boolean edited;
    String path;

    Source(String path) {
        this.path = path;
        load();
    }

    @Override
    public boolean del() {
        edited = true;
        return super.del();
    }

    @Override
    public boolean onEnter() {
        return false;
    }

    char getLastChar(String text) {
        return text.length() > 0 ? text.charAt(text.length()-1) : 0;
    }

    @Override
    void paste(char c) {
        super.paste(c);
        if (c == C.open_brace) {
            int cursor = sel1;
            super.paste(C.close_brace);
            sel2 = sel1 = cursor;
        }
    }

    @Override
    int addLine(int line, String s) {
        s = trimRight(s);
        String text = lines.get(line);
        if (text.length() > 0) {
            if (text.trim().length() > 0){
                s = s.trim();
                char lc = getLastChar(text);
                String t = C.empty;
                int i = text.lastIndexOf(S.tab);
                if (i >= 0) t = text.substring(0, i+S.tab.length());
                if (lc != C.close_brace) {
                    char fc = s.length() > 0 ? s.charAt(0) : 0;
                    if (lc == C.semi_column) {
                        String prev = line > 1 ? lines.get(line-1) : C.empty;
                        char pc = getLastChar(prev);
                        if (fc == C.close_brace || (pc != C.semi_column && pc != C.open_brace && pc != C.close_brace && pc != 0))
                            t = i > 0 ? text.substring(0, i) :  C.empty;
                    }
                    else if (fc == C.close_brace) {
                        if (lc == C.open_brace) {
                            lines.add(line+1, t + s);
                            s = C.empty;
                            t += S.tab;
                        }
                    }
                    else t += S.tab;
                }
                super.addLine(line, t + s);
                return getCursor(++line, t.length());
            }
            else lines.set(line, C.empty);
        }
        return super.addLine(line, s);
    }

    @Override
    public boolean paste(String chars) {
        edited = true;
        return super.paste(chars);
    }

    @Override
    public boolean undo() {
        if (edited) {
            return load();
        }
        return false;
    }

    @Override
    public void save() {
        if (!edited)
            return;
        try {
            FileWriter output = new FileWriter(path);
            output.write(toString());
            output.close();
            edited = false;
            S.builder.log(C.saved_as + path);
        }
        catch (Exception e) {
            S.builder.log(e);
        }
    }

    String trimRight(String s) {
        int i = s.length()-1;
        while (i >= 0) {
            char c = s.charAt(i);
            if (c != 0 && c != C.cr && c != C.space && c != C.newline)
                break;
            i--;
        }
        s = ++i > 0 ? s.substring(0, i) : C.empty;
        return s;
    }

    boolean load() {
        try {
            FileReader reader = new FileReader(path);
            char[] buffer = new char[4096];
            int begin = 0;
            String s = C.empty;
            int len, count;
            lines.clear();
            while ((len = reader.read(buffer))>0){
                for (int i = 0; i < len ; i++) {
                    char c = buffer[i];
                    if (c == C.newline) {
                        count = i - begin;
                        if (count > 0)
                            s += trimRight(new String(buffer, begin, count));
                        lines.add(s);
                        begin = i + 1;
                        s = C.empty;
                    }
                }
                count = len - begin;
                if (count > 0)
                    s += new String(buffer, begin, count);
                begin = 0;
            }
            if (s.length() > 0)
                lines.add(s);
            reader.close();
            edited = false;
            return true;
        }
        catch (Exception e) {
            S.builder.log(e);
        }
        return false;
    }
}
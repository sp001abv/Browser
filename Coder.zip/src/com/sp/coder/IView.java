package com.sp.coder;

import android.graphics.Canvas;

interface IView {
    void onClick(float x, float y);
    void onDraw(Canvas canvas);
    boolean onScroll(float x, float y, float factor);
    void move(float left, float top, float right, float bottom);
    boolean contains(float x, float y);
}

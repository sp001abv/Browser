package com.sp.coder;

interface ITextEditor {
    boolean startEditing(float x, float y);
    boolean onEnter();
    boolean onTab(boolean shift, boolean control);
    boolean onLeft(boolean shift, boolean home);
    boolean onRight(boolean shift, boolean end);
    boolean onUp(boolean shift, boolean page);
    boolean onDown(boolean shift, boolean page);
    boolean del();
    void copy(StringBuilder builder);
    boolean paste(String text);
    void save();
    boolean undo();
    void stopEditing();
}
package com.sp.coder;

import android.graphics.Color;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

class S {
    static int color_text = Color.rgb(200, 200, 200);
    static int color_link = Color.rgb(0, 100, 255);
    static int color_accent = Color.rgb(0, 200, 255);
    static int color_selected = Color.rgb(100, 0, 100);
    static int color_cursor = Color.rgb(55, 255, 255);
    static int color_background = Color.BLACK;
    static int text_size = 26;
    static String tab = "    ";

    static boolean invalidLayout = true;
    static boolean show_software_input = false;
    static float fling_threshold = 800;
    static float fling_to_scroll = 400;
    static float scroll_attenuation = 0.1f;
    static float pointer_dx = -3.0f;
    static float pointer_dy = -10.0f;

    static String home_folder = "/mnt/external_sd/projects/Coder/src/com/sp/coder/";
    static String sdk_folder = "/data/asdk/";
    static String build_resources = "res.sh";
    static String compile_java_classes = "ecj.sh";
    static String dex_java_classes = "dx.sh";
    static String pack_apk = "pack.sh";
    static String sign_apk = "sign.sh";

    static boolean initialized = init();
    static Builder builder = new Builder();
    static Explorer explorer = new Explorer();
    static FindActions find = new FindActions();
    static Sources sources = new Sources();

    static void applySkin(String skin) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(C.home_folder+skin));
            String line;
            while((line=reader.readLine()) != null){
                String[] v = line.split(String.valueOf(C.equals));
                if (v[0].equals("color_text")) color_text=Color.parseColor(v[1]);
                if (v[0].equals("color_link")) color_link=Color.parseColor(v[1]);
                if (v[0].equals("color_accent")) color_accent=Color.parseColor(v[1]);
                if (v[0].equals("color_selected")) color_selected=Color.parseColor(v[1]);
                if (v[0].equals("color_cursor")) color_cursor=Color.parseColor(v[1]);
                if (v[0].equals("color_background")) color_background=Color.parseColor(v[1]);
            }
            reader.close();
        }
        catch(Exception e) {}
    }

    static boolean init(){
        try {
            BufferedReader reader = new BufferedReader(new FileReader(C.home_folder+"Coder.cfg"));
            String line;
            String skin = null;
            while((line=reader.readLine()) != null){
                String[] v = line.split(String.valueOf(C.equals));
                if (v[0].equals("skin")) skin=v[1];
                if (v[0].equals("text_size")) text_size=Integer.parseInt(v[1]);

                if (v[0].equals("home_folder")) home_folder=v[1];
                if (v[0].equals("sdk_folder")) sdk_folder=v[1];
                if (v[0].equals("build_resources")) build_resources=v[1];
                if (v[0].equals("compile_java_classes")) compile_java_classes=v[1];
                if (v[0].equals("dex_java_classes")) dex_java_classes=v[1];
                if (v[0].equals("pack_apk")) pack_apk=v[1];
                if (v[0].equals("sign_apk")) sign_apk=v[1];
            }
            reader.close();
            if (skin != null) applySkin(skin);
            return true;
        }
        catch(Exception e) {}
        return false;
    }

    static float getFileSize(File f) {
        float size = f.length();
        if (f.isDirectory()) {
            File files[] = f.listFiles();
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    size += getFileSize(files[i]);
                }
            }
        }
        return size;
    }

    static String getExt(String url) {
        int i =	url.lastIndexOf(C.dot)+1;
        return i > 0 ? url.substring(i) : null;
    }

    static String getFolderName(String url) {
        return url.substring(url.lastIndexOf(C.slash, url.length()-2)+1, url.length()-1);
    }

    static String getFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash)+1);
    }

    static String getParentFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash, url.length()-2)+1);
    }

    static void loadLocalFilesSorted(ArrayList<String> locals, String path, boolean directory) {
        File folder = new File(path);
        File files[] = folder.listFiles();
        if (files != null) {
            for (File f : files) {
                if ((directory && f.isDirectory()) ||
                        (!directory && f.isFile())) {
                    String fileName = f.getName();
                    addSorted(locals, fileName);
                }
            }
        }
    }

    static void addSorted(ArrayList<String> sorted, String s) {
        for (int i = 0; i < sorted.size(); i++) {
            String s1 = sorted.get(i);
            if (s.compareToIgnoreCase(s1) < 0) {
                sorted.set(i, s);
                s = s1;
                i--;
            }
        }
        sorted.add(s);
    }

    static String getFileName(String url) {
        int i;
        i = url.lastIndexOf(C.slash);
        if (i > 0)
            url = url.substring(i+1);
        return url;
    }

}
package com.sp.coder;

import android.graphics.Color;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

class S {
    static int color_text = Color.rgb(200, 200, 200);
    static int color_link = Color.rgb(0, 100, 255);
    static int color_accent = Color.rgb(0, 200, 255);
    static int color_selection = Color.rgb(100, 0, 100);
    static int color_cursor = Color.rgb(55, 255, 255);
    static int color_background = Color.BLACK;
    static int color_keyword = Color.rgb(0, 150, 255);
    static int color_type = Color.rgb(0, 200, 255);
    static int color_member = Color.rgb(255, 180, 0);
    static int color_string = Color.rgb(0, 255, 0);
    static int text_size = 24;
    static boolean hilight_keywords = true;
    static String tab = "    ";

    static boolean show_software_input = false;
    static float fling_threshold = 800;
    static float fling_to_scroll = 400;
    static float scroll_attenuation = 0.1f;
    static float pointer_dx = -3.0f;
    static float pointer_dy = -10.0f;

    static String home_folder = "/mnt/external_sd/projects/Coder/src/com/sp/coder/";
    static String sdk_folder = "/data/asdk/";
    static String build_resources = "res.sh";
    static String compile_java_classes = "ecj.sh";
    static String dex_java_classes = "dx.sh";
    static String pack_apk = "pack.sh";
    static String sign_apk = "sign.sh";

    static String skin = init();
    static Builder builder = new Builder();
    static Explorer explorer = new Explorer();
    static FindActions find = new FindActions();
    static Sources sources = new Sources();
    static Keywords keywords = new Keywords();

    static String init(){
        try {
            BufferedReader reader = new BufferedReader(new FileReader(C.home_folder+"Coder.cfg"));
            String line;
            while((line=reader.readLine()) != null){
                String[] kv = line.split(String.valueOf(C.equals));
                String k = kv[0];
                String v = kv[1];
                if (k.equals("skin")) skin=v;
                if (k.equals("text_size")) text_size=Integer.parseInt(v);
                if (k.equals("show_software_input")) show_software_input=Boolean.parseBoolean(v);
                if (k.equals("home_folder")) home_folder=v;
                if (k.equals("sdk_folder")) sdk_folder=v;
                if (k.equals("build_resources")) build_resources=v;
                if (k.equals("compile_java_classes")) compile_java_classes=v;
                if (k.equals("dex_java_classes")) dex_java_classes=v;
                if (k.equals("pack_apk")) pack_apk=v;
                if (k.equals("sign_apk")) sign_apk=v;
            }
            reader.close();
            if (skin != null) applySkin();
            return skin;
        }
        catch(Exception e) {
        }
        return null;
    }

    static void applySkin() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(C.home_folder+skin));
            String line;
            while((line=reader.readLine()) != null){
                String[] kv = line.split(String.valueOf(C.equals));
                String k = kv[0];
                String v = kv[1];
                if (k.equals("text")) color_text=Color.parseColor(v);
                if (k.equals("link")) color_link=Color.parseColor(v);
                if (k.equals("accent")) color_accent=Color.parseColor(v);
                if (k.equals("selection")) color_selection=Color.parseColor(v);
                if (k.equals("cursor")) color_cursor=Color.parseColor(v);
                if (k.equals("background")) color_background=Color.parseColor(v);
                if (k.equals("keyword")) color_keyword=Color.parseColor(v);
                if (k.equals("type")) color_type=Color.parseColor(v);
                if (k.equals("member")) color_member=Color.parseColor(v);
                if (k.equals("string")) color_string=Color.parseColor(v);
            }
            reader.close();
        }
        catch(Exception e) {
            skin = null;
        }
    }

    static void applyNextSkin() {
        ArrayList<String> skins = new ArrayList<String>();
        ArrayList<String> files = new ArrayList<String>();
        loadLocalFilesSorted(files, C.home_folder, false);
        for (String file: files) {
            String ext = getExt(file);
            if (ext.equals("skin")) {
                skins.add(file);
            }
        }
        if (skins.size() > 0) {
            if (skin == null) {
                skin  = skins.get(0);
                applySkin();
                return;
            }
            if (skins.size() == 1)
                return;
            for (int i = 0; i < skins.size(); i++) {
                if (skins.get(i).equals(skin)) {
                    skin = skins.get(++i < skins.size() ? i  : 0);
                    applySkin();
                }
            }
        }
    }

    static float getFileSize(File f) {
        float size = f.length();
        if (f.isDirectory()) {
            File files[] = f.listFiles();
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    size += getFileSize(files[i]);
                }
            }
        }
        return size;
    }

    static String getExt(String url) {
        int i =	url.lastIndexOf(C.dot)+1;
        return i > 0 ? url.substring(i) : null;
    }

    static String getFolderName(String url) {
        return url.substring(url.lastIndexOf(C.slash, url.length()-2)+1, url.length()-1);
    }

    static String getFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash)+1);
    }

    static String getParentFolder(String url) {
        return url.substring(0, url.lastIndexOf(C.slash, url.length()-2)+1);
    }

    static void loadLocalFilesSorted(ArrayList<String> locals, String path, boolean directory) {
        File folder = new File(path);
        File files[] = folder.listFiles();
        if (files != null) {
            for (File f : files) {
                if ((directory && f.isDirectory()) ||
                        (!directory && f.isFile())) {
                    String fileName = f.getName();
                    addSorted(locals, fileName);
                }
            }
        }
    }

    static void addSorted(ArrayList<String> sorted, String s) {
        for (int i = 0; i < sorted.size(); i++) {
            String s1 = sorted.get(i);
            if (s.compareToIgnoreCase(s1) < 0) {
                sorted.set(i, s);
                s = s1;
                i--;
            }
        }
        sorted.add(s);
    }

    static String getFileName(String url) {
        int i;
        i = url.lastIndexOf(C.slash);
        if (i > 0)
            url = url.substring(i+1);
        return url;
    }

}